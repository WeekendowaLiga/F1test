# Weekendowa Liga F1

Strona internetowa ligi przygotowana do publikacji na GitHub Pages.

## Zawartość

```text
index.html                    Splash, nagłówek, nawigacja i wspólne okna
Logo.png                      Logo ligi
cars/                         Grafiki 11 bolidów
pages/
  klasyfikacje.html           Klasyfikacja kierowców i konstruktorów
  ostatni-wyscig.html         Ostatni wyścig
  archiwum.html               Archiwum wyścigów i kwalifikacji
  kalendarz.html              Kalendarz
  galeria.html                Galeria
  zespoly.html                Zespoły
  regulamin.html              Regulamin
scripts/
  bootstrap.js                Wczytywanie zakładek
  splash.js                   Przejście do strony i powrót do splasha
  app.js                      Logika strony, panel administracyjny i Firebase
styles/
  site.css                    Wspólne style
.nojekyll
.gitignore
README.md
```

## Publikacja

1. Rozpakuj ZIP. W katalogu po rozpakowaniu znajdziesz bezpośrednio `index.html`, `Logo.png`, `cars`, `pages`, `scripts` i `styles`.
2. Prześlij **zawartość rozpakowanego katalogu**, a nie sam plik ZIP, do głównego katalogu repozytorium `WeekendowaLiga/f1`. Zastąp dotychczasowy `index.html`.
3. Na GitHubie sprawdź `Settings → Pages → Build and deployment`. Wybierz `Deploy from a branch`, gałąź `main` i katalog `/ (root)`.
4. Po publikacji odwiedź `https://weekendowaliga.github.io/f1/` (w razie starej wersji wykonaj twarde odświeżenie przeglądarki).

Wszystkie pliki HTML są połączone przez `scripts/bootstrap.js`. Klikanie zakładek nie przeładowuje strony. Dane nadal pochodzą z dotychczasowej konfiguracji Firebase.

## Podgląd lokalny

Zakładki są wczytywane przez `fetch()`, dlatego nie należy otwierać `index.html` jako `file://` bez serwera. W katalogu projektu uruchom:

```bash
py -m http.server 8000
```

Następnie wejdź na `http://localhost:8000/`. Alternatywnie: `python -m http.server 8000`.

## Edycja

- Zawartość zakładek: pliki `pages/*.html`.
- Układ splasha i wspólne panele: `index.html`.
- Wygląd strony: `styles/site.css`.
- Obsługa Firebase, logowania, wyników i panelu administratora: `scripts/app.js`.
- Nawigacja i ładowanie widoków: `scripts/bootstrap.js`.

Zdjęcia z Google Dysku muszą mieć dostęp do wyświetlania dla osób z linkiem. Działanie zewnętrznych usług i dostępu do Firebase zależy od ich konfiguracji oraz połączenia internetowego.

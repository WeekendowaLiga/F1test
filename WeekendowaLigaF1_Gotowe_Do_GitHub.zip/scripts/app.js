import { initializeApp } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-app.js";
import { getAuth, signInWithEmailAndPassword, onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-auth.js";
import { getDatabase, ref, set, push, onValue, remove, update } from "https://www.gstatic.com/firebasejs/10.7.1/firebase-database.js";

try {

const firebaseConfig = {
    apiKey: "AIzaSyAGqYLPBR8UnOY3GdirJ-V4fkI-cygU8HA",
    authDomain: "f1-liga-43d29.firebaseapp.com",
    projectId: "f1-liga-43d29",
    databaseURL: "https://f1-liga-43d29-default-rtdb.europe-west1.firebasedatabase.app"
};
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getDatabase(app);
 
window._fbDb = db;
window._fbFirebase = { ref, onValue, set, update, push, remove };

let isLoggedIn = false;
let currentSplit = 1;
let adminSplit = 1;
let currentSeason = 2;  
let split2SoonMode = true;
let splitDataCache = {
    1: { standings: null, lastRace: null, archive: {}, teamsInfo: {} },
    2: { standings: null, lastRace: null, archive: {}, teamsInfo: {} }
};
window.splitDataCache = splitDataCache;  
let splashTimerInterval = null;
let cachedHeroConfig = { mode: 'countdown', date: '', title: '' };
let teamLogos = {};
let socialConfig = {};
let socialIconUploads = {};
let teamsInfoData = {};
const getTeamsInfoData = () => splitDataCache[currentSplit].teamsInfo || teamsInfoData;

const getArchiveDataCache = () => splitDataCache[currentSplit].archive;
const getLastRaceDataCache = () => splitDataCache[currentSplit].lastRace;
let archiveDataCache = {};
let lastRaceDataCache = null;
let calendarData = {};
let calendarSubscribed = false;
let splitSubscribed = {
    1: { standings: false, lastRace: false, archive: false, teamsInfo: false },
    2: { standings: false, lastRace: false, archive: false, teamsInfo: false }
};

const TEAM_DEFS = [
    { key: 'ferrari',  label: 'Ferrari',      color: '#ef1a2d', fullName: 'Scuderia Ferrari HP' },
    { key: 'mclaren',  label: 'McLaren',       color: '#ff8700', fullName: 'McLaren Formula 1 Team' },
    { key: 'redbull',  label: 'Red Bull',      color: '#131b45', fullName: 'Oracle Red Bull Racing' },
    { key: 'mercedes', label: 'Mercedes',      color: '#00d2be', fullName: 'Mercedes-AMG Petronas F1 Team' },
    { key: 'aston',    label: 'Aston Martin',  color: '#006f62', fullName: 'Aston Martin Aramco F1 Team' },
    { key: 'alpine',   label: 'Alpine',        color: '#6088d6', fullName: 'BWT Alpine F1 Team' },
    { key: 'haas',     label: 'Haas',          color: '#888888', fullName: 'MoneyGram Haas F1 Team' },
    { key: 'williams', label: 'Williams',      color: '#182cc4', fullName: 'Williams Racing' },
    { key: 'rb',       label: 'Racing Bulls',  color: '#004cff', fullName: 'Visa Cash App RB F1 Team' },
    { key: 'audi',     label: 'Audi',          color: '#3d3d3d', fullName: 'Audi F1 Team' },
    { key: 'cadillac', label: 'Cadillac',      color: '#1f1f1f', fullName: 'Cadillac F1 Team' },
];

const TEAM_DEFAULTS = {
    ferrari:  { driver1: '', driver2: '', desc: '' },
    mclaren:  { driver1: '', driver2: '', desc: '' },
    redbull:  { driver1: '', driver2: '', desc: '' },
    mercedes: { driver1: '', driver2: '', desc: '' },
    aston:    { driver1: '', driver2: '', desc: '' },
    alpine:   { driver1: '', driver2: '', desc: '' },
    haas:     { driver1: '', driver2: '', desc: '' },
    williams: { driver1: '', driver2: '', desc: '' },
    rb:       { driver1: '', driver2: '', desc: '' },
    audi:     { driver1: '', driver2: '', desc: '' },
    cadillac: { driver1: '', driver2: '', desc: '' },
    sauber:   { driver1: '', driver2: '', desc: '' },
};

const DEFAULT_DISCORD_SVG = `<svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" fill="#5865F2"><path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057 19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028c.462-.63.874-1.295 1.226-1.994a.076.076 0 0 0-.041-.106 13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.928 1.793 8.18 1.793 12.062 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.892.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.03zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.956-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.956 2.418-2.157 2.418zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.946 2.418-2.157 2.418z"/></svg>`;
const DEFAULT_YOUTUBE_SVG = `<svg viewBox="0 0 24 24" fill="#FF0000"><path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/></svg>`;
const DEFAULT_TIKTOK_SVG = `<svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-2.88 2.5 2.89 2.89 0 0 1-2.89-2.89 2.89 2.89 0 0 1 2.89-2.89c.28 0 .54.04.79.1V9.01a6.27 6.27 0 0 0-.79-.05 6.34 6.34 0 0 0-6.34 6.34 6.34 6.34 0 0 0 6.34 6.34 6.34 6.34 0 0 0 6.33-6.34V8.19a8.16 8.16 0 0 0 4.77 1.52V6.25a4.85 4.85 0 0 1-1-.56z" fill="#69C9D0" transform="translate(-1, 1)"/><path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-2.88 2.5 2.89 2.89 0 0 1-2.89-2.89 2.89 2.89 0 0 1 2.89-2.89c.28 0 .54.04.79.1V9.01a6.27 6.27 0 0 0-.79-.05 6.34 6.34 0 0 0-6.34 6.34 6.34 6.34 0 0 0 6.34 6.34 6.34 6.34 0 0 0 6.33-6.34V8.19a8.16 8.16 0 0 0 4.77 1.52V6.25a4.85 4.85 0 0 1-1-.56z" fill="#EE1D52" transform="translate(1, -1)"/><path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-2.88 2.5 2.89 2.89 0 0 1-2.89-2.89 2.89 2.89 0 0 1 2.89-2.89c.28 0 .54.04.79.1V9.01a6.27 6.27 0 0 0-.79-.05 6.34 6.34 0 0 0-6.34 6.34 6.34 6.34 0 0 0 6.34 6.34 6.34 6.34 0 0 0 6.33-6.34V8.19a8.16 8.16 0 0 0 4.77 1.52V6.25a4.85 4.85 0 0 1-1-.56z" fill="#ffffff"/></svg>`;

const getTeamColorByName = (teamName) => {
    const n = (teamName || '').toLowerCase().trim();
    if (n.includes('ferrari') || n.includes('scuderia')) return '#ef1a2d';
    if (n.includes('mercedes')) return '#00d2be';
    if (n.includes('red bull') && !n.includes('racing')) return '#131b45';
    if (n.includes('mclaren')) return '#ff8700';
    if (n.includes('aston')) return '#006f62';
    if (n.includes('alpine')) return '#6088d6';
    if (n.includes('williams')) return '#182cc4';
    if (n.includes('haas') || n.includes('moneygram')) return '#888888';
    if (n.includes('racing bull') || n.includes('visa cash') || n.includes('vcarb') || n === 'rb' || n.startsWith('rb ') || n.endsWith(' rb')) return '#004cff';
    if (n.includes('audi')) return '#3d3d3d';
        if (n.includes('cadillac')) return '#1f1f1f';
    if (n.includes('sauber') || n.includes('kick')) return '#00e600';
    return '#e10600';    return '#e10600';
};

const findFastestLapIdx = (results) => {
    const toSec = (t) => {
        if (!t || t === '-' || t === '' || t === '—') return Infinity;
        const clean = t.toString().trim();
        const m = clean.match(/^(\d+):(\d+)[\.,](\d+)$/);
        if (m) return parseInt(m[1]) * 60 + parseInt(m[2]) + parseInt(m[3]) / 1000;
        const s = parseFloat(clean.replace(',', '.'));
        return isNaN(s) ? Infinity : s;
    };
    let best = Infinity, idx = -1;
    (results || []).forEach((r, i) => { const t = toSec(r.best); if (t < best) { best = t; idx = i; } });
    return idx;
};
 
function animateCountUp(el, target, duration = 800) {
    if (!el) return;
    target = parseInt(target) || 0;
    if (target === 0) { el.textContent = '0'; return; }
    const start = performance.now();
    function tick(now) {
        const progress = Math.min((now - start) / duration, 1);
        const eased = 1 - Math.pow(1 - progress, 3);
        el.textContent = Math.round(target * eased);
        if (progress < 1) requestAnimationFrame(tick);
        else el.textContent = target;
    }
    requestAnimationFrame(tick);
}
function runCountUps(container) {
    if (!container) return;
    container.querySelectorAll('[data-countup]').forEach((el, i) => {
        const target = el.getAttribute('data-countup');
        setTimeout(() => animateCountUp(el, target), i * 20);
    });
}
const getDriverCurrentTeam = (nick) => {
    const nl = (nick || '').toLowerCase().trim();
    for (const [teamKey, info] of Object.entries(teamsInfoData)) {
        const d1 = (info.driver1 || '').toLowerCase().trim();
        const d2 = (info.driver2 || '').toLowerCase().trim();
        if ((d1 && d1 === nl) || (d2 && d2 === nl)) {
            const def = TEAM_DEFS.find(t => t.key === teamKey);
            return def ? def.label : teamKey;
        }
    }
    const sorted = Object.values(archiveDataCache).sort((a, b) => (b.timestamp || 0) - (a.timestamp || 0));
    for (const race of sorted) {
        if (race.results) {
            const r = race.results.find(r => (r.nick || '').toLowerCase() === nl);
            if (r && r.team) return r.team;
        }
    }
    if (lastRaceDataCache && lastRaceDataCache.results) {
        const r = lastRaceDataCache.results.find(r => (r.nick || '').toLowerCase() === nl);
        if (r && r.team) return r.team;
    }
    return '';
};

const _preloadKeep = [];
function preloadImages(urls) {
    (urls || []).forEach(u => {
        if (!u || u.startsWith('data:') || _preloadKeep.some(i => i.dataset.src === u)) return;
        const im = new Image();
        im.dataset.src = u;
        im.decoding = 'async';
        im.src = u;
        _preloadKeep.push(im);
    });
}

function renderTeamsPage() {
    const container = document.getElementById('teams-grid-container');
    if (!container) return;
    container.innerHTML = TEAM_DEFS.map((t, idx) => {
        const info = teamsInfoData[t.key] || TEAM_DEFAULTS[t.key] || {};
        const logoUrl = teamLogos[t.key] || '';
        const logoHtml = logoUrl
            ? `<img class="tpc-logo" src="${logoUrl}" alt="${t.label}" onerror="this.style.display='none'">`
            : `<div class="tpc-logo-placeholder">LOGO</div>`;
        const d1 = info.driver1 || '';
        const d2 = info.driver2 || '';
        const custom1 = info.custom1 || '';
        const custom2 = info.custom2 || '';
        const editHint = isLoggedIn ? `<div class="tpc-edit-hint">✎ EDYTUJ</div>` : '';

        const makeField = (fieldKey, value, label) => {
            const inner = isLoggedIn
                ? `<span class="tpc-editable" onclick="ui.editTeamField(this,'${t.key}','${fieldKey}')" title="Kliknij aby edytować">${value || '—'}</span>`
                : `<span>${value || '—'}</span>`;
            return `<div class="tpc-field"><div class="tpc-field-label">${label}</div><div class="tpc-field-value">${inner}</div></div>`;
        };

        const makeDriverField = (fieldKey, value, label) => {
            const display = value || '—';
            const isEmpty = !value || value.trim() === '';
            let inner;
            if (isLoggedIn) {
                inner = `<span class="tpc-editable" onclick="ui.editTeamField(this,'${t.key}','${fieldKey}')" title="Kliknij aby edytować">${display}</span>`;
            } else if (!isEmpty) {
                inner = `<span class="tpc-driver-clickable" onclick="ui.openDriverProfile('${value.replace(/'/g,"\\'")}') " title="Profil kierowcy">${display}</span>`;
            } else {
                inner = `<span>${display}</span>`;
            }
            return `<div class="tpc-field"><div class="tpc-field-label">${label}</div><div class="tpc-field-value">${inner}</div></div>`;
        };

        return `<div class="team-page-card tc-${t.key}" style="animation-delay:${idx * 0.06}s">
            ${editHint}
            <div class="tpc-header">
                <div>
                    <div class="tpc-name">${t.label}</div>
                    <div style="font-family:var(--font-body);font-size:14px;color:rgba(255,255,255,0.5);margin-top:4px;letter-spacing:1px;">${t.fullName}</div>
                </div>
                <div class="tpc-logo-wrap">${logoHtml}</div>
            </div>
			            <div class="tpc-car-stage">
                <div class="tpc-num">${String(idx + 1).padStart(2, '0')}</div>
                <img class="tpc-car" src="cars/${t.key}.png" alt="${t.label}" onerror="this.style.display='none'">
            </div>
            <div class="tpc-body">
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;">
                    ${makeDriverField('driver1', d1, '🏎 Kierowca 1')}
                    ${makeDriverField('driver2', d2, '🏎 Kierowca 2')}
                </div>
                ${(custom1 || custom2 || isLoggedIn) ? `<div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;">
                    ${makeField('custom1', custom1, 'Inżynier wyścigowy')}
                    ${makeField('custom2', custom2, '')}
                </div>` : ''}
            </div>

        </div>`;
    }).join('');
}

function buildTeamsAdminList() {
    const list = document.getElementById('adm-teams-cards-list');
    if (!list) return;
    list.innerHTML = TEAM_DEFS.map(t => {
        const info = teamsInfoData[t.key] || TEAM_DEFAULTS[t.key] || {};
        return `<div class="adm-team-row">
            <div class="adm-team-row-header"><div class="adm-team-swatch" style="background:${t.color};"></div><span class="adm-team-label">${t.label}</span></div>
            <div class="adm-team-fields">
                <div class="form-group" style="margin:0;"><label class="form-label" style="font-size:10px;">Kierowca 1</label><input type="text" class="f1-input" id="ti-${t.key}-driver1" value="${(info.driver1||'').replace(/"/g,'&quot;')}" style="padding:10px 12px;font-size:14px;"></div>
                <div class="form-group" style="margin:0;"><label class="form-label" style="font-size:10px;">Kierowca 2</label><input type="text" class="f1-input" id="ti-${t.key}-driver2" value="${(info.driver2||'').replace(/"/g,'&quot;')}" style="padding:10px 12px;font-size:14px;"></div>
                <div class="form-group adm-team-fields-full" style="margin:0;"><label class="form-label" style="font-size:10px;">Opis</label><input type="text" class="f1-input" id="ti-${t.key}-desc" value="${(info.desc||'').replace(/"/g,'&quot;')}" style="padding:10px 12px;font-size:14px;"></div>
                <div class="form-group" style="margin:0;"><label class="form-label" style="font-size:10px;">Pole własne 1</label><input type="text" class="f1-input" id="ti-${t.key}-custom1" value="${(info.custom1||'').replace(/"/g,'&quot;')}" style="padding:10px 12px;font-size:14px;" placeholder="np. Mistrzostwa: 16"></div>
                <div class="form-group" style="margin:0;"><label class="form-label" style="font-size:10px;">Pole własne 2</label><input type="text" class="f1-input" id="ti-${t.key}-custom2" value="${(info.custom2||'').replace(/"/g,'&quot;')}" style="padding:10px 12px;font-size:14px;" placeholder="np. Silnik: Ferrari"></div>
            </div>
        </div>`;
    }).join('');
}

function renderSocialIcons() {
    const splashContainer = document.getElementById('splash-social-icons');
    const headerContainer = document.getElementById('header-social-icons');
    const soonContainer   = document.getElementById('soon-social-icons');
    if (!splashContainer || !headerContainer) return;
    const platforms = [{ key: 'discord', defaultSvg: DEFAULT_DISCORD_SVG }, { key: 'youtube', defaultSvg: DEFAULT_YOUTUBE_SVG }, { key: 'tiktok', defaultSvg: DEFAULT_TIKTOK_SVG }];

    let splashHtml = '', headerHtml = '';
    platforms.forEach(({ key, defaultSvg }) => {
        const cfg = socialConfig[key] || {};
        const link = cfg.url || '';
        const iconSrc = cfg.icon || '';
        const label = key.charAt(0).toUpperCase() + key.slice(1);
        const innerHtml = iconSrc ? `<img src="${iconSrc}" alt="${key}" style="width:28px;height:28px;object-fit:contain;">` : defaultSvg;
        if (link) {
            splashHtml += `<a class="splash-social-btn" href="${link}" target="_blank" rel="noopener" onclick="event.stopPropagation()" title="${label}">${innerHtml}</a>`;
            headerHtml += `<a class="header-social-btn" href="${link}" target="_blank" rel="noopener" title="${label}">${innerHtml}</a>`;
        } else {
            splashHtml += `<span class="splash-social-btn" style="opacity:0.35;cursor:default;">${innerHtml}</span>`;
            headerHtml += `<span class="header-social-btn" style="opacity:0.35;cursor:default;">${innerHtml}</span>`;
        }
    });
    splashContainer.innerHTML = splashHtml;
    headerContainer.innerHTML = headerHtml;
    if (soonContainer) soonContainer.innerHTML = headerHtml;
}

function buildLogosGrid() {
    const grid = document.getElementById('adm-logos-grid');
    if (!grid) return;
    grid.innerHTML = TEAM_DEFS.map(t => {
        const url = teamLogos[t.key] || '';
        const isBase64 = url.startsWith('data:');
        return `<div class="adm-logo-item">
            <div class="logo-swatch" style="background:${t.color};"></div>
            <span class="logo-team-name">${t.label}</span>
            <div style="flex:1;min-width:0;">
                <input type="text" class="f1-input" id="logo-url-${t.key}" placeholder="URL logo lub prześlij plik →" value="${isBase64 ? '[plik lokalny]' : url}" oninput="ui.previewTeamLogo('${t.key}', this.value)" style="margin-bottom:6px;">
                <label class="logo-upload-label">📁 PRZEŚLIJ PLIK<input type="file" class="logo-upload-input" accept="image/*" onchange="ui.handleLogoUpload('${t.key}', this)"></label>
            </div>
            <img class="adm-logo-preview" id="logo-prev-${t.key}" src="${url || 'data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7'}" alt="${t.label}" onerror="this.style.opacity=0.2" style="opacity:${url ? 1 : 0.2}">
        </div>`;
    }).join('');
}

 
 
 
function parseSplashDriveLink(raw) {
    const value = String(raw || '').trim();
    if (!value) return null;
    try {
        const u = new URL(value);
        const host = u.hostname.toLowerCase();
        if (!['drive.google.com', 'docs.google.com', 'drive.usercontent.google.com'].includes(host)) return null;
        if (/\/folders\//.test(u.pathname)) return { folder: true };
        let id = '';
        const m = u.pathname.match(/\/(?:file\/)?d\/([a-zA-Z0-9_-]{12,})/);
        if (m) id = m[1];
        else if (u.pathname === '/open' || u.pathname === '/uc' || u.pathname === '/thumbnail' || u.pathname === '/download') id = u.searchParams.get('id') || '';
        else if (host === 'drive.usercontent.google.com') id = u.searchParams.get('id') || '';
        if (!/^[a-zA-Z0-9_-]{12,}$/.test(id)) return null;
        return { id, resourcekey: u.searchParams.get('resourcekey') || '' };
    } catch { return null; }
}
function normalizeSplashImageUrl(raw) {
    const value = String(raw || '').trim();
    const drive = parseSplashDriveLink(value);
    if (!drive || drive.folder) return value;
    const key = drive.resourcekey ? '&resourcekey=' + encodeURIComponent(drive.resourcekey) : '';
    return 'https://drive.google.com/thumbnail?id=' + encodeURIComponent(drive.id) + '&sz=w3200' + key;
}
function splashImageFallbackUrl(raw) {
    const drive = parseSplashDriveLink(raw);
    if (!drive || !drive.id) return '';
    return 'https://lh3.googleusercontent.com/d/' + encodeURIComponent(drive.id);
}
 
function loadSplashImage(img, raw, adminRow = null) {
    if (!img) return;
    const value = String(raw || '').trim();
    const source = normalizeSplashImageUrl(value);
    const fallback = splashImageFallbackUrl(value);
    const message = adminRow?.querySelector('.sie-link-message');
    if (message) {
        message.textContent = fallback ? 'Ładowanie zdjęcia z Google Dysku…' : '';
        message.classList.remove('error');
    }
    img.onerror = null;
    img.onload = null;
    if (!value) {
        img.removeAttribute('src');
        img.style.opacity = '.2';
        return;
    }
    let triedFallback = false;
    img.onload = () => {
        img.style.opacity = '1';
        if (message) { message.textContent = fallback ? 'Zdjęcie z Dysku jest dostępne.' : ''; message.classList.remove('error'); }
    };
    img.onerror = () => {
        if (fallback && !triedFallback) {
            triedFallback = true;
            img.src = fallback;
            return;
        }
        img.style.opacity = '.2';
        if (message) {
            message.textContent = fallback
                ? 'Nie udało się wczytać zdjęcia. Sprawdź: „Każda osoba mająca link” oraz czy plik jest obrazem.'
                : 'Nie udało się wczytać tego obrazu. Sprawdź adres URL.';
            message.classList.add('error');
        }
    };
    img.src = source;
}
function renderSplashImages(images) {
    const container = document.getElementById('splash-images-container');
    if (!container) return;
    const valid = Array.isArray(images) ? images.filter(img => img && img.url) : [];
    if (!valid.length) { container.innerHTML = ''; return; }
    const primary = valid[0];
    const pos = { left: 'left center', center: 'center center', right: 'right center' }[primary.align] || 'center center';
    container.innerHTML = `<div class="splash-featured-image"><img class="splash-image-main" alt="Zdjęcie wyścigowe" onclick="event.stopPropagation()"></div>` +
        (valid.length > 1 ? `<div class="splash-thumb-rail">${valid.slice(1).map(() => `<img alt="Zdjęcie wyścigowe" onclick="event.stopPropagation()">`).join('')}</div>` : '');
    const primaryImg = container.querySelector('.splash-featured-image .splash-image-main');
    primaryImg.style.objectPosition = pos;
    loadSplashImage(primaryImg, primary.url);
    container.querySelectorAll('.splash-thumb-rail img').forEach((img, i) => loadSplashImage(img, valid[i + 1].url));
}

function renderSplashCountdown(config) {
    const section = document.getElementById('splash-countdown-section');
    if (!section) return;
    const card = section.closest('.splash-countdown-card');
    if (splashTimerInterval) {
        clearInterval(splashTimerInterval);
        splashTimerInterval = null;
    }
     
    if (config && config.mode === 'soon') {
        if (card) card.classList.remove('is-hidden');
        section.innerHTML = '<div class="splash-soon" role="status">SOON</div>';
        return;
    }
    const rawDate = String((config && config.date) || '').trim();
    const target = rawDate ? new Date(rawDate.replace(' ', 'T')).getTime() : NaN;
    if (!Number.isFinite(target)) {
        if (card) card.classList.add('is-hidden');
        section.replaceChildren();
        return;
    }
    if (card) card.classList.remove('is-hidden');
    section.innerHTML = `<div class="splash-countdown" role="timer" aria-label="Czas do startu wyścigu">
        <div class="splash-timer-unit"><span class="splash-timer-val" id="sp-d">00</span><span class="splash-timer-label">DNI</span></div>
        <div class="splash-timer-unit"><span class="splash-timer-val" id="sp-h">00</span><span class="splash-timer-label">GODZIN</span></div>
        <div class="splash-timer-unit"><span class="splash-timer-val" id="sp-m">00</span><span class="splash-timer-label">MINUT</span></div>
        <div class="splash-timer-unit"><span class="splash-timer-val" id="sp-s">00</span><span class="splash-timer-label">SEKUND</span></div>
    </div>`;
    function tickSplash() {
        const diff = Math.max(0, target - Date.now());
        const d=Math.floor(diff/86400000), h=Math.floor((diff%86400000)/3600000),
              m=Math.floor((diff%3600000)/60000), s=Math.floor((diff%60000)/1000);
        const update=(id,val)=>{const el=document.getElementById(id);if(el)el.textContent=String(val).padStart(2,'0');};
        update('sp-d',d);update('sp-h',h);update('sp-m',m);update('sp-s',s);
        if (diff === 0 && splashTimerInterval) {clearInterval(splashTimerInterval);splashTimerInterval=null;}
    }
    tickSplash();
    if (target > Date.now()) splashTimerInterval = setInterval(tickSplash,1000);
}

function applySplitSwitcherVisibility(val) {
    const el = document.querySelector('.split-toggle-wrap');
    if (el) el.style.display = val ? 'none' : '';
}
function applyHeroConfig(splitNum) {
    const cfg = splitNum === 2 ? (window.heroConfigS2 || {}) : (window.heroConfigS1 || {});
    const mode = cfg.mode || 'countdown';
    const timerSection = document.getElementById('hero-timer-section');
    const soonSection  = document.getElementById('hero-soon-section');
    const titleEl      = document.getElementById('display-hero-title');
    const splashGpName = document.getElementById('splash-gp-name');

    if (titleEl) titleEl.innerText = cfg.title || 'NEXT GP';
    if (splashGpName) {
        if (cfg.title) { splashGpName.textContent = cfg.title; splashGpName.style.display = ''; }
        else splashGpName.style.display = 'none';
    }
    cachedHeroConfig = cfg;
    if (mode === 'soon') {
        if (timerSection) timerSection.style.display = 'none';
        if (soonSection)  soonSection.style.display  = 'block';
        if (window.f1Timer) clearInterval(window.f1Timer);
    } else {
        if (timerSection) timerSection.style.display = 'block';
        if (soonSection)  soonSection.style.display  = 'none';
        if (window.f1Timer) clearInterval(window.f1Timer);
        const targetDate = new Date((cfg.date || '').replace(' ', 'T')).getTime();
        function tickHero() {
            const diff = targetDate - Date.now();
            if (diff <= 0) { document.querySelectorAll('.timer-val').forEach(el => el.innerText = '00'); return; }
            const d=Math.floor(diff/86400000), h=Math.floor((diff%86400000)/3600000), m=Math.floor((diff%3600000)/60000), s=Math.floor((diff%60000)/1000);
            const td = document.getElementById('timer-d'); if(td) td.innerText = d.toString().padStart(2,'0');
            const th = document.getElementById('timer-h'); if(th) th.innerText = h.toString().padStart(2,'0');
            const tm = document.getElementById('timer-m'); if(tm) tm.innerText = m.toString().padStart(2,'0');
            const ts = document.getElementById('timer-s'); if(ts) ts.innerText = s.toString().padStart(2,'0');
        }
        tickHero();
        window.f1Timer = setInterval(tickHero, 1000);
    }
    localStorage.setItem('f1_heroConfig', JSON.stringify(cachedHeroConfig));
    renderSplashCountdown(cachedHeroConfig);
    const quickDateInput = document.getElementById('quick-countdown-date-input');
    if (quickDateInput) quickDateInput.value = (cfg.date || '').replace(' ', 'T');
}
let dragSrcEl = null;
function initSplashDragDrop() {
    const list = document.getElementById('adm-splash-images-list');
    list.querySelectorAll('.splash-img-entry').forEach(item => {
        item.draggable = true;
        item.addEventListener('dragstart', e => { dragSrcEl = item; item.classList.add('dragging'); e.dataTransfer.effectAllowed = 'move'; });
        item.addEventListener('dragend', () => { item.classList.remove('dragging'); list.querySelectorAll('.splash-img-entry').forEach(i => i.classList.remove('drag-over')); ui._renumberSplashRows(); });
        item.addEventListener('dragover', e => { e.preventDefault(); e.dataTransfer.dropEffect = 'move'; list.querySelectorAll('.splash-img-entry').forEach(i => i.classList.remove('drag-over')); if (item !== dragSrcEl) item.classList.add('drag-over'); return false; });
        item.addEventListener('drop', e => { e.stopPropagation(); if (dragSrcEl !== item) { const allItems = [...list.querySelectorAll('.splash-img-entry')]; const srcIdx = allItems.indexOf(dragSrcEl); const dstIdx = allItems.indexOf(item); if (srcIdx < dstIdx) { list.insertBefore(dragSrcEl, item.nextSibling); } else { list.insertBefore(dragSrcEl, item); } } return false; });
    });
}

let reorderDragSrc = null;
function initReorderList(listEl, onDrop) {
    listEl.querySelectorAll('.reorder-item').forEach(item => {
        item.draggable = true;
        item.addEventListener('dragstart', e => { reorderDragSrc = item; item.classList.add('dragging'); e.dataTransfer.effectAllowed = 'move'; });
        item.addEventListener('dragend', () => { item.classList.remove('dragging'); listEl.querySelectorAll('.reorder-item').forEach(i => i.classList.remove('drag-over')); if (onDrop) onDrop(); });
        item.addEventListener('dragover', e => { e.preventDefault(); e.dataTransfer.dropEffect = 'move'; listEl.querySelectorAll('.reorder-item').forEach(i => i.classList.remove('drag-over')); if (item !== reorderDragSrc) item.classList.add('drag-over'); return false; });
        item.addEventListener('drop', e => { e.stopPropagation(); if (reorderDragSrc && reorderDragSrc !== item) { const all = [...listEl.querySelectorAll('.reorder-item')]; const si = all.indexOf(reorderDragSrc), di = all.indexOf(item); if (si < di) listEl.insertBefore(reorderDragSrc, item.nextSibling); else listEl.insertBefore(reorderDragSrc, item); } return false; });
    });
}


function updateRegulaminButtons() {
    const isOnRegulamin = document.getElementById('view-regulamin')?.classList.contains('active');
    const show = isLoggedIn && isOnRegulamin;
    const editBtn = document.getElementById('regulamin-edit-btn');
    const cancelBtn = document.getElementById('regulamin-cancel-btn');
    const saveBtn = document.getElementById('regulamin-save-btn');
    if (editBtn) editBtn.style.display = show ? 'block' : 'none';
    if (cancelBtn) cancelBtn.style.display = show ? 'inline-flex' : 'none';
    if (saveBtn) saveBtn.style.display = show ? 'inline-flex' : 'none';
}
 
const renderQualiTable = (results, raceId = null) => {
    if (!results || results.length === 0) return '<p style="padding:20px;color:#aaa;font-family:var(--font-data);font-size:22px;">Brak danych kwalifikacji.</p>';
    const posClass = (i) => i===0?'pos-gold':i===1?'pos-silver':i===2?'pos-bronze':'';
    return `<table class="f1-table"><thead><tr>
        <th class="col-pos">P</th>
        <th class="col-driver">Kierowca</th>
        <th>Zespół</th>
        <th style="width:220px;">Najlepszy czas</th>
        <th style="width:120px;text-align:center;">P. startowa</th>
    </tr></thead><tbody>${results.map((r, i) => {
        const safeNick = (r.nick || '').replace(/'/g, "\\'");
        const nickHtml = `<span class="nick-clickable" onclick="ui.openDriverProfile('${safeNick}')" title="Profil kierowcy">${r.nick||'—'}</span>`;
        return `<tr class="${getTeamClass(r.team)}">
            <td class="col-pos ${posClass(i)}">${i+1}</td>
            <td class="col-driver">
    <span class="arc-cell-editable" onclick="ui.editArcCell(this,'${raceId}',${i},'nick')">
        ${r.nick || '—'}
    </span>
</td>
            <td class="${getTeamClass(r.team).replace('team-','txt-')}">
    <span class="arc-cell-editable" onclick="ui.editArcCell(this,'${raceId}',${i},'team')">
        ${r.team || '—'}
    </span>
</td>
            <td class="${i === 0 ? 'fastest-lap' : 'col-best-lap'}" style="font-weight:700;">
    <span class="arc-cell-editable" onclick="ui.editArcCell(this,'${raceId}',${i},'best')">
        ${r.best || '—'}
    </span>
</td>
            <td style="text-align:center;color:rgba(0,0,0,0.5);">
    <span class="arc-cell-editable" onclick="ui.editArcCell(this,'${raceId}',${i},'startPos')">
        ${r.startPos || r.grid || String(i + 1)}
    </span>
</td>
        </tr>`;
    }).join('')}</tbody></table>`;
};

window.ui = {
        switchPage(pageId, navEl) {
        document.querySelectorAll('.page-view').forEach(v => v.classList.remove('active'));
        document.querySelectorAll('.nav-item').forEach(i => i.classList.remove('active'));
        document.getElementById('view-' + pageId).classList.add('active');
        navEl.classList.add('active');
        document.getElementById('f1-main-nav')?.classList.remove('mobile-open');
        if (['standings','archive','gallery'].includes(pageId)) {
            this.switchSeasonSplit('2-1', pageId);
        }
        if (pageId === 'gallery') { this.closeAlbum(); subscribeGallery(); }
        if (pageId === 'archive') subscribeArchive(currentSplit);
        if (pageId === 'calendar') subscribeCalendar();
        if (pageId === 'teams') renderTeamsPage();
        if (pageId === 'standings') runCountUps(document.getElementById('view-standings'));
        updateRegulaminButtons();
        window.scrollTo({ top: 0, behavior: 'smooth' });
    },
    toggleAdmin(show) {
        document.getElementById('admin-sidebar').classList.toggle('open', show);
        document.getElementById('admin-overlay').classList.toggle('open', show);
        if (show) { buildLogosGrid(); buildTeamsAdminList(); buildRaceNickChips(); this.refreshGpNameSuggestion(1); this.refreshGpNameSuggestion(2); }
    },
toggleAuth(show) { 
    const modal = document.getElementById('auth-modal');
    if (!modal) return;
    if (show) {
        document.body.appendChild(modal);
        modal.style.display = 'flex';
        modal.style.alignItems = 'center';
        modal.style.justifyContent = 'center';
        modal.style.position = 'fixed';
        modal.style.inset = '0';
        modal.style.zIndex = 'var(--z-top)';
    } else {
        modal.style.display = 'none';
    }
},
    updateGpPreview(splitNum) {
        const input = document.getElementById('adm-gp-name-s' + splitNum);
        const preview = document.getElementById('gp-preview-s' + splitNum);
        if (!input) return;
        const val = input.value.trim();
        if (splitNum === 1) window.gpNameS1 = val; else window.gpNameS2 = val;
        if (preview) {
            if (!val) { preview.innerHTML = ''; }
            else {
                const round = getNextRoundNumber(splitNum);
                preview.innerHTML = `🏁 Wyniki: <strong>ROUND ${round} ${val.toUpperCase()}</strong> &nbsp;|&nbsp; 📷 Galeria: <strong>${gpNameToShort(val)}</strong>`;
            }
        }
        if (adminSplit === splitNum) this.refreshRaceTitleSuggestion();
        this.refreshGpNameSuggestion(splitNum);
    },
    refreshRaceTitleSuggestion() {
        const box = document.getElementById('race-title-suggestion-box');
        const textEl = document.getElementById('race-title-suggestion-text');
        if (!box || !textEl) return;
        const suggestion = buildRaceTitleSuggestion(adminSplit);
        if (suggestion) { textEl.textContent = suggestion; box.style.display = 'flex'; }
        else { box.style.display = 'none'; }
    },
    refreshGpNameSuggestion(splitNum) {
        const box = document.getElementById('gp-name-suggestion-box-s' + splitNum);
        const textEl = document.getElementById('gp-name-suggestion-text-s' + splitNum);
        if (!box || !textEl) return;
        const suggestion = buildGpNameSuggestion(splitNum);
        const currentVal = (document.getElementById('adm-gp-name-s' + splitNum)?.value || '').trim();
        if (suggestion && suggestion !== currentVal) { textEl.textContent = suggestion; box.style.display = 'flex'; }
        else { box.style.display = 'none'; }
    },
    useGpNameSuggestion(splitNum) {
        const suggestion = buildGpNameSuggestion(splitNum);
        if (!suggestion) return;
        const input = document.getElementById('adm-gp-name-s' + splitNum);
        if (input) { input.value = suggestion; ui.updateGpPreview(splitNum); }
    },
    useRaceTitleSuggestion() {
        const suggestion = buildRaceTitleSuggestion(adminSplit);
        if (suggestion) document.getElementById('adm-race-title').value = suggestion;
    },
    quickCreateAlbumForGp() {
        const nextCal = getNextCalendarEntry(currentSplit);
        const gpName = nextCal ? nextCal.entry.name : (currentSplit === 2 ? window.gpNameS2 : window.gpNameS1);
        const suggested = gpName ? gpNameToShort(gpName) : '';
        ui.openGalleryModal('album', null, suggested);
    },
	toggleAdminSection(header) {
        const body = header.nextElementSibling;
        const isOpen = body.classList.toggle('open');
        header.classList.toggle('open', isOpen);
    },
    openAdminSection(sectionId) {
        const section = document.getElementById(sectionId);
        if (!section) return;
        const header = section.querySelector('.admin-section-header');
        const body = section.querySelector('.admin-section-body');
        if (header && body && !body.classList.contains('open')) { body.classList.add('open'); header.classList.add('open'); }
        setTimeout(() => section.scrollIntoView({ behavior: 'smooth', block: 'start' }), 100);
        return false;
    },
    handleSocialIconUpload(platform, input) {
        const file = input.files[0]; if (!file) return;
        const reader = new FileReader();
        reader.onload = e => {
            const dataUrl = e.target.result;
            socialIconUploads[platform] = dataUrl;
            const prev = document.getElementById('social-prev-' + platform);
            if (prev) prev.innerHTML = `<img src="${dataUrl}" alt="${platform}" style="width:30px;height:30px;object-fit:contain;">`;
            const iconInput = document.getElementById('social-icon-' + platform);
            if (iconInput) iconInput.value = '[plik lokalny]';
        };
        reader.readAsDataURL(file);
    },
    openRegulaminEditor() {
        if (!isLoggedIn) return;
        const overlay = document.getElementById('regulamin-editor-overlay');
        if (!overlay) { console.error('Brak elementu #regulamin-editor-overlay w DOM'); return; }
        overlay.classList.add('open');;
        overlay.style.display = 'flex';
        overlay.style.position = 'fixed';
        overlay.style.inset = '0';
        overlay.style.zIndex = 'var(--z-modal-regulamin)';
        document.body.style.overflow = 'hidden';
        const ta = document.getElementById('regulamin-textarea');
        if (ta) setTimeout(() => ta.focus(), 50);
    },
    closeRegulaminEditor() {
        const overlay = document.getElementById('regulamin-editor-overlay');
        if (!overlay) return;
        overlay.classList.remove('open');
        overlay.style.display = 'none';
        document.body.style.overflow = '';
    },
    addSplashImageRow(imgData) {
        const list = document.getElementById('adm-splash-images-list');
        const count = list.querySelectorAll('.splash-img-entry').length;
        if (count >= 10) { ui.showToast('Maksymalnie 10 zdjęć.', 'warn'); return; }
        const url = imgData ? (imgData.url || '') : '';
        const width = imgData ? (imgData.width || '80%') : '80%';
        const align = imgData ? (imgData.align || 'center') : 'center';
        const scale = imgData ? (imgData.scale !== undefined ? parseFloat(imgData.scale) : 1) : 1;
        const isBase64 = url.startsWith('data:');
        const scalePercent = Math.round(scale * 100);
        const entry = document.createElement('div');
        entry.className = 'splash-img-entry';
        entry.innerHTML = `
            <span class="sie-drag-handle" title="Przeciągnij">⠿</span>
            <span class="sie-num">${count + 1}</span>
            <div class="sie-field">
                <label class="form-label" style="font-size:10px;margin-bottom:4px;">ŹRÓDŁO</label>
                <div class="sie-source-toggle">
                    <button type="button" class="sie-source-btn ${!isBase64 ? 'active' : ''}" onclick="ui.sieSetMode(this,'url')">URL</button>
                    <button type="button" class="sie-source-btn ${isBase64 ? 'active' : ''}" onclick="ui.sieSetMode(this,'file')">PLIK</button>
                </div>
                <div class="sie-url-wrap" style="display:${isBase64 ? 'none' : 'block'}">
                    <input type="text" class="f1-input spl-url" placeholder="Link do zdjęcia z Google Dysku lub adres JPG/PNG" value="${isBase64 ? '' : String(url).replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;')}" oninput="ui.updateSplashThumb(this)">
                    <span class="sie-link-message" aria-live="polite"></span>
                </div>
                <div class="sie-file-wrap" style="display:${isBase64 ? 'block' : 'none'}">
                    <label style="display:flex;align-items:center;gap:8px;cursor:pointer;background:#333;color:#fff;padding:10px 14px;border-radius:4px;font-size:12px;font-weight:800;letter-spacing:1px;text-transform:uppercase;" onmouseover="this.style.background='#e10600'" onmouseout="this.style.background='#333'">
                        📁 WYBIERZ PLIK<input type="file" accept="image/*" style="display:none" onchange="ui.handleSplashFileUpload(this)">
                    </label>
                    <input type="hidden" class="spl-url spl-file-data" value="${isBase64 ? url : ''}">
                    <span class="spl-file-name" style="font-size:11px;color:#888;margin-top:4px;display:block;">${isBase64 ? 'Plik lokalny załadowany' : 'Brak pliku'}</span>
                </div>
            </div>
            <div class="sie-field-sm">
                <label class="form-label" style="font-size:10px;margin-bottom:4px;">WYRÓWNANIE</label>
                <select class="f1-input spl-align"><option value="center" ${align==='center'?'selected':''}>Środek</option><option value="left" ${align==='left'?'selected':''}>Lewo</option><option value="right" ${align==='right'?'selected':''}>Prawo</option></select>
            </div>
            <div class="sie-field-sm">
                <label class="form-label" style="font-size:10px;margin-bottom:4px;">SZEROKOŚĆ</label>
                <input type="text" class="f1-input spl-width" placeholder="80%" value="${width}">
            </div>
            <div class="sie-field" style="min-width:180px;">
                <label class="form-label" style="font-size:10px;margin-bottom:4px;">SKALA</label>
                <div class="sie-scale-wrap">
                    <input type="range" class="spl-scale" min="10" max="200" value="${scalePercent}" oninput="this.nextElementSibling.textContent=this.value+'%'">
                    <span class="sie-scale-val">${scalePercent}%</span>
                </div>
            </div>
            <img class="splash-img-preview-thumb" style="opacity:${url ? 1 : 0.2}" alt="Podgląd">
            <button type="button" class="sie-remove" onclick="ui.removeSplashImageRow(this)" title="Usuń">✕</button>`;
        list.appendChild(entry);
        if (url) loadSplashImage(entry.querySelector('.splash-img-preview-thumb'), url, isBase64 ? null : entry);
        this._renumberSplashRows(); this._updateAddBtn(); initSplashDragDrop();
    },
    sieSetMode(btn, mode) {
        const entry = btn.closest('.splash-img-entry');
        entry.querySelectorAll('.sie-source-btn').forEach(b => b.classList.remove('active')); btn.classList.add('active');
        entry.querySelector('.sie-url-wrap').style.display = mode === 'url' ? 'block' : 'none';
        entry.querySelector('.sie-file-wrap').style.display = mode === 'file' ? 'block' : 'none';
        const selected = mode === 'file' ? entry.querySelector('.spl-file-data') : entry.querySelector('.sie-url-wrap .spl-url');
        loadSplashImage(entry.querySelector('.splash-img-preview-thumb'), selected?.value || '', mode === 'url' ? entry : null);
    },
    handleSplashFileUpload(input) {
        const file = input.files[0]; if (!file) return;
        const entry = input.closest('.splash-img-entry');
        const reader = new FileReader();
        reader.onload = e => {
            const dataUrl = e.target.result;
            const hidden = entry.querySelector('.spl-file-data');
            const thumb = entry.querySelector('.splash-img-preview-thumb');
            const nameSpan = entry.querySelector('.spl-file-name');
            if (hidden) hidden.value = dataUrl;
            if (thumb) loadSplashImage(thumb, dataUrl);
            if (nameSpan) nameSpan.textContent = file.name;
        };
        reader.readAsDataURL(file);
    },
    removeSplashImageRow(btn) { btn.closest('.splash-img-entry').remove(); this._renumberSplashRows(); this._updateAddBtn(); },
    _renumberSplashRows() { document.querySelectorAll('.splash-img-entry').forEach((row, i) => { const num = row.querySelector('.sie-num'); if (num) num.textContent = i + 1; }); },
    _updateAddBtn() {
        const list = document.getElementById('adm-splash-images-list');
        const count = list.querySelectorAll('.splash-img-entry').length;
        const btn = document.getElementById('btn-add-splash-img');
        if (btn) btn.style.display = count >= 10 ? 'none' : '';
    },
    updateSplashThumb(input) {
        const entry = input.closest('.splash-img-entry');
        loadSplashImage(entry.querySelector('.splash-img-preview-thumb'), input.value, entry);
    },
    previewTeamLogo(teamKey, url) {
        const img = document.getElementById('logo-prev-' + teamKey);
        if (!img) return;
        img.src = url || 'data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7';
        img.style.opacity = url ? 1 : 0.2;
        if (url && !url.startsWith('[')) teamLogos[teamKey] = url;
    },
   handleLogoUpload(teamKey, input) {
        const file = input.files[0]; if (!file) return;
        const reader = new FileReader();
        reader.onload = e => {
            const dataUrl = e.target.result; teamLogos[teamKey] = dataUrl;
            const img = document.getElementById('logo-prev-' + teamKey);
            if (img) { img.src = dataUrl; img.style.opacity = 1; }
            const urlInput = document.getElementById('logo-url-' + teamKey);
            if (urlInput) urlInput.value = '[plik lokalny]';
        };
        reader.readAsDataURL(file);
    },
    toggleArc(id) {
        const body = document.getElementById('arc-body-' + id);
        const btn  = document.getElementById('arc-btn-' + id);
        const isOpen = body.classList.toggle('open');
        if (btn) btn.classList.toggle('open', isOpen);
        if (isOpen) {
            ui.replayRowAnimations(body);
            if (isLoggedIn) setTimeout(() => initRaceRowDragDrop(`race-tbl-${id}`, id, false), 50);
        }
    },
    replayRowAnimations(container) {
        if (!container) return;
        container.querySelectorAll('tbody tr').forEach(row => {
            row.style.animation = 'none';
            void row.offsetWidth;
            row.style.animation = '';
        });
    },
    switchArchiveTab(tab) {
        const isRaces = tab === 'races';
        const showEl = document.getElementById(isRaces ? 'api-archive-list' : 'api-quali-list');
        const hideEl = document.getElementById(isRaces ? 'api-quali-list' : 'api-archive-list');
        if (hideEl) hideEl.style.display = 'none';
        if (showEl) {
            showEl.style.display = 'block';
            showEl.classList.remove('archive-list-anim');
            void showEl.offsetWidth;
            showEl.classList.add('archive-list-anim');
        }
        const activeStyle = 'font-family:var(--font-display);font-size:28px;font-weight:900;letter-spacing:2px;text-transform:uppercase;padding:20px 50px;background:var(--f1-black);color:#fff;border:none;cursor:pointer;border-bottom:4px solid var(--f1-red);margin-bottom:-4px;';
        const inactiveStyle = 'font-family:var(--font-display);font-size:28px;font-weight:900;letter-spacing:2px;text-transform:uppercase;padding:20px 50px;background:transparent;color:#888;border:none;cursor:pointer;border-bottom:4px solid transparent;margin-bottom:-4px;transition:all 0.2s;';
        document.getElementById('arc-tab-races').style.cssText = isRaces ? activeStyle : inactiveStyle;
        document.getElementById('arc-tab-quali').style.cssText = isRaces ? inactiveStyle : activeStyle;
    },
    switchSeason(n, context) {
        currentSeason = n;
        if (context === 'archive') {
            splitSubscribed[currentSplit].archive = false;
            subscribeArchive(currentSplit);
        } else if (context === 'gallery') {
            gallerySubscribed = false;
            window._currentAlbumId = null;
            this.closeAlbum();
            subscribeGallery();
        } else if (context === 'standings') {
            splitSubscribed[currentSplit].standings = false;
            subscribeStandings(currentSplit);
        }
    },
    switchSeasonSplit(value, context) {
        const [s, sp] = value.split('-').map(Number);
        currentSeason = s;
        if (currentSplit !== sp) {
            currentSplit = sp;
            adminSplit = sp;
            subscribeStandings(sp);
            subscribeLastRace(sp);
            subscribeTeamsInfo(sp);
            document.getElementById('nav-split1-btn')?.classList.toggle('active', sp === 1);
            document.getElementById('nav-split2-btn')?.classList.toggle('active', sp === 2);
            document.querySelector('.split-toggle-wrap')?.classList.toggle('split-2-active', sp === 2);
            applyHeroConfig(sp);
            this._applySplitView();
        }
        if (context === 'archive') {
            splitSubscribed[currentSplit].archive = false;
            subscribeArchive(currentSplit);
        } else if (context === 'gallery') {
            gallerySubscribed = false;
            window._currentAlbumId = null;
            this.closeAlbum();
            subscribeGallery();
        } else if (context === 'standings') {
            splitSubscribed[currentSplit].standings = false;
            subscribeStandings(currentSplit);
        }
                document.querySelectorAll('.season-split-select').forEach(sel => { sel.value = value; });
    },

     
    switchRaceTab(context, tab, btn) {
        if (context === 'last') {
            document.querySelectorAll('#last-race-tabs .race-tab-btn').forEach(b => b.classList.remove('active'));
            document.querySelectorAll('[id^="last-race-tab-"]').forEach(p => {
                if (p.id === 'last-race-tab-' + tab) return;
                if (p.classList.contains('active')) {
                    p.classList.remove('active');
                    p.classList.add('leaving');
                    p.addEventListener('animationend', function handler() {
                        p.classList.remove('leaving');
                        p.removeEventListener('animationend', handler);
                    }, { once: true });
                }
            });
            const pane = document.getElementById('last-race-tab-' + tab);
            if (pane) { pane.classList.remove('leaving'); pane.classList.add('active'); }
        }
        if (btn) btn.classList.add('active');
    },

     
    switchSplit(n) {
        if (currentSplit === n) return;

         
        const fxLabel = document.getElementById('split-fx-label');
        if (fxLabel) fxLabel.textContent = 'SPLIT ' + n;
        const fxLogo = document.getElementById('split-fx-logo');
        if (fxLogo) fxLogo.style.boxShadow = n === 2 ? '0 0 70px rgba(0,120,255,0.55)' : '0 0 70px rgba(225,6,0,0.55)';
        const fx = document.getElementById('split-transition-fx');
        if (fx) {
            fx.classList.remove('firing');
            fx.classList.toggle('split2', n === 2);
            void fx.offsetWidth;
            fx.classList.add('firing');
        }
       const shakeTarget = document.getElementById('main-app');
        if (shakeTarget) {
            shakeTarget.classList.remove('split-shaking');
            void shakeTarget.offsetWidth;
            shakeTarget.classList.add('split-shaking');
            setTimeout(() => shakeTarget.classList.remove('split-shaking'), 300);
        }

         
        document.querySelector('.split-toggle-wrap')?.classList.toggle('split-2-active', n === 2);
        document.getElementById('nav-split1-btn').classList.toggle('active', n === 1);
        document.getElementById('nav-split2-btn').classList.toggle('active', n === 2);

         
        const mainContent = document.querySelector('.main-content');
        const hero = document.querySelector('.f1-hero');
        mainContent?.classList.add('split-fading');
        hero?.classList.add('split-fading');

       setTimeout(() => {
		document.body.classList.toggle('split2-mode', n === 2);
            currentSplit = n;
            adminSplit = n;
             
            document.getElementById('adm-split1-btn')?.classList.toggle('active', n === 1);
            document.getElementById('adm-split2-btn')?.classList.toggle('active', n === 2);
             
            subscribeStandings(n);
            subscribeLastRace(n);
            subscribeTeamsInfo(n);
            const archiveView = document.getElementById('view-archive');
            if (archiveView && archiveView.classList.contains('active')) subscribeArchive(n);
            applyHeroConfig(n);
            this._applySplitView();

            mainContent?.classList.remove('split-fading');
            hero?.classList.remove('split-fading');
        }, 330);
    },
   adminSwitchSplit(n) {
        const body = document.querySelector('.admin-body');
        if (body) { body.classList.remove('admin-body-flash'); void body.offsetWidth; body.classList.add('admin-body-flash'); }
        adminSplit = n;
        document.getElementById('adm-split1-btn').classList.toggle('active', n === 1);
        document.getElementById('adm-split2-btn').classList.toggle('active', n === 2);
        const split2SoonToc = document.querySelector('a.split-only-toc[href="#sec-split2soon"]');
        if (split2SoonToc) split2SoonToc.style.display = n === 2 ? '' : 'none';
        const split2sec = document.getElementById('sec-split2soon');
        if (split2sec) split2sec.style.display = n === 2 ? '' : 'none';
        const splitPath = n === 1 ? 'split1' : 'split2';
        const sd = splitDataCache[n].standings;
        if (sd) {
            const driversRaw = document.getElementById('adm-drivers-raw');
            const teamsRaw = document.getElementById('adm-teams-raw');
            if (driversRaw && sd.drivers) driversRaw.value = sd.drivers.map(d => `${d.isBot ? 'BOT:' : (d.isReserve ? 'REZ:' : '')}${d.nick} | ${d.team} | ${d.photo || ''} | ${d.wins || 0} | ${d.pts || 0}`).join('\n');
            if (teamsRaw && sd.teams) teamsRaw.value = sd.teams.map(t => `${t.team} | ${t.pts}`).join('\n');
        }
        subscribeArchive(n);
        buildAdmArchiveManager();
        buildTeamsAdminList();
        buildRaceNickChips();
        ui.updateGpPreview(n);
        ui.refreshRaceTitleSuggestion();
        if (n === 2) {
            const tog = document.getElementById('adm-split2-soon-toggle');
            if (tog) tog.checked = !!split2SoonMode;
        }
    },
    _applySplitView() {
        const n = currentSplit;
        const isSoon = n === 2 && split2SoonMode && !isLoggedIn;
        const overlay = document.getElementById('split2-soon-overlay');
        if (overlay) overlay.classList.toggle('visible', isSoon);
        if (!isSoon) {
            archiveDataCache = splitDataCache[n].archive;
            lastRaceDataCache = splitDataCache[n].lastRace;
            teamsInfoData = splitDataCache[n].teamsInfo || {};
            rerenderLastRace();
            rerenderArchive();
            renderStandings();
            if (document.getElementById('view-teams').classList.contains('active')) renderTeamsPage();
        }
    },

     
    async openDriverProfile(nick) {
        if (!nick || nick === '—' || nick.trim() === '') return;

         
        const overlay = document.getElementById('driver-profile-overlay');
        overlay.classList.add('open');
        document.body.style.overflow = 'hidden';
        overlay.scrollTop = 0;
         
        document.getElementById('dp-nick-display').textContent = nick;
        document.getElementById('dp-team-display').textContent = '…';
        document.getElementById('dp-top-bar').style.background = 'var(--f1-red)';
        document.getElementById('driver-profile-modal').style.background = '';
        document.getElementById('dp-left-accent').style.background = 'var(--f1-red)';
        document.getElementById('dp-team-dot').style.background = 'var(--f1-red)';
        document.getElementById('dp-logo-wrap').innerHTML = '';
        document.getElementById('dp-number-bg').textContent = '';
        ['dp-stat-races','dp-stat-pts','dp-stat-wins','dp-stat-podiums','dp-stat-best','dp-stat-avg','dp-stat-fl','dp-stat-pp'].forEach(id => {
            const el = document.getElementById(id); if(el) el.textContent = '…';
        });
        document.getElementById('dp-races-content').innerHTML = `<div style="text-align:center;padding:60px;font-family:var(--font-display);font-size:26px;color:var(--f1-red);letter-spacing:4px;text-transform:uppercase;animation:splashPulse 1.5s ease infinite;">Ładowanie...</div>`;

         
        if (!splitSubscribed[currentSplit].archive) {
            await new Promise(resolve => {
                const sp = currentSplit === 1 ? 'split1' : 'split2';
                splitSubscribed[currentSplit].archive = true;
                let resolved = false;
                onValue(ref(db, sp + '/archive'), snap => {
                    const d = snap.val();
                    splitDataCache[currentSplit].archive = d || {};
                    archiveDataCache = splitDataCache[currentSplit].archive;
                    rerenderArchive();
                    buildAdmArchiveManager();
                    if (!resolved) { resolved = true; resolve(); }
                });
            });
        } else {
             
            archiveDataCache = splitDataCache[currentSplit].archive;
        }

         
        const arcEntries = Object.values(archiveDataCache)
            .filter(race => !race.isQualifying)
            .sort((a, b) => {
                const ao = a.order, bo = b.order;
                if (ao !== undefined && bo !== undefined) return ao - bo;
                if (ao !== undefined) return -1; if (bo !== undefined) return 1;
                return (a.timestamp || 0) - (b.timestamp || 0);
            });

        const arcEntriesReversed = [...arcEntries].reverse();

const allRaces = [];
arcEntriesReversed.forEach(race => {
    if (race.isNoHistory || race.isNoStats) return;
    if (race.results) {
        const r = race.results.find(r => (r.nick || '').toLowerCase() === nick.toLowerCase());
        if (r) allRaces.push({ raceName: race.name || 'Wyścig', _excludeFromCalc: !!race.isNoProfileStats, ...r });
    }
});

        let totalPts = 0, wins = 0, podiums = 0, bestPos = Infinity, posSum = 0, posCount = 0;
        let fastestLaps = 0, polePositions = 0;

const globalFastRaceIndices = new Set();
arcEntries.forEach(race => {
    if (!race.results || race.isNoHistory || race.isNoStats || race.isNoProfileStats) return;
            const fastInRace = findFastestLapIdx(race.results);
            if (fastInRace === -1) return;
            const fastNick = (race.results[fastInRace].nick || '').toLowerCase();
            if (fastNick === nick.toLowerCase()) {
                const raceIdx = allRaces.findIndex(r => r.raceName === (race.name || 'Wyścig'));
                if (raceIdx !== -1) globalFastRaceIndices.add(raceIdx);
            }
        });

allRaces.forEach((r, i) => {
    if (r._excludeFromCalc) return;  
    totalPts += (parseInt(r.pts) || 0);
    const pos = parseInt(r.pos);
    if (!isNaN(pos) && pos > 0) {
        if (pos === 1) wins++;
        if (pos <= 3) podiums++;
        if (pos < bestPos) bestPos = pos;
        posSum += pos; posCount++;
    }
    if (globalFastRaceIndices.has(i)) fastestLaps++;
    const startPos = parseInt((r.start || '').toString().replace(/^(Start:)?\s*/i, '').trim());
    if (startPos === 1) polePositions++;
});
const avgPos = posCount > 0 ? (posSum / posCount).toFixed(1) : '—';
const raceCountForStats = allRaces.filter(r => !r._excludeFromCalc).length;

        const teamName = getDriverCurrentTeam(nick);
        const teamColor = getTeamColorByName(teamName);
        const teamDef = TEAM_DEFS.find(t => t.label.toLowerCase() === teamName.toLowerCase());
        const logoUrl = teamDef ? (teamLogos[teamDef.key] || '') : '';

         
        document.getElementById('dp-top-bar').style.background = teamColor;
        document.getElementById('driver-profile-modal').style.background = 'linear-gradient(160deg, ' + teamColor + '66 0%, ' + teamColor + '1a 38%, transparent 72%), #15151e';
        document.getElementById('dp-left-accent').style.background = teamColor;
        document.getElementById('dp-team-dot').style.background = teamColor;
        document.getElementById('dp-team-badge').style.borderColor = teamColor + '44';

        const isDriverBot = isRealF1Driver(nick) || (splitDataCache[currentSplit].standings?.drivers || []).find(d => d.nick.toLowerCase() === nick.toLowerCase())?.isBot;
        const nickEl = document.getElementById('dp-nick-display');
        if (nickEl) nickEl.innerHTML = nick + (isDriverBot ? ' <span style="display:inline-block;background:rgba(255,255,255,0.18);color:rgba(255,255,255,0.75);font-size:0.35em;font-family:var(--font-data);font-weight:800;letter-spacing:3px;padding:3px 10px;border-radius:3px;vertical-align:middle;margin-left:10px;border:1px solid rgba(255,255,255,0.25);">BOT AI</span>' : '');
        document.getElementById('dp-team-display').textContent = teamName || 'Nieznany zespół';
        document.getElementById('dp-number-bg').textContent = posCount > 0 ? String(Math.round(posSum / posCount)) : '?';

        const logoWrap = document.getElementById('dp-logo-wrap');
        logoWrap.innerHTML = logoUrl
            ? `<img class="dp-team-logo" src="${logoUrl}" alt="${teamName}" onerror="this.style.display='none'">`
            : '';

animateCountUp(document.getElementById('dp-stat-races'), raceCountForStats, 800);
        animateCountUp(document.getElementById('dp-stat-pts'), totalPts, 900);
        animateCountUp(document.getElementById('dp-stat-wins'), wins, 700);
        animateCountUp(document.getElementById('dp-stat-podiums'), podiums, 750);
        document.getElementById('dp-stat-best').textContent = bestPos === Infinity ? '—' : bestPos;
        document.getElementById('dp-stat-avg').textContent = avgPos;
        animateCountUp(document.getElementById('dp-stat-fl'), fastestLaps, 700);
        animateCountUp(document.getElementById('dp-stat-pp'), polePositions, 700);

        const content = document.getElementById('dp-races-content');
        const visibleRaces = allRaces.map((r, i) => ({ r, i }));
        if (visibleRaces.length === 0) {
            content.innerHTML = `<div class="dp-no-races"><span>🏁</span>Brak danych wyścigowych dla tego gracza</div>`;
        } else {
            const posC = (pos) => { const p=parseInt(pos); if(p===1)return 'pos-gold'; if(p===2)return 'pos-silver'; if(p===3)return 'pos-bronze'; return ''; };
            const clean = (val) => (val || '').toString().replace(/^(Start:|Pit:)\s*/i, '').trim() || '—';
            content.innerHTML = `<div style="overflow-x:auto;">
            <table class="dp-race-table">
                <thead><tr>
                    <th>Wyścig</th>
                    <th style="text-align:center;width:60px;">P</th>
                    <th>Zespół</th>
                    <th style="text-align:center;width:60px;">Grid</th>
                    <th style="text-align:center;width:60px;">Pit</th>
                    <th>Najl. okrążenie</th>
                    <th>Czas / Status</th>
                    <th style="text-align:right;padding-right:30px;">PKT</th>
                </tr></thead>
                <tbody>${visibleRaces.map(({ r, i }) => {
                    const isFast = globalFastRaceIndices.has(i);
                    const tColor = getTeamColorByName(r.team);
return `<tr${r._excludeFromCalc ? ' style="opacity:0.55;"' : ''}>
                        <td class="dp-race-name-cell">${r.raceName}${r._excludeFromCalc ? ' <span style="font-size:11px;color:#888;">[poza statystykami]</span>' : ''}</td>
                        <td class="dp-pos-cell ${posC(r.pos)}" style="text-align:center;">${r.pos || '—'}</td>
                        <td style="color:${tColor};font-weight:700;">${r.team || '—'}</td>
                        <td style="text-align:center;color:rgba(255,255,255,0.6);">${clean(r.start)}</td>
                        <td style="text-align:center;color:rgba(255,255,255,0.6);">${clean(r.pit)}</td>
                        <td class="${isFast ? 'dp-fastest-cell' : ''}">${r.best || '—'}${isFast ? ' ' : ''}</td>
                        <td style="color:rgba(255,255,255,0.65);">${r.time || '—'}</td>
                        <td class="dp-pts-cell">${parseInt(r.pts) || 0}</td>
                    </tr>`;
                }).join('')}</tbody>
            </table></div>`;
        }
    },

    closeDriverProfile(event, force) {
        if (force || (event && event.target === document.getElementById('driver-profile-overlay'))) {
            document.getElementById('driver-profile-overlay').classList.remove('open');
            document.body.style.overflow = '';
        }
    },

    editTeamField(el, teamKey, fieldKey) {
        if (!isLoggedIn) return;
        const current = el.textContent.trim();
        const isDesc = fieldKey === 'desc';
        const input = document.createElement(isDesc ? 'textarea' : 'input');
        if (!isDesc) input.type = 'text';
        input.value = current;
        const baseStyle = 'font-family:var(--font-data);font-weight:600;color:#fff;background:rgba(255,255,255,0.15);border:none;border-bottom:2px solid rgba(255,255,255,0.7);outline:none;width:100%;border-radius:3px;padding:4px 6px;';
        input.style.cssText = isDesc ? baseStyle + 'font-size:18px;resize:none;min-height:60px;' : baseStyle + 'font-size:24px;';
        el.replaceWith(input); input.focus(); if (!isDesc) input.select();
        const save = async () => {
            const newVal = input.value.trim() || current;
            const span = document.createElement('span');
            span.className = 'tpc-editable'; span.textContent = newVal;
            span.onclick = () => ui.editTeamField(span, teamKey, fieldKey);
            input.replaceWith(span);
            const update_obj = {}; update_obj[fieldKey] = newVal;
            if (!teamsInfoData[teamKey]) teamsInfoData[teamKey] = {};
            teamsInfoData[teamKey][fieldKey] = newVal;
            await update(ref(db, getSplitPathView() + '/teamsInfo/' + teamKey), update_obj);
        };
        input.addEventListener('blur', save);
        input.addEventListener('keydown', e => { if (!isDesc && e.key === 'Enter') input.blur(); if (e.key === 'Escape') { input.value = current; input.blur(); } });
    },

    editArcCell(el, raceId, rowIdx, field) {
        if (!isLoggedIn) return;
        const arcPath = seasonArchivePath(currentSplit);
        const current = el.textContent.trim();
        const input = document.createElement('input');
        input.type = 'text'; input.value = current;
        input.style.cssText = 'width:110px;font-family:var(--font-display);font-size:22px;font-weight:900;color:var(--f1-red);background:transparent;border:none;border-bottom:2px solid var(--f1-red);text-align:center;outline:none;';
        el.replaceWith(input); input.focus(); input.select();
        let saved = false;
        const save = async () => {
            if (saved) return; saved = true;
            const newVal = input.value.trim();
            const span = document.createElement('span'); span.className = 'arc-cell-editable'; span.textContent = newVal;
            span.onclick = () => ui.editArcCell(span, raceId, rowIdx, field);
            if (input.parentNode) input.replaceWith(span);
            try {
                const s = await new Promise(res => onValue(ref(db, arcPath + '/' + raceId), res, { onlyOnce: true }));
                const data = s.val();
                if (data && Array.isArray(data.results) && data.results[rowIdx] !== undefined) {
                    data.results[rowIdx][field] = newVal;
                    await set(ref(db, arcPath + '/' + raceId + '/results'), data.results);
                }
            } catch(e) { console.error('Błąd zapisu arc:', e); }
        };
        input.addEventListener('keydown', e => {
            if (e.key === 'Enter') { e.preventDefault(); e.stopPropagation(); save(); }
            if (e.key === 'Escape') { saved = true; input.value = current; const span = document.createElement('span'); span.className = 'arc-cell-editable'; span.textContent = current; span.onclick = () => ui.editArcCell(span, raceId, rowIdx, field); if (input.parentNode) input.replaceWith(span); }
        });
        input.addEventListener('blur', save);
    },

    editLastRaceCell(el, rowIdx, field) {
        if (!isLoggedIn) return;
        const splitPath = getSplitPathView();
        const current = el.textContent.trim();
        const input = document.createElement('input');
        input.type = 'text'; input.value = current;
        input.style.cssText = 'width:110px;font-family:var(--font-display);font-size:22px;font-weight:900;color:var(--f1-red);background:transparent;border:none;border-bottom:2px solid var(--f1-red);text-align:center;outline:none;';
        el.replaceWith(input); input.focus(); input.select();
        let saved = false;
        const save = async () => {
            if (saved) return; saved = true;
            const newVal = input.value.trim();
            const span = document.createElement('span'); span.className = 'arc-cell-editable'; span.textContent = newVal;
            span.onclick = () => ui.editLastRaceCell(span, rowIdx, field);
            if (input.parentNode) input.replaceWith(span);
            try {
                const s = await new Promise(res => onValue(ref(db, splitPath + '/lastRace'), res, { onlyOnce: true }));
                const data = s.val();
                if (data && Array.isArray(data.results) && data.results[rowIdx] !== undefined) {
                    data.results[rowIdx][field] = newVal;
                    await set(ref(db, splitPath + '/lastRace/results'), data.results);
                }
            } catch(e) { console.error('Błąd zapisu lastRace:', e); }
        };
        input.addEventListener('blur', save);
        input.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); input.blur(); } if (e.key === 'Escape') { saved = true; input.value = current; input.blur(); } });
    },

    openAlbum(id) {
        document.getElementById('gallery-albums').classList.add('hidden');
        document.getElementById('gallery-viewer').classList.remove('hidden');
        window._currentAlbumId = id;
        const album = window.galleryData[id];
        const titleEl = document.getElementById('gallery-viewer-title');
        if (isLoggedIn) {
            titleEl.innerHTML = `<span class="album-viewer-title-editable">${album.name}</span>`;
            titleEl.querySelector('span').onclick = () => ui.editAlbumName(id, album.name, titleEl.querySelector('span'));
        } else { titleEl.textContent = album.name; }
        const grid = document.getElementById('album-content-grid');
        const entries = album.entries ? Object.entries(album.entries) : [];
        const addEntryTile = isLoggedIn ? `
            <div class="media-entry" style="display:flex;align-items:center;justify-content:center;cursor:pointer;min-height:200px;background:#f0f0f2;" onclick="ui.quickAddEntry('${id}')">
                <div style="font-family:var(--font-display);font-size:70px;color:#bbb;">＋</div>
            </div>` : '';
        if (entries.length === 0) { grid.innerHTML = addEntryTile + (isLoggedIn ? '' : '<p style="font-family:var(--font-data);font-size:30px;color:#999;letter-spacing:1px;">Brak wpisów w tym albumie.</p>'); return; }
        grid.innerHTML = addEntryTile + entries.map(([entryId, entry]) => {
            let mediaHtml = '';
            const src = entry.src || '';
            if (entry.type === 'youtube') {
                const ytId = extractYtId(src);
                mediaHtml = `<iframe src="https://www.youtube-nocookie.com/embed/${ytId}?rel=0&modestbranding=1" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>`;
            } else if (entry.type === 'upload' || src.startsWith('data:')) {
                mediaHtml = `<video controls preload="metadata" style="width:100%;height:100%;object-fit:contain;"><source src="${src}"></video>`;
            } else if (entry.type === 'url') {
                const cleanSrc = src.split('?')[0].toLowerCase();
                if (src.includes('youtu.be') || src.includes('youtube.com')) {
                    const ytId = extractYtId(src);
                    mediaHtml = `<iframe src="https://www.youtube-nocookie.com/embed/${ytId}?rel=0&modestbranding=1" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>`;
                } else if (src.includes('streamable.com')) {
                    const streamId = src.replace(/.*streamable\.com\/(e\/)?/, '').split('?')[0];
                    mediaHtml = `<iframe src="https://streamable.com/e/${streamId}" frameborder="0" allowfullscreen></iframe>`;
                } else if (src.includes('drive.google.com')) {
                    let fileId = ''; const m1 = src.match(/\/d\/([^/\?&]+)/); const m2 = src.match(/[?&]id=([^&]+)/);
                    if (m1) fileId = m1[1]; else if (m2) fileId = m2[1];
                    mediaHtml = fileId ? `<iframe src="https://drive.google.com/file/d/${fileId}/preview" allowfullscreen></iframe>` : `<video controls preload="metadata" style="width:100%;height:100%;object-fit:contain;"><source src="${src}"></video>`;
                } else if (src.includes('medal.tv')) {
                    let medalId = '';
                    const mGames = src.match(/medal\.tv\/games\/[^\/]+\/clips\/([^\/\?&#]+)/);
                    const mClips = src.match(/medal\.tv\/clips?\/([^\/\?&#]+)/);
                    if (mGames) medalId = mGames[1];
                    else if (mClips) medalId = mClips[1];
                    if (medalId) {
                        mediaHtml = `<iframe src="https://medal.tv/clip/${medalId}/auto?loop=0&autostart=0" frameborder="0" allow="autoplay; fullscreen" allowfullscreen></iframe>`;
                    } else {
                        mediaHtml = `<div style="display:flex;align-items:center;justify-content:center;height:100%;background:#111;"><a href="${src}" target="_blank" rel="noopener" style="color:var(--f1-red);font-family:var(--font-display);font-size:28px;letter-spacing:2px;text-decoration:none;">▶ OTWÓRZ NA MEDAL.TV</a></div>`;
                    }
                } else if (/\.(jpg|jpeg|png|gif|webp|svg|bmp)(\?.*)?$/.test(cleanSrc)) {
                    mediaHtml = `<img src="${src}" alt="${entry.title || ''}" style="width:100%;height:100%;object-fit:cover;">`;
                } else {
                    mediaHtml = `<video controls preload="metadata" style="width:100%;height:100%;object-fit:contain;"><source src="${src}" type="video/mp4"></video>`;
                }
            } else {
                mediaHtml = `<img src="${src}" alt="${entry.title || ''}" style="width:100%;height:100%;object-fit:cover;">`;
            }
            const deleteBtn = isLoggedIn ? `<button class="btn-action btn-danger btn-sm" style="position:absolute;top:10px;right:10px;z-index:10;" onclick="dbCore.deleteNode('${seasonGalleryPath()}/${id}/entries/${entryId}');ui.openAlbum('${id}')">✕</button>` : '';
            const entryTitleHtml = isLoggedIn
                ? `<div class="media-entry-title"><span class="arc-cell-editable" onclick="ui.editEntryTitle(this,'${id}','${entryId}')">${entry.title || 'Wpis'}</span></div>`
                : (entry.title ? `<div class="media-entry-title">${entry.title}</div>` : '');
            return `<div class="media-entry">${entryTitleHtml}<div class="media-entry-body" style="position:relative;">${mediaHtml}${deleteBtn}</div></div>`;
        }).join('');
    },
	quickAddEntry(albumId) {
        if (!isLoggedIn) return;
        ui.openGalleryModal('entry', albumId);
    },
    editAlbumName(id, currentName, el) {
        if (!isLoggedIn) return;
        const input = document.createElement('input'); input.type = 'text'; input.value = currentName;
        input.style.cssText = 'font-family:var(--font-display);font-size:44px;font-weight:900;letter-spacing:2px;color:var(--f1-black);background:transparent;border:none;border-bottom:3px solid var(--f1-red);outline:none;width:100%;text-transform:uppercase;';
        el.replaceWith(input); input.focus(); input.select();
        const save = async () => { const nv = input.value.trim() || currentName; await update(ref(db, seasonGalleryPath() + '/' + id), { name: nv }); if (window.galleryData && window.galleryData[id]) window.galleryData[id].name = nv; };
        input.addEventListener('blur', save);
        input.addEventListener('keydown', e => { if (e.key === 'Enter') input.blur(); if (e.key === 'Escape') { input.value = currentName; input.blur(); } });
    },
    editEntryTitle(el, albumId, entryId) {
        if (!isLoggedIn) return;
        const current = el.textContent.trim();
        const input = document.createElement('input'); input.type = 'text'; input.value = current;
        input.style.cssText = 'font-family:var(--font-data);font-size:30px;font-weight:700;color:var(--f1-red);background:transparent;border:none;border-bottom:2px solid var(--f1-red);outline:none;width:100%;letter-spacing:1px;';
        el.replaceWith(input); input.focus(); input.select();
        const save = async () => {
            const nv = input.value.trim() || current;
            const span = document.createElement('span'); span.className = 'arc-cell-editable'; span.textContent = nv;
            span.onclick = () => ui.editEntryTitle(span, albumId, entryId);
            input.replaceWith(span);
await update(ref(db, `${seasonGalleryPath()}/${albumId}/entries/${entryId}`), { title: nv });
        };
        input.addEventListener('blur', save);
        input.addEventListener('keydown', e => { if (e.key === 'Enter') input.blur(); if (e.key === 'Escape') { input.value = current; input.blur(); } });
    },
    closeAlbum() { document.getElementById('gallery-albums').classList.remove('hidden'); document.getElementById('gallery-viewer').classList.add('hidden'); },
    switchMediaType(type) {
        document.getElementById('media-input-youtube').classList.toggle('hidden', type !== 'youtube');
        document.getElementById('media-input-url').classList.toggle('hidden', type !== 'url');
        document.getElementById('media-input-upload').classList.toggle('hidden', type !== 'upload');
    },
    async editCell(el, dbPath, type, idx, field) {
        if (!isLoggedIn) return;
        const current = el.textContent.trim();
        const input = document.createElement('input'); input.type = 'text'; input.value = current;
        input.style.cssText = 'width:80px;font-family:var(--font-display);font-size:22px;font-weight:900;color:var(--f1-red);background:transparent;border:none;border-bottom:2px solid var(--f1-red);text-align:center;outline:none;';
        el.replaceWith(input); input.focus(); input.select();
        let saved = false;
        const save = async () => {
            if (saved) return; saved = true;
            const newVal = input.value.trim();
            const span = document.createElement('span'); span.className = 'editable-cell'; span.textContent = newVal;
            span.onclick = () => ui.editCell(span, dbPath, type, idx, field);
            if (input.parentNode) input.replaceWith(span);
        };
        input.addEventListener('blur', save);
        input.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); save(); } if (e.key === 'Escape') { saved = true; input.value = current; const span = document.createElement('span'); span.className = 'editable-cell'; span.textContent = current; span.onclick = () => ui.editCell(span, dbPath, type, idx, field); input.replaceWith(span); } });
    },
    async editLastRaceName() {
        if (!isLoggedIn) return;
        const splitPath = getSplitPathView();
        const titleEl = document.getElementById('display-last-race-name');
        const snap = await new Promise(res => onValue(ref(db, splitPath + '/lastRace'), res, { onlyOnce: true }));
        const data = snap.val(); if (!data) return;
        const current = data.name || '';
        const input = document.createElement('input'); input.type = 'text'; input.value = current;
        input.style.cssText = 'font-family:var(--font-display);font-size:34px;font-weight:900;letter-spacing:1px;color:var(--f1-black);background:transparent;border:none;border-bottom:3px solid var(--f1-red);outline:none;width:100%;';
        const existingSpan = titleEl.querySelector('span');
        if (existingSpan) existingSpan.replaceWith(input);
        else { titleEl.textContent = 'WYNIKI: '; titleEl.appendChild(input); }
        input.focus(); input.select();
        const save = async () => { const newVal = input.value.trim(); await update(ref(db, splitPath + '/lastRace'), { name: newVal }); };
        input.addEventListener('blur', save);
        input.addEventListener('keydown', e => { if (e.key === 'Enter') input.blur(); if (e.key === 'Escape') { input.value = current; input.blur(); } });
    },
	    async deleteDriverFromStandings(idx) {
        if (!confirm('Usunąć tego kierowcę z klasyfikacji?')) return;
        const sp = seasonStandingsPath(currentSplit);
        const snap = await new Promise(res => onValue(ref(db, sp), res, { onlyOnce: true }));
        const data = snap.val();
        if (!data || !Array.isArray(data.drivers)) return;
        data.drivers.splice(idx, 1);
        await set(ref(db, sp), data);
    },
	async toggleReserveDriver(idx) {
    const sp = seasonStandingsPath(currentSplit);
    const snap = await new Promise(res => onValue(ref(db, sp), res, { onlyOnce: true }));
    const data = snap.val();
    if (!data || !Array.isArray(data.drivers) || !data.drivers[idx]) return;
    data.drivers[idx].isReserve = !data.drivers[idx].isReserve;
    await set(ref(db, sp), data);
},
    async editArchiveName(id, currentName) {
        if (!isLoggedIn) return;
        const arcPath = seasonArchivePath(currentSplit);
        const nameEl = document.getElementById('arc-name-' + id); if (!nameEl) return;
        const input = document.createElement('input'); input.type = 'text'; input.value = currentName;
        input.style.cssText = 'font-family:var(--font-data);font-size:46px;font-weight:700;letter-spacing:1px;color:var(--f1-black);background:transparent;border:none;border-bottom:3px solid var(--f1-red);outline:none;flex:1;text-transform:uppercase;';
        nameEl.replaceWith(input); input.focus(); input.select();
        const save = async () => { const nv=input.value.trim(); await update(ref(db, arcPath + '/'+id),{name:nv}); };
        input.addEventListener('blur', save);
        input.addEventListener('keydown', e => { if (e.key==='Enter') input.blur(); if (e.key==='Escape'){input.value=currentName;input.blur();} });
    },
    replayStandingsCountUp() {
        runCountUps(document.getElementById('view-standings'));
    },
    async clearCalendarSlot(round) {
        if (!isLoggedIn) return;
        if (!confirm(`Usunąć tor z Rundy ${round}?`)) return;
        await remove(ref(db, 'calendar/' + round));
    },
    toggleMobileNav() {
        const nav = document.getElementById('f1-main-nav');
        if (nav) nav.classList.toggle('mobile-open');
    },
    async toggleReserveResult(raceId, rowIdx, isLastRace) {
        if (!isLoggedIn) return;
        const splitPath = getSplitPathView();
        const path = raceId ? (seasonArchivePath(currentSplit) + '/' + raceId) : (splitPath + '/lastRace');
        const snap = await new Promise(res => onValue(ref(db, path), res, { onlyOnce: true }));
        const data = snap.val();
        if (!data || !Array.isArray(data.results) || !data.results[rowIdx]) return;
        data.results[rowIdx].isReserve = !data.results[rowIdx].isReserve;
        await set(ref(db, path + '/results'), data.results);
        if (raceId) rerenderArchive(); else rerenderLastRace();
    }
};

 
ui.predictAlbumCover = function(name) {
    const coverInput = document.getElementById('gm-album-cover');
    const suggestionsBox = document.getElementById('gm-cover-suggestions');
    const chipsBox = document.getElementById('gm-cover-chips');
    if (!coverInput || !suggestionsBox || !chipsBox) return;
    const n = (name || '').toLowerCase().trim();
    if (!n) { suggestionsBox.style.display = 'none'; return; }

    const COVER_MAP = [
        { keys: ['australian','australia','albert park'],             url: 'https://www.formula1.com/content/dam/fom-website/2018-redesign-assets/Circuit%20maps%2016x9/Australia_Circuit.png' },
        { keys: ['chinese','china','shanghai'],                       url: 'https://www.formula1.com/content/dam/fom-website/2018-redesign-assets/Circuit%20maps%2016x9/China_Circuit.png' },
        { keys: ['japanese','japan','suzuka'],                        url: 'https://www.formula1.com/content/dam/fom-website/2018-redesign-assets/Circuit%20maps%2016x9/Japan_Circuit.png' },
        { keys: ['bahrain','sakhir'],                                 url: 'https://www.formula1.com/content/dam/fom-website/2018-redesign-assets/Circuit%20maps%2016x9/Bahrain_Circuit.png' },
        { keys: ['saudi','arabia','jeddah'],                          url: 'https://www.formula1.com/content/dam/fom-website/2018-redesign-assets/Circuit%20maps%2016x9/Saudi_Arabia_Circuit.png' },
        { keys: ['miami'],                                            url: 'https://www.formula1.com/content/dam/fom-website/2018-redesign-assets/Circuit%20maps%2016x9/Miami_Circuit.png' },
        { keys: ['madrid'],                                           url: 'https://media.formula1.com/image/upload/c_fit,h_704/q_auto/v1740000001/common/f1/2026/track/2026trackmadringdetailed.webp' },
        { keys: ['monaco','monte carlo'],                             url: 'https://www.formula1.com/content/dam/fom-website/2018-redesign-assets/Circuit%20maps%2016x9/Monaco_Circuit.png' },
        { keys: ['spanish','spain','barcelona','catalunya'],          url: 'https://www.formula1.com/content/dam/fom-website/2018-redesign-assets/Circuit%20maps%2016x9/Spain_Circuit.png' },
        { keys: ['canadian','canada','montreal','villeneuve'],        url: 'https://www.formula1.com/content/dam/fom-website/2018-redesign-assets/Circuit%20maps%2016x9/Canada_Circuit.png' },
        { keys: ['austrian','austria','spielberg','red bull ring'],   url: 'https://www.formula1.com/content/dam/fom-website/2018-redesign-assets/Circuit%20maps%2016x9/Austria_Circuit.png' },
        { keys: ['british','britain','silverstone'],                  url: 'https://www.formula1.com/content/dam/fom-website/2018-redesign-assets/Circuit%20maps%2016x9/Great_Britain_Circuit.png' },
        { keys: ['belgian','belgium','spa','francorchamps'],          url: 'https://www.formula1.com/content/dam/fom-website/2018-redesign-assets/Circuit%20maps%2016x9/Belgium_Circuit.png' },
        { keys: ['hungarian','hungary','hungaroring','budapest'],     url: 'https://www.formula1.com/content/dam/fom-website/2018-redesign-assets/Circuit%20maps%2016x9/Hungary_Circuit.png' },
        { keys: ['dutch','netherlands','zandvoort'],                  url: 'https://www.formula1.com/content/dam/fom-website/2018-redesign-assets/Circuit%20maps%2016x9/Netherlands_Circuit.png' },
        { keys: ['italian','italy','monza'],                          url: 'https://www.formula1.com/content/dam/fom-website/2018-redesign-assets/Circuit%20maps%2016x9/Italy_Circuit.png' },
        { keys: ['azerbaijan','baku'],                                url: 'https://www.formula1.com/content/dam/fom-website/2018-redesign-assets/Circuit%20maps%2016x9/Baku_Circuit.png' },
        { keys: ['singapore','marina bay'],                           url: 'https://www.formula1.com/content/dam/fom-website/2018-redesign-assets/Circuit%20maps%2016x9/Singapore_Circuit.png' },
        { keys: ['united states','usa','austin','cota'],              url: 'https://www.formula1.com/content/dam/fom-website/2018-redesign-assets/Circuit%20maps%2016x9/USA_Circuit.png' },
        { keys: ['mexico','mexico city','hermanos'],                  url: 'https://www.formula1.com/content/dam/fom-website/2018-redesign-assets/Circuit%20maps%2016x9/Mexico_Circuit.png' },
        { keys: ['paulo','sao paulo','brasil','brazil','interlagos'], url: 'https://www.formula1.com/content/dam/fom-website/2018-redesign-assets/Circuit%20maps%2016x9/Brazil_Circuit.png' },
        { keys: ['las vegas','vegas'],                                url: 'https://www.formula1.com/content/dam/fom-website/2018-redesign-assets/Circuit%20maps%2016x9/Las_Vegas_Circuit.png' },
        { keys: ['qatar','losail'],                                   url: 'https://www.formula1.com/content/dam/fom-website/2018-redesign-assets/Circuit%20maps%2016x9/Qatar_Circuit.png' },
        { keys: ['abu dhabi','yas marina','yas'],                     url: 'https://www.formula1.com/content/dam/fom-website/2018-redesign-assets/Circuit%20maps%2016x9/Abu_Dhabi_Circuit.png' },
    ];

    const match = COVER_MAP.find(entry => entry.keys.some(k => n.includes(k)));
    if (!match) { suggestionsBox.style.display = 'none'; return; }

    suggestionsBox.style.display = 'block';
    if (!coverInput.value || coverInput.value.trim() === '') {
        coverInput.value = match.url;
        ui.previewAlbumCoverImg(match.url);
    }
    chipsBox.innerHTML = `<div onclick="document.getElementById('gm-album-cover').value='${match.url}';ui.previewAlbumCoverImg('${match.url}')" style="cursor:pointer;border-radius:4px;overflow:hidden;border:2px solid rgba(255,255,255,0.1);transition:border-color 0.2s;" onmouseover="this.style.borderColor='var(--f1-red)'" onmouseout="this.style.borderColor='rgba(255,255,255,0.1)'">
        <img src="${match.url}" style="width:120px;height:70px;object-fit:cover;display:block;" onerror="this.parentElement.style.display='none'">
    </div>`;
};

ui.previewAlbumCoverImg = function(url) {
    const preview = document.getElementById('gm-cover-preview');
    const img = document.getElementById('gm-cover-img');
    if (!preview || !img) return;
    if (!url || !url.startsWith('http')) { preview.style.display = 'none'; return; }
    img.src = url;
    preview.style.display = 'block';
};
ui.openAddRaceModal = function() {
    if (!isLoggedIn) return;
     
    const suggestion = buildRaceTitleSuggestion(adminSplit);
    const titleInput = document.getElementById('arm-race-title');
    if (titleInput && !titleInput.value) titleInput.value = suggestion || '';
    const suggBox = document.getElementById('arm-title-suggestion-box');
    const suggText = document.getElementById('arm-title-suggestion-text');
    if (suggBox && suggText && suggestion) { suggText.textContent = suggestion; suggBox.style.display = 'flex'; }
     
    ui._buildArmNickChips(null);
    const overlay = document.getElementById('add-race-modal-overlay');
    overlay.classList.add('open');
    document.body.style.overflow = 'hidden';
    setTimeout(() => document.getElementById('arm-race-title')?.focus(), 200);
};

ui.closeAddRaceModal = function(event, force) {
    if (force || (event && event.target === document.getElementById('add-race-modal-overlay'))) {
        document.getElementById('add-race-modal-overlay').classList.remove('open');
        document.body.style.overflow = '';
    }
};

ui.useArmTitleSuggestion = function() {
    const s = buildRaceTitleSuggestion(adminSplit);
    if (s) document.getElementById('arm-race-title').value = s;
};

ui.onArmRawInput = function(textarea) {
    const lines = textarea.value.split('\n').filter(l => l.trim());
     
    const teamsInText = new Set();
    lines.forEach(line => {
        const parsed = parseArmLine(line);
        if (parsed && parsed.team) teamsInText.add(normalizeTeamName(parsed.team));
    });

    if (teamsInText.size === 0) {
        ui._buildArmNickChips(null);
        return;
    }

     
    const cursorPos = textarea.selectionStart;
    const textBefore = textarea.value.substring(0, cursorPos);
    const currentLineText = textBefore.split('\n').pop() || '';
    const currentLineParsed = parseArmLine(currentLineText);
    const currentTeamRaw = currentLineParsed ? currentLineParsed.team : '';
    const currentTeam = currentTeamRaw ? normalizeTeamName(currentTeamRaw) : null;

     
    const ti = splitDataCache[adminSplit].teamsInfo || {};
    const sd = splitDataCache[adminSplit].standings;
    const map = new Map();  

    TEAM_DEFS.forEach(t => {
        const info = ti[t.key];
        if (!info) return;
        [info.driver1, info.driver2].forEach(dn => {
            if (dn && dn.trim()) map.set(dn.toLowerCase(), { nick: dn.trim(), team: t.label });
        });
    });
    (sd?.drivers || []).filter(d => !d.isBot).forEach(d => {
        if (d.nick && !map.has(d.nick.toLowerCase())) map.set(d.nick.toLowerCase(), { nick: d.nick, team: d.team || '' });
    });

    const allPlayers = [...map.values()];

     
    if (currentTeam) {
        const filtered = allPlayers.filter(p => normalizeTeamName(p.team) === currentTeam);
        if (filtered.length > 0) {
            const teamNickMap = { [currentTeam]: filtered.map(p => p.nick) };
            ui._buildArmNickChips(teamNickMap, currentTeam);
            return;
        }
    }

     
    ui._buildArmNickChips(null);
};

ui._buildArmNickChips = function(teamNickMap, activeTeam) {
    const container = document.getElementById('arm-nick-chips');
    const filteredLabel = document.getElementById('arm-filtered-label');
    if (!container) return;

    if (teamNickMap && Object.keys(teamNickMap).length > 0) {
         
if (filteredLabel) {
            filteredLabel.classList.add('visible');
            if (activeTeam) filteredLabel.textContent = `🎯 Kierowcy z zespołu: ${activeTeam}`;
        }
        const allChips = [];
        Object.entries(teamNickMap).forEach(([team, nicks]) => {
            const color = getTeamColorByName(team);
            nicks.forEach(nick => {
                const safeNick = nick.replace(/'/g, "\\'");
                const safeTeam = team.replace(/'/g, "\\'");
                allChips.push(`<span class="arm-nick-chip" onclick="ui.insertArmNick('${safeNick}','${safeTeam}')" style="border-color:${color}33;" title="${team}">
                    <span class="arm-chip-dot" style="background:${color};"></span>
                    ${nick}
                </span>`);
            });
        });
        container.innerHTML = allChips.length
            ? allChips.map((c, i) => `<span style="animation:f1StaggerIn 0.3s ${i * 0.05}s both;">${c}</span>`).join('')
            : '<span style="font-family:var(--font-data);font-size:13px;color:rgba(255,255,255,0.3);">Brak graczy (tylko boty?) w wklejonych danych</span>';
    } else {
         
        if (filteredLabel) filteredLabel.classList.remove('visible');
        const sd = splitDataCache[adminSplit].standings;
        const ti = splitDataCache[adminSplit].teamsInfo || {};
        const map = new Map();
        (sd?.drivers || []).filter(d => !d.isBot).forEach(d => {
            if (d.nick) map.set(d.nick.toLowerCase(), { nick: d.nick, team: d.team || '' });
        });
        TEAM_DEFS.forEach(t => {
            const info = ti[t.key];
            if (!info) return;
            [info.driver1, info.driver2].forEach(dn => {
                if (dn && dn.trim() && !map.has(dn.toLowerCase())) map.set(dn.toLowerCase(), { nick: dn.trim(), team: t.label });
            });
        });
        const list = [...map.values()].sort((a, b) => a.nick.localeCompare(b.nick));
        if (list.length === 0) {
            container.innerHTML = '<span style="font-family:var(--font-data);font-size:13px;color:rgba(255,255,255,0.3);">Brak zapisanych graczy — wklej wyniki żeby zobaczyć filtrowanie</span>';
        } else {
            container.innerHTML = list.map((d, i) => {
                const color = getTeamColorByName(d.team);
                const safeNick = d.nick.replace(/'/g, "\\'");
                const safeTeam = (d.team || '').replace(/'/g, "\\'");
                return `<span style="animation:f1StaggerIn 0.3s ${i * 0.04}s both;display:inline-block;">
                    <span class="arm-nick-chip" onclick="ui.insertArmNick('${safeNick}','${safeTeam}')">
                        <span class="arm-chip-dot" style="background:${color};"></span>
                        ${d.nick}
                    </span>
                </span>`;
            }).join('');
        }
    }
};

ui.insertArmNick = function(nick, team) {
    const ta = document.getElementById('arm-race-raw');
    if (!ta) return;

    const cursorPos = ta.selectionStart;
    const text = ta.value;

     
    const lineStart = text.lastIndexOf('\n', cursorPos - 1) + 1;
    const lineEndRaw = text.indexOf('\n', cursorPos);
    const lineEnd = lineEndRaw === -1 ? text.length : lineEndRaw;
    const currentLine = text.substring(lineStart, lineEnd);
    const trimmedLine = currentLine.trim();

    if (trimmedLine.startsWith('"') && trimmedLine.includes('","')) {
         
        const fields = csvSplit(trimmedLine);
        if (fields.length > 1) fields[1] = nick;
        if (fields.length > 8) fields[8] = nick;
        const newLine = '"' + fields.join('","') + '"';
        ta.value = text.substring(0, lineStart) + newLine + text.substring(lineEnd);
        ta.selectionStart = ta.selectionEnd = lineStart + newLine.length;
    } else if (currentLine.includes('|')) {
         
        const parts = currentLine.split('|');
        parts[0] = nick + ' ';
        const newLine = parts.join('|');
        ta.value = text.substring(0, lineStart) + newLine + text.substring(lineEnd);
         
        const newPos = lineStart + nick.length + 3;
        ta.selectionStart = ta.selectionEnd = Math.min(newPos, lineStart + newLine.length);
    } else {
         
        const prefix = text && !text.endsWith('\n') && text.length > 0 ? '\n' : '';
        ta.value = text + `${prefix}${nick} | ${team} | `;
        ta.selectionStart = ta.selectionEnd = ta.value.length;
    }

    ta.focus();
    ui.onArmRawInput(ta);
};

ui.submitAddRaceModal = async function() {
     
    const copyField = (from, to) => {
        const src = document.getElementById(from);
        const dst = document.getElementById(to);
        if (src && dst) dst.value = src.value;
    };
    const copyCheck = (from, to) => {
        const src = document.getElementById(from);
        const dst = document.getElementById(to);
        if (src && dst) dst.checked = src.checked;
    };
    copyField('arm-race-title', 'adm-race-title');
    copyField('arm-race-raw', 'adm-race-raw');
    copyField('arm-no-bonus-nicks', 'adm-no-bonus-nicks');
    copyCheck('arm-pub-last', 'pub-last');
    copyCheck('arm-pub-archive', 'pub-archive');
    copyCheck('arm-pub-no-stats', 'pub-no-stats');
    copyCheck('arm-pub-no-history', 'pub-no-history');
    copyCheck('arm-pub-qualifying', 'pub-qualifying');
copyField('arm-race-title', 'adm-race-title');
copyField('arm-race-raw', 'adm-race-raw');
copyField('arm-no-bonus-nicks', 'adm-no-bonus-nicks');
copyField('arm-reserve-nicks', 'adm-reserve-nicks');

    ui.closeAddRaceModal(null, true);
    await dbCore.publishRace();

     
    document.getElementById('arm-race-title').value = '';
    document.getElementById('arm-race-raw').value = '';
    document.getElementById('arm-no-bonus-nicks').value = '';
    document.getElementById('arm-pub-last').checked = true;
    document.getElementById('arm-pub-archive').checked = true;
    document.getElementById('arm-pub-no-stats').checked = false;
    document.getElementById('arm-pub-no-history').checked = false;
    document.getElementById('arm-pub-qualifying').checked = false;
	document.getElementById('arm-race-title').value = '';
document.getElementById('arm-race-raw').value = '';
document.getElementById('arm-no-bonus-nicks').value = '';
document.getElementById('arm-reserve-nicks').value = '';
    ui._buildArmNickChips(null);
};

 
let _galleryModalMode = null;
let _galleryModalAlbumId = null;

ui.openGalleryModal = function(mode, albumId, suggested) {
    _galleryModalMode = mode;
    _galleryModalAlbumId = albumId;
    const overlay = document.getElementById('gallery-modal-overlay');
    const body = document.getElementById('gm-body');
    const titleEl = document.getElementById('gm-header-title');
    const iconEl = document.getElementById('gm-header-icon');
    const submitBtn = document.getElementById('gm-submit-btn');

    if (mode === 'album') {
        titleEl.textContent = 'Nowy album';
        iconEl.textContent = '📷';
        submitBtn.textContent = '📷 UTWÓRZ ALBUM';
        body.innerHTML = `
    <div class="gm-form-group">
        <label class="gm-label">Nazwa albumu</label>
        <input type="text" class="gm-input" id="gm-album-name" placeholder="np. GP Monaco 2026" value="${suggested || ''}" style="margin-bottom:0;" oninput="ui.predictAlbumCover(this.value)">
    </div>
    <div class="gm-form-group">
        <label class="gm-label">URL okładki (opcjonalnie)</label>
        <input type="text" class="gm-input" id="gm-album-cover" placeholder="https://example.com/foto.jpg" oninput="ui.previewAlbumCoverImg(this.value)">
        <div id="gm-cover-preview" style="margin-top:10px;display:none;text-align:center;">
            <img id="gm-cover-img" src="" style="max-width:100%;max-height:160px;border-radius:6px;border:1px solid rgba(255,255,255,0.1);object-fit:cover;" onerror="document.getElementById('gm-cover-preview').style.display='none'">
        </div>
        <div id="gm-cover-suggestions" style="margin-top:10px;display:none;">
            <div style="font-family:var(--font-data);font-size:11px;color:rgba(255,255,255,0.35);letter-spacing:2px;text-transform:uppercase;margin-bottom:6px;">Sugerowane okładki:</div>
            <div id="gm-cover-chips" style="display:flex;flex-wrap:wrap;gap:6px;"></div>
        </div>
    </div>`;
if (suggested) setTimeout(() => ui.predictAlbumCover(suggested), 50);
        setTimeout(() => document.getElementById('gm-album-name')?.focus(), 100);
    } else if (mode === 'entry') {
        titleEl.textContent = 'Dodaj wpis do albumu';
        iconEl.textContent = '🎬';
        submitBtn.textContent = '➕ DODAJ WPIS';
        body.innerHTML = `
            <div class="gm-form-group">
                <label class="gm-label">Tytuł wpisu (opcjonalnie)</label>
                <input type="text" class="gm-input" id="gm-entry-title" placeholder="np. Highlights z kwalifikacji">
            </div>
            <div class="gm-form-group">
                <label class="gm-label">Typ mediów</label>
                <div class="gm-type-row">
                    <div class="gm-type-btn active" id="gm-type-youtube" onclick="ui.setGmType('youtube')">▶ YouTube</div>
                    <div class="gm-type-btn" id="gm-type-url" onclick="ui.setGmType('url')">🔗 URL / Streamable / Drive / Medal.tv</div>
                </div>
            </div>
            <div class="gm-form-group" id="gm-src-group">
                <label class="gm-label" id="gm-src-label">Link YouTube</label>
                <input type="text" class="gm-input" id="gm-entry-src" placeholder="https://youtu.be/...">
            </div>`;
        setTimeout(() => document.getElementById('gm-entry-title')?.focus(), 100);
    }

    overlay.classList.add('open');
    document.body.style.overflow = 'hidden';
};

ui.setGmType = function(type) {
    document.querySelectorAll('.gm-type-btn').forEach(b => b.classList.remove('active'));
    const btn = document.getElementById('gm-type-' + type);
    if (btn) btn.classList.add('active');
    const label = document.getElementById('gm-src-label');
    const input = document.getElementById('gm-entry-src');
    if (type === 'youtube') {
        if (label) label.textContent = 'Link YouTube';
        if (input) input.placeholder = 'https://youtu.be/...';
    } else {
        if (label) label.textContent = 'Bezpośredni URL';
        if (input) input.placeholder = 'https://streamable.com/... lub mp4, jpg, drive, medal.tv...';
    }
};

ui.closeGalleryModal = function(event, force) {
    if (force || (event && event.target === document.getElementById('gallery-modal-overlay'))) {
        document.getElementById('gallery-modal-overlay').classList.remove('open');
        document.body.style.overflow = '';
    }
};

ui.submitGalleryModal = async function() {
    const submitBtn = document.getElementById('gm-submit-btn');
    const origText = submitBtn.textContent;
    submitBtn.innerHTML = '<span class="gm-spinner"></span>ZAPISUJĘ...';
    submitBtn.disabled = true;

    try {
        if (_galleryModalMode === 'album') {
            const name = document.getElementById('gm-album-name')?.value?.trim();
            const cover = document.getElementById('gm-album-cover')?.value?.trim() || '';
            if (!name) { ui.showToast('Podaj nazwę albumu.', 'error'); return; }
await push(ref(db, seasonGalleryPath()), { name, cover, entries: {} });
        } else if (_galleryModalMode === 'entry') {
            const title = document.getElementById('gm-entry-title')?.value?.trim() || '';
            const activeTypeBtn = document.querySelector('.gm-type-btn.active');
            const type = activeTypeBtn?.id?.replace('gm-type-', '') || 'youtube';
            const src = document.getElementById('gm-entry-src')?.value?.trim();
            if (!src) { ui.showToast('Podaj URL lub link.', 'error'); return; }
await push(ref(db, `${seasonGalleryPath()}/${_galleryModalAlbumId}/entries`), { title, type, src });
            ui.openAlbum(_galleryModalAlbumId);
        }
        ui.closeGalleryModal(null, true);
        ui.showToast('✓ Zapisano pomyślnie!');
    } finally {
        submitBtn.innerHTML = origText;
        submitBtn.disabled = false;
    }
};

 

window.authCore = {
    login() {
        const email = document.getElementById('field-email').value;
        const pass  = document.getElementById('field-pass').value;
        signInWithEmailAndPassword(auth, email, pass)
            .then(() => ui.toggleAuth(false))
            .catch(err => ui.showToast("Błąd logowania: " + err.message, 'error'));
    },
    logout() { signOut(auth).then(() => location.reload()); }
};

 
function rerenderLastRace() {
    const data = splitDataCache[currentSplit].lastRace;
    lastRaceDataCache = data;
    const titleEl = document.getElementById('display-last-race-name');
    const racePane = document.getElementById('last-race-tab-race');
    const qualiPane = document.getElementById('last-race-tab-quali');
    const tabsBar = document.getElementById('last-race-tabs');
    const qualiTabBtn = document.getElementById('last-tab-quali-btn');

    if (!data) {
        if (racePane) racePane.innerHTML = '<p style="padding:40px;color:#aaa;">Brak danych dla tego splitu.</p>';
        if (titleEl) titleEl.textContent = 'WYNIKI: OSTATNI WYŚCIG';
        if (tabsBar) tabsBar.style.display = 'none';
        updateLastRaceSidebar(null);
        return;
    }

    if (isLoggedIn) {
        titleEl.innerHTML = `WYNIKI: <span class="editable-title" onclick="ui.editLastRaceName()" title="Kliknij aby edytować">${data.name}</span>`;
    } else {
        titleEl.textContent = 'WYNIKI: ' + (data.name || 'OSTATNI WYŚCIG');
    }

     
    if (racePane) {
        racePane.innerHTML = renderRaceTable(data.results, null, true, !!data.isNoStats);
        if (isLoggedIn) setTimeout(() => initRaceRowDragDrop('race-tbl-last', null, true), 50);
    }
    updateLastRaceSidebar(data.results);

     
    const qualiData = data.qualiResults || null;
    if (qualiData && qualiData.length > 0) {
        if (tabsBar) tabsBar.style.display = 'flex';
        if (qualiPane) qualiPane.innerHTML = renderQualiTable(qualiData, null);
    } else {
        if (tabsBar) tabsBar.style.display = 'none';
        if (qualiPane) qualiPane.innerHTML = '';
    }
}

function rerenderArchive() {
    const data = splitDataCache[currentSplit].archive;
    archiveDataCache = data || {};
    if (!data || Object.keys(data).length === 0) {
        const arcList = document.getElementById('api-archive-list');
        const qualiList = document.getElementById('api-quali-list');
        if (arcList) arcList.innerHTML = '';
        if (qualiList) qualiList.innerHTML = '';
        return;
    }
    const entries = Object.entries(data).sort((a, b) => {
        const ao = a[1].order, bo = b[1].order;
        if (ao !== undefined && bo !== undefined) return ao - bo;
        if (ao !== undefined) return -1; if (bo !== undefined) return 1;
        return (b[1].timestamp || 0) - (a[1].timestamp || 0);
    });

    const openIds = new Set();
    document.querySelectorAll('.archive-body.open').forEach(el => {
        const id = el.id.replace('arc-body-', '');
        if (id) openIds.add(id);
    });

    const makeItem = (id, race, isQuali) => {
        const editPart = isLoggedIn
            ? `id="arc-name-${id}" class="arc-edit-name editable-mode" onclick="ui.editArchiveName('${id}', '${(race.name||'').replace(/'/g,"\\'")}')"`
            : `id="arc-name-${id}" class="arc-edit-name"`;
        const isOpen = openIds.has(id);

        let tableHtml;
        if (isQuali) {
            tableHtml = renderQualiTable(race.results, id);
        } else {
             
            const hasQuali = race.qualiResults && race.qualiResults.length > 0;
            if (hasQuali) {
                tableHtml = `
                    <div class="race-tabs" style="margin-bottom:0;">
                        <button class="race-tab-btn active" onclick="ui.switchArcTab(this,'${id}','race')">🏁 WYŚCIG</button>
                        <button class="race-tab-btn" onclick="ui.switchArcTab(this,'${id}','quali')">⏱ KWALIFIKACJE</button>
                    </div>
                    <div id="arc-tab-race-${id}" class="race-tab-pane active">${renderRaceTable(race.results, id, false, !!race.isNoStats)}</div>
                    <div id="arc-tab-quali-${id}" class="race-tab-pane">${renderQualiTable(race.qualiResults, id)}</div>
                `;
            } else {
                tableHtml = renderRaceTable(race.results, id, false, !!race.isNoStats);
            }
        }

        return `<div class="archive-item">
            <button class="archive-header${isOpen ? ' open' : ''}" id="arc-btn-${id}" onclick="ui.toggleArc('${id}')">
                <span ${editPart}>${race.name}</span>
 
                <span>WYNIKI <span class="arc-arrow">▼</span></span>
            </button>
            <div class="archive-body${isOpen ? ' open' : ''}" id="arc-body-${id}">
                <div style="padding:20px;border-top:2px solid #eee;overflow-x:auto;">${tableHtml}</div>
            </div>
        </div>`;
    };

    const arcList = document.getElementById('api-archive-list');
    const qualiList = document.getElementById('api-quali-list');
    if (arcList) {
        arcList.innerHTML = entries.filter(([,r]) => !r.isQualifying).map(([id,r]) => makeItem(id,r,false)).join('') || '';
        if (isLoggedIn) {
            entries.filter(([,r]) => !r.isQualifying).forEach(([id]) => {
                setTimeout(() => initRaceRowDragDrop(`race-tbl-${id}`, id, false), 50);
            });
        }
    }
    if (qualiList) qualiList.innerHTML = entries.filter(([,r]) => r.isQualifying).map(([id,r]) => makeItem(id,r,true)).join('') || '';
}

 
ui.switchArcTab = function(btn, id, tab) {
    const parent = btn.closest('.archive-body') || btn.closest('div');
    if (!parent) return;
    parent.querySelectorAll('.race-tab-btn').forEach(b => b.classList.remove('active'));
    const targetId = `arc-tab-${tab}-${id}`;
    parent.querySelectorAll('.race-tab-pane').forEach(p => {
        if (p.id === targetId) return;
        if (p.classList.contains('active')) {
            p.classList.remove('active');
            p.classList.add('leaving');
            p.addEventListener('animationend', function handler() {
                p.classList.remove('leaving');
                p.removeEventListener('animationend', handler);
            }, { once: true });
        }
    });
    btn.classList.add('active');
    const pane = document.getElementById(targetId);
    if (pane) { pane.classList.remove('leaving'); pane.classList.add('active'); }
};

 
ui.showToast = function(message, type) {
    const toast = document.getElementById('toast-notice');
    if (!toast) return;
    const borderColors = { success: '#4caf50', error: '#e10600', warn: '#ffc107' };
    toast.style.borderLeftColor = borderColors[type] || borderColors.success;
    toast.textContent = message;
    toast.classList.add('show');
    clearTimeout(toast._hideTimer);
     
    const duration = message.length > 60 ? 5500 : 3000;
    toast._hideTimer = setTimeout(() => toast.classList.remove('show'), duration);
};

function buildRaceNickChips() {
    const container = document.getElementById('race-nick-chips');
    if (!container) return;
    const sd = splitDataCache[adminSplit].standings;
    const ti = splitDataCache[adminSplit].teamsInfo || {};
    const map = new Map();
    (sd?.drivers || []).forEach(d => { if (d.nick) map.set(d.nick.toLowerCase(), { nick: d.nick, team: d.team || '' }); });
    TEAM_DEFS.forEach(t => {
        const info = ti[t.key];
        if (!info) return;
        [info.driver1, info.driver2].forEach(dn => {
            if (dn && dn.trim() && !map.has(dn.toLowerCase())) map.set(dn.toLowerCase(), { nick: dn.trim(), team: t.label });
        });
    });
    const list = [...map.values()].sort((a, b) => a.nick.localeCompare(b.nick));
    if (list.length === 0) { container.innerHTML = '<span style="font-size:12px;color:#999;">Brak zapisanych kierowców — uzupełnij ich w sekcji Klasyfikacje lub Zespoły.</span>'; return; }
    container.innerHTML = list.map(d => {
        const color = getTeamColorByName(d.team);
        const safeNick = d.nick.replace(/'/g, "\\'");
        const safeTeam = (d.team || '').replace(/'/g, "\\'");
        return `<span class="nick-chip" onclick="ui.insertNickIntoRaceRaw('${safeNick}','${safeTeam}')"><span class="chip-dot" style="background:${color};"></span>${d.nick}</span>`;
    }).join('');
}

ui.insertNickIntoRaceRaw = function(nick, team) {
    const ta = document.getElementById('adm-race-raw');
    if (!ta) return;
    const prefix = ta.value && !ta.value.endsWith('\n') ? '\n' : '';
    ta.value += `${prefix}${nick} | ${team} | `;
    ta.focus();
    ta.selectionStart = ta.selectionEnd = ta.value.length;
};

ui.saveQuickCountdownDate = async function() {
    const input = document.getElementById('quick-countdown-date-input');
    if (!input || !input.value) return;
    const dateStr = input.value.replace('T', ' ');
    const n = currentSplit;
    const snap = await new Promise(res => onValue(ref(db, 'config'), res, { onlyOnce: true }));
    const current = snap.val() || {};
    const updates = n === 1
        ? { heroDateS1: dateStr, heroModeS1: 'countdown' }
        : { heroDateS2: dateStr, heroModeS2: 'countdown' };
    await set(ref(db, 'config'), { ...current, ...updates });
    const dateInputAdm = document.getElementById('adm-hero-date-s' + n);
    if (dateInputAdm) dateInputAdm.value = dateStr;
    const modeRadio = document.querySelector(`input[name="hero-mode-s${n}"][value="countdown"]`);
    if (modeRadio) modeRadio.checked = true;
    const dateGroup = document.getElementById('hero-date-group-s' + n);
    if (dateGroup) dateGroup.style.display = 'block';
    ui.showToast('✓ Data odliczania zapisana');
};

onAuthStateChanged(auth, user => {
    isLoggedIn = !!user;
    if (!isLoggedIn) ui.closeRegulaminEditor();
    document.getElementById('btn-open-login').classList.toggle('hidden', !!user);
    document.getElementById('btn-open-admin').classList.toggle('hidden', !user);
    document.getElementById('quick-standings-bar')?.classList.toggle('visible', isLoggedIn);
    document.getElementById('quick-countdown-editor')?.classList.toggle('visible', isLoggedIn);
     
    document.getElementById('add-results-btn-last')?.classList.toggle('logged-in', isLoggedIn);
    document.getElementById('add-results-btn-archive')?.classList.toggle('logged-in', isLoggedIn);
    document.getElementById('calendar-draw-btn')?.classList.toggle('logged-in', isLoggedIn);
    const qualiTab = document.getElementById('arc-tab-quali');
    if (qualiTab) qualiTab.style.display = '';
    document.querySelectorAll('.album-edit-btn').forEach(btn => btn.classList.toggle('visible', !!user));
    const regEditBtn = document.getElementById('regulamin-edit-btn');
    if (regEditBtn) regEditBtn.style.display = (isLoggedIn && document.getElementById('view-regulamin').classList.contains('active')) ? 'block' : 'none';
        updateRegulaminButtons();
	if (currentSplit === 2) ui._applySplitView();
    if (document.getElementById('view-teams').classList.contains('active')) renderTeamsPage();
    rerenderLastRace();
    rerenderArchive();
    renderStandings();
});

window.dbCore = {
    async saveSplashContent() {
        const snap = await new Promise(res => onValue(ref(db, 'config'), res, { onlyOnce: true }));
        const current = snap.val() || {};
        const entries = document.querySelectorAll('.splash-img-entry');
        const images = [];
        let invalidSplashLink = false;
        entries.forEach(entry => {
            const align = entry.querySelector('.spl-align')?.value || 'center';
            const width = entry.querySelector('.spl-width')?.value?.trim() || '80%';
            const scaleInput = entry.querySelector('.spl-scale');
            const scale = scaleInput ? parseFloat(scaleInput.value) / 100 : 1;
            const fileData = entry.querySelector('.spl-file-data');
            const urlInput = entry.querySelector('.sie-url-wrap .spl-url');
            let url = '';
            const fileMode = entry.querySelector('.sie-source-btn.active')?.textContent?.trim() === 'PLIK';
            if (fileMode) url = fileData?.value || '';
            else url = urlInput?.value?.trim() || '';
            if (url && !fileMode) {
                const drive = parseSplashDriveLink(url);
                if (drive?.folder) { invalidSplashLink = true; return; }
                url = normalizeSplashImageUrl(url);
            }
            if (url) images.push({ url, align, width, scale });
        });
        if (invalidSplashLink) { ui.showToast('Wklej link do pojedynczego zdjęcia z Dysku, nie do folderu.', 'warn'); return; }
await set(ref(db, 'config'), { ...current, splashContent: document.getElementById('adm-splash-content').value, splashImages: images, splashImage: images.length === 1 ? images[0].url : (current.splashImage || '') });
        ui.showToast('Strona startowa zapisana!', 'success');
        document.getElementById('splash-custom-content').innerHTML = document.getElementById('adm-splash-content').value;
        renderSplashImages(images);
    },
    async saveSocialConfig() {
        const snap = await new Promise(res => onValue(ref(db, 'config'), res, { onlyOnce: true }));
        const current = snap.val() || {};
        const platforms = ['discord', 'youtube', 'tiktok'];
        const social = {};
        platforms.forEach(p => {
            const url = document.getElementById('social-url-' + p)?.value?.trim() || '';
            let icon = '';
            if (socialIconUploads[p]) { icon = socialIconUploads[p]; }
            else { const iconInput = document.getElementById('social-icon-' + p); if (iconInput && iconInput.value.trim() && !iconInput.value.includes('[')) { icon = iconInput.value.trim(); } }
            if (url) social[p] = { url, icon };
        });
        await set(ref(db, 'config'), { ...current, socialIcons: social });
        socialConfig = social; renderSocialIcons();
        ui.showToast('Ikonki social zapisane!', 'success');
    },
    async saveNewsConfig() {
        const snap = await new Promise(res => onValue(ref(db, 'config'), res, { onlyOnce: true }));
        const current = snap.val() || {};
        await set(ref(db, 'config'), { ...current, showNews: document.getElementById('adm-show-news').checked, newsContent: document.getElementById('adm-news-content').value });
        ui.showToast('News zapisany!', 'success');
    },
  async saveCountdownConfig(splitNum) {
        const snap = await new Promise(res => onValue(ref(db, 'config'), res, { onlyOnce: true }));
        const current = snap.val() || {};
        if (splitNum === 1) {
            const mode = document.querySelector('input[name="hero-mode-s1"]:checked').value;
            await set(ref(db, 'config'), { ...current,
                heroTitleS1: document.getElementById('adm-hero-title-s1').value,
                heroDateS1:  document.getElementById('adm-hero-date-s1').value,
                heroModeS1:  mode,
                gpNameS1: document.getElementById('adm-gp-name-s1').value
            });
            ui.showToast('Odliczanie Split 1 zapisane!', 'success');
        } else {
            const mode = document.querySelector('input[name="hero-mode-s2"]:checked').value;
            await set(ref(db, 'config'), { ...current,
                heroTitleS2: document.getElementById('adm-hero-title-s2').value,
                heroDateS2:  document.getElementById('adm-hero-date-s2').value,
                heroModeS2:  mode,
                gpNameS2: document.getElementById('adm-gp-name-s2').value
            });
            ui.showToast('Odliczanie Split 2 zapisane!', 'success');
        }
    },
    async publishRace() {
    const activeAdminSplit = document.getElementById('adm-split2-btn')?.classList.contains('active') ? 2 : 1;
    adminSplit = activeAdminSplit;
        const title = document.getElementById('adm-race-title').value;
        const raw = document.getElementById('adm-race-raw').value;
const noBonusRaw = document.getElementById('adm-no-bonus-nicks').value;
const noBonusNicks = new Set(noBonusRaw.split('\n').map(s => s.trim().toLowerCase()).filter(Boolean));
const reserveRaw = document.getElementById('adm-reserve-nicks').value;
const reserveNicks = new Set(reserveRaw.split('\n').map(s => s.trim().toLowerCase()).filter(Boolean));
const lines = raw.split('\n').filter(l => l.trim());


        const isQualifying = document.getElementById('pub-qualifying').checked;

        if (isQualifying) {
             
            const qualResults = lines.map((line, i) => {
                const p = line.split('|').map(s => s.trim());
                return {
                    nick: p[0] || '',
                    team: normalizeTeamName(p[1] || ''),
                    best: p[2] || '',
                    startPos: p[3] || String(i + 1),
                    grid: p[3] || String(i + 1)
                };
            });
            const qualObj = { name: title, results: qualResults, timestamp: Date.now(), isQualifying: true };
             
            await push(ref(db, seasonArchivePath(activeAdminSplit)), qualObj);
            ui.showToast(`Kwalifikacje opublikowane! (Split ${adminSplit})`, 'success');
            document.getElementById('pub-qualifying').checked = false;
            return;
        }

        const isCsvFormat = lines.length > 0 && lines[0].trim().startsWith('"') && lines[0].includes('","');
        const isTabFormat = lines.length > 0 && lines[0].includes('\t') && !lines[0].includes('|');

         
         
        const parseCsvLine = (line) => {
            const out = [];
            let cur = '';
            let inQuotes = false;
            for (let i = 0; i < line.length; i++) {
                const ch = line[i];
                if (ch === '"') {
                    if (inQuotes && line[i + 1] === '"') { cur += '"'; i++; }
                    else inQuotes = !inQuotes;
                } else if (ch === ',' && !inQuotes) {
                    out.push(cur); cur = '';
                } else {
                    cur += ch;
                }
            }
            out.push(cur);
            return out.map(s => s.trim());
        };

        let results;
        if (isCsvFormat) {
             
            const dataLines = lines.filter(l => !l.trim().startsWith('"Poz'));
            results = dataLines.map(line => {
                const p = parseCsvLine(line);
                return { pos: p[0], nick: p[1], team: normalizeTeamName(p[2]), start: p[3], pit: p[4], best: p[5], time: p[6] || '', pts: p[7] || '0' };
            });
        } else if (isTabFormat) {
            const dataLines = lines.filter(l => /^\d/.test(l.trim()));
            results = dataLines.map(line => {
                const p = line.split('\t').map(s => s.trim());
                const best = (p[5] || '').replace(',', '.');
                return { pos: p[0], nick: p[1], team: normalizeTeamName(p[2]), start: p[3], pit: p[4], best, time: p[6] || '', pts: p[7] || '0' };
            });
} else {
    results = lines.map((line, index) => {
        const p = line.split('|').map(s => s.trim());
        return { pos: index + 1, nick: p[0] || '', team: normalizeTeamName(p[1]), start: p[2], pit: p[3], best: p[4], time: p[5], pts: p[6] };
    });
}

results = results.map(r => ({ ...r, isReserve: reserveNicks.has((r.nick||'').toLowerCase()) }));


const isNoStats = document.getElementById('pub-no-stats').checked;
const isNoHistory = document.getElementById('pub-no-history').checked;
const isNoProfileStats = document.getElementById('pub-no-profile-stats').checked;

        const fastestLapIdx = findFastestLap(results);
        const resultsWithBonus = results.map((r, idx) => {
            const nickKey = (r.nick || '').toLowerCase();
            const isBot = isRealF1Driver(r.nick);
            const dnfTags = ['DNF', 'DSQ', 'DNS', 'RET', 'NC'];
            const isDnfDsq = dnfTags.some(s => (r.time || '').toString().toUpperCase().includes(s) || (r.pos || '').toString().toUpperCase().includes(s));
            const isManualExcluded = noBonusNicks.has(nickKey);
            const basePts = parseInt(r.pts) || 0;
            let bonusPts = 0;
            if (!isBot && !isDnfDsq && !isManualExcluded && !isNoStats) bonusPts = 3;
            let flPts = 0;
            if (!isBot && !isNoStats && idx === fastestLapIdx) flPts = 1;
            return { ...r, pts: String(basePts + bonusPts + flPts), hasBonus: bonusPts > 0, hasFastestLapBonus: flPts > 0 };
        });

const raceObj = { name: title, results: resultsWithBonus, timestamp: Date.now(), ...(isNoStats && { isNoStats: true }), ...(isNoHistory && { isNoHistory: true }), ...(isNoProfileStats && { isNoProfileStats: true }) };
        if (document.getElementById('pub-last').checked) await set(ref(db, getSplitPath(activeAdminSplit) + '/lastRace'), raceObj);
        if (document.getElementById('pub-archive').checked) await push(ref(db, seasonArchivePath(activeAdminSplit)), raceObj);

        if (!isNoStats) {
            const standSnap = await new Promise(res => onValue(ref(db, seasonStandingsPath(activeAdminSplit)), res, { onlyOnce: true }));
            const currentStandings = standSnap.val() || { drivers: [], teams: [] };
            const driverMap = {}; const teamMap = {};
            (currentStandings.drivers || []).forEach(d => { driverMap[d.nick.toLowerCase()] = { ...d }; });
            (currentStandings.teams || []).forEach(t => { teamMap[t.team.toLowerCase()] = { ...t }; });
            let bonusCount = 0, noBonusCount = 0;
            const noBonusReasons = [];
            resultsWithBonus.forEach(r => {
                const pts = parseInt(r.pts) || 0;
                const nickKey = (r.nick || '').toLowerCase();
                const teamKey = (r.team || '').toLowerCase();
                const isWin = parseInt(r.pos) === 1;
                const isBot = isRealF1Driver(r.nick);
                if (!isBot) {
                    if (r.hasBonus) { bonusCount++; }
                    else {
                        noBonusCount++;
                        const dnfTags = ['DNF','DSQ','DNS','RET','NC'];
                        const isDnfDsq = dnfTags.some(s => (r.time||'').toString().toUpperCase().includes(s)||(r.pos||'').toString().toUpperCase().includes(s));
                        if (isDnfDsq) noBonusReasons.push(`${r.nick}: DNF/DSQ/DNS`);
                        else noBonusReasons.push(`${r.nick}: ręcznie wykluczony`);
                    }
                }
                if (driverMap[nickKey]) { driverMap[nickKey].pts = (parseInt(driverMap[nickKey].pts) || 0) + pts; if (isWin) driverMap[nickKey].wins = (parseInt(driverMap[nickKey].wins) || 0) + 1; }
                else { driverMap[nickKey] = { nick: r.nick, team: r.team, pts, wins: isWin ? 1 : 0, isBot }; }
                if (teamKey) { if (teamMap[teamKey]) { teamMap[teamKey].pts = (parseInt(teamMap[teamKey].pts) || 0) + pts; } else { teamMap[teamKey] = { team: r.team, pts }; } }
            });
            const drivers = Object.values(driverMap).sort((a, b) => (parseInt(b.pts) || 0) - (parseInt(a.pts) || 0));
            const teams = Object.values(teamMap).sort((a, b) => (parseInt(b.pts) || 0) - (parseInt(a.pts) || 0));
            await set(ref(db, seasonStandingsPath(activeAdminSplit)), { drivers, teams });
            let msg = `✅ Wyniki opublikowane! (Split ${adminSplit})\n\n  PKT otrzymało: ${bonusCount} graczy\n`;
            if (noBonusReasons.length > 0) msg += `\n❌ Bez bonusu (${noBonusCount}):\n` + noBonusReasons.map(r => `  • ${r}`).join('\n');
            msg += `\n\n(Boty AI nie wliczane)`;
            ui.showToast(msg, 'success');
        } else {
            ui.showToast(`Wyniki opublikowane bez PKT (klasyfikacja niezmieniona)! (Split ${adminSplit})`, 'success');
        }
document.getElementById('adm-no-bonus-nicks').value = '';
document.getElementById('pub-no-stats').checked = false;
document.getElementById('pub-no-profile-stats').checked = false;
document.getElementById('pub-no-history').checked = false;
    },
    async saveRegulamin() {
        const content = document.getElementById('regulamin-textarea').value;
        const snap = await new Promise(res => onValue(ref(db, 'config'), res, { onlyOnce: true }));
        const current = snap.val() || {};
        await set(ref(db, 'config'), { ...current, regulaminContent: content });
        document.getElementById('regulamin-content-display').innerHTML = content || '<div class="regulamin-empty"><span>📋</span>Regulamin zostanie dodany wkrótce.</div>';
        ui.closeRegulaminEditor();
        ui.showToast('Regulamin zapisany!', 'success');
    },
async saveStandings() {
    const dRaw = document.getElementById('adm-drivers-raw').value.split('\n').filter(l => l.trim());
    const tRaw = document.getElementById('adm-teams-raw').value.split('\n').filter(l => l.trim());
    const drivers = dRaw.map(l => {
        const p = l.split('|').map(s => s.trim());
        const nick = p[0] || '';
        const upperNick = nick.toUpperCase();
        const isBot = upperNick.startsWith('BOT:');
        const isReserve = upperNick.startsWith('REZ:');
        const cleanNick = (isBot || isReserve) ? nick.substring(4).trim() : nick;
        return { nick: cleanNick, team: normalizeTeamName(p[1] || ''), photo: p[2] || '', wins: p[3] || '0', pts: p[4] || '0', isBot, isReserve };
    });
        const teams = tRaw.map(l => { const p = l.split('|').map(s => s.trim()); return { team: normalizeTeamName(p[0]), pts: p[1] }; });
        await set(ref(db, seasonStandingsPath(adminSplit)), { drivers, teams });
        ui.showToast(`Klasyfikacje zaktualizowane! (Split ${adminSplit}, Sezon ${currentSeason})`, 'success');
    },
    async saveTeamLogos() {
        const logos = {};
        TEAM_DEFS.forEach(t => {
            if (teamLogos[t.key] && (teamLogos[t.key].startsWith('data:') || teamLogos[t.key].startsWith('http'))) { logos[t.key] = teamLogos[t.key]; }
            else { const input = document.getElementById('logo-url-' + t.key); if (input && input.value.trim() && !input.value.includes('[')) { logos[t.key] = input.value.trim(); } }
        });
        const snap = await new Promise(res => onValue(ref(db, 'config'), res, { onlyOnce: true }));
        const current = snap.val() || {};
        await set(ref(db, 'config'), { ...current, teamLogos: logos });
        teamLogos = logos;
        if (document.getElementById('view-teams').classList.contains('active')) renderTeamsPage();
        ui.showToast('Loga zapisane!', 'success');
    },
    async saveTeamsInfo() {
        const splitPath = getSplitPath(adminSplit);
        const updates = {};
        TEAM_DEFS.forEach(t => {
            const get = (field) => document.getElementById(`ti-${t.key}-${field}`)?.value?.trim() || '';
            updates[t.key] = { driver1: get('driver1'), driver2: get('driver2'), desc: get('desc'), custom1: get('custom1'), custom2: get('custom2') };
        });
        await set(ref(db, splitPath + '/teamsInfo'), updates);
        splitDataCache[adminSplit].teamsInfo = updates;
        if (currentSplit === adminSplit) { teamsInfoData = updates; if (document.getElementById('view-teams').classList.contains('active')) renderTeamsPage(); }
        ui.showToast(`Dane zespołów zapisane! (Split ${adminSplit})`, 'success');
    },
    async createAlbum() {
        const name = document.getElementById('adm-gal-name').value.trim();
        const cover = document.getElementById('adm-gal-cover').value.trim();
        if (!name) { ui.showToast('Podaj nazwę albumu.', 'error'); return; }
await push(ref(db, seasonGalleryPath()), { name, cover, entries: {} });
        document.getElementById('adm-gal-name').value = '';
        document.getElementById('adm-gal-cover').value = '';
        ui.showToast('Album utworzony!', 'success');
    },
    async addEntry() {
        const albumId = document.getElementById('adm-entry-album').value;
        const title = document.getElementById('adm-entry-title').value.trim();
        const mediaType = document.querySelector('input[name="media-type"]:checked').value;
        const status = document.getElementById('adm-entry-status');
        if (!albumId) { ui.showToast('Wybierz album.', 'error'); return; }
        let entry = { title, type: mediaType };
        if (mediaType === 'youtube') { const url = document.getElementById('adm-entry-youtube').value.trim(); if (!url) { ui.showToast("Podaj link YouTube.", 'error'); return; } entry.src = url; }
        else if (mediaType === 'url') { const url = document.getElementById('adm-entry-url').value.trim(); if (!url) { ui.showToast("Podaj URL.", 'error'); return; } entry.src = url; }
        else if (mediaType === 'upload') {
            const file = document.getElementById('adm-entry-file').files[0];
            if (!file) { ui.showToast('Wybierz plik.', 'error'); return; }
            status.textContent = "Kodowanie pliku...";
            entry.src = await new Promise((res, rej) => { const r = new FileReader(); r.onload = e => res(e.target.result); r.onerror = () => rej(new Error("Błąd odczytu")); r.readAsDataURL(file); });
            status.textContent = "Zapisywanie...";
        }
await push(ref(db, `${seasonGalleryPath()}/${albumId}/entries`), entry);
status.textContent = "✓ Wpis dodany!";
        document.getElementById('adm-entry-title').value = '';
        document.getElementById('adm-entry-youtube').value = '';
        document.getElementById('adm-entry-url').value = '';
        document.getElementById('adm-entry-file').value = '';
        setTimeout(() => status.textContent = '', 3000);
    },
    async deleteNode(path) {
        if (confirm("Czy na pewno chcesz to usunąć?")) { await remove(ref(db, path)); ui.showToast("Usunięto pomyślnie.", 'success'); }
    },
    async saveArchiveOrder() {
        const arcPath = seasonArchivePath(adminSplit);
        const list = document.getElementById('adm-archive-manager');
        const items = [...list.querySelectorAll('.reorder-item')];
        const updates = {};
        items.forEach((item, i) => { updates[arcPath + '/' + item.dataset.id + '/order'] = i; });
        await update(ref(db), updates);
        ui.showToast('Kolejność wyścigów zapisana!', 'success');
        document.getElementById('btn-save-archive-order').style.display = 'none';
    },
    async saveSplit2SoonMode() {
        const tog = document.getElementById('adm-split2-soon-toggle');
        const val = tog ? tog.checked : true;
        const snap = await new Promise(res => onValue(ref(db, 'config'), res, { onlyOnce: true }));
        const current = snap.val() || {};
        await set(ref(db, 'config'), { ...current, split2SoonMode: val });
        split2SoonMode = val;
        if (currentSplit === 2) ui._applySplitView();
        ui.showToast(val ? 'Split 2: tryb SOON włączony.' : 'Split 2: dane widoczne dla wszystkich.', 'success');
    },
    async saveGalleryOrder() {
        const list = document.getElementById('adm-gallery-manager');
        const items = [...list.querySelectorAll('.reorder-item')];
        const updates = {};
items.forEach((item, i) => { updates[seasonGalleryPath() + '/' + item.dataset.id + '/order'] = i; });
        await update(ref(db), updates);
        ui.showToast('Kolejność albumów zapisana!', 'success');
        document.getElementById('btn-save-gallery-order').style.display = 'none';
    },
    async recalcStandingsFromArchive(splitNum) {
        if (!isLoggedIn) return;
    const targetSplit = splitNum || adminSplit;
    const arcSnap = await new Promise(res => onValue(ref(db, seasonArchivePath(targetSplit)), res, { onlyOnce: true }));
    const archive = arcSnap.val();
    if (!archive || Object.keys(archive).length === 0) { ui.showToast('Brak danych w archiwum dla tego splitu.', 'error'); return; }

    const sdSnap = await new Promise(res => onValue(ref(db, seasonStandingsPath(targetSplit)), res, { onlyOnce: true }));
        const currentSd = sdSnap.val() || { drivers: [], teams: [] };

        const driverMeta = {};
        (currentSd.drivers || []).forEach(d => {
            driverMeta[(d.nick || '').toLowerCase()] = { ...d, pts: 0, wins: 0 };
        });

        const knownHumanNicks = new Set(
            (currentSd.drivers || []).filter(d => !d.isBot).map(d => (d.nick || '').toLowerCase())
        );
        const knownBotNicks = new Set(
            (currentSd.drivers || []).filter(d => d.isBot).map(d => (d.nick || '').toLowerCase())
        );

        const teamMap = {};
        const races = Object.values(archive).sort((a, b) => {
            const ao = a.order, bo = b.order;
            if (ao !== undefined && bo !== undefined) return ao - bo;
            if (ao !== undefined) return -1; if (bo !== undefined) return 1;
            return (a.timestamp || 0) - (b.timestamp || 0);
        });

        let racesProcessed = 0;
        races.forEach(race => {
            if (!race.results || race.isQualifying || race.isNoStats) return;
            racesProcessed++;
            race.results.forEach(r => {
                const pts = parseInt(r.pts) || 0;
                const nickKey = (r.nick || '').toLowerCase();
                const teamKey = (r.team ? normalizeTeamName(r.team) : '').toLowerCase();
                const isWin = parseInt(r.pos) === 1;
                let isBot;
                if (knownHumanNicks.has(nickKey)) isBot = false;
                else if (knownBotNicks.has(nickKey)) isBot = true;
                else isBot = isRealF1Driver(r.nick);

                if (!driverMeta[nickKey]) {
                    driverMeta[nickKey] = { nick: r.nick, team: normalizeTeamName(r.team) || '', pts: 0, wins: 0, isBot };
                }
                driverMeta[nickKey].pts = (driverMeta[nickKey].pts || 0) + pts;
                if (isWin) driverMeta[nickKey].wins = (driverMeta[nickKey].wins || 0) + 1;
                if (r.team) driverMeta[nickKey].team = normalizeTeamName(r.team);

                if (teamKey) {
                    const tLabel = normalizeTeamName(r.team);
                    if (!teamMap[teamKey]) teamMap[teamKey] = { team: tLabel, pts: 0 };
                    teamMap[teamKey].pts += pts;
                }
            });
        });

        const drivers = Object.values(driverMeta).sort((a, b) => (parseInt(b.pts) || 0) - (parseInt(a.pts) || 0));
        const teams = Object.values(teamMap).sort((a, b) => (parseInt(b.pts) || 0) - (parseInt(a.pts) || 0));
        await set(ref(db, seasonStandingsPath(targetSplit)), { drivers, teams });
ui.showToast(`Klasyfikacja przeliczona z archiwum (Split ${targetSplit})!\nPrzeanalizowanych wyścigów: ${racesProcessed}\nKierowców: ${drivers.length}, Konstruktorów: ${teams.length}`, 'success');
    },
        async startNewSeason() {
        if (!isLoggedIn) return;
        const sp = seasonStandingsPath(adminSplit);
        const snap = await new Promise(res => onValue(ref(db, sp), res, { onlyOnce: true }));
        const current = snap.val() || { drivers: [], teams: [] };
        const drivers = (current.drivers || []).map(d => ({ ...d, pts: 0, wins: 0 }));
        const teams = (current.teams || []).map(t => ({ ...t, pts: 0 }));
                await set(ref(db, sp), { drivers, teams });
               ui.showToast(`Zerowanie wykonane dla Split ${adminSplit}, Sezon ${currentSeason}!`, 'success');
    },
    async saveSplitSwitcherVisibility() {
        const tog = document.getElementById('adm-hide-split-switcher');
        const val = tog ? tog.checked : false;
        const snap = await new Promise(res => onValue(ref(db, 'config'), res, { onlyOnce: true }));
        const current = snap.val() || {};
        await set(ref(db, 'config'), { ...current, hideSplitSwitcher: val });
        applySplitSwitcherVisibility(val);
        ui.showToast(val ? 'Przełącznik splitów ukryty.' : 'Przełącznik splitów widoczny.', 'success');
    }
};

 
const extractYtId = (url) => {
    if (!url) return '';
    let m = url.match(/youtu\.be\/([^?&]+)/); if (m) return m[1];
    m = url.match(/[?&]v=([^?&]+)/); if (m) return m[1];
    m = url.match(/embed\/([^?&]+)/); if (m) return m[1];
    return url;
};
const gpNameToShort = (gpName) => {
    if (!gpName) return '';
    const short = gpName.replace(/grand\s*prix/i, '').replace(/\s+/g, ' ').trim();
    return short ? short + ' GP' : 'GP';
};
const getNextRoundNumber = (splitNum) => {
    const arc = (splitDataCache[splitNum] && splitDataCache[splitNum].archive) || {};
    const count = Object.values(arc).filter(r => !r.isQualifying).length;
    return count + 1;
};

 
function getNextCalendarEntry(splitNum) {
    const cal = window.calendarData || {};
    const arc = (splitDataCache[splitNum] && splitDataCache[splitNum].archive) || {};
    const usedNames = Object.values(arc)
        .filter(r => !r.isQualifying && r.name)
        .map(r => r.name.toLowerCase());

    const rounds = Object.keys(cal).map(Number).sort((a, b) => a - b);
    for (const round of rounds) {
        const entry = cal[round];
        if (!entry || !entry.name) continue;
        const core = entry.name.toLowerCase().replace(/grand prix/i, '').trim();
        const alreadyUsed = core && usedNames.some(n => n.includes(core));
        if (!alreadyUsed) return { round, entry };
    }
    return null;
}
const buildRaceTitleSuggestion = (splitNum) => {
    const round = getNextRoundNumber(splitNum);  
    const nextCal = getNextCalendarEntry(splitNum);  
    const gpName = nextCal ? nextCal.entry.name : ((splitNum === 2 ? window.gpNameS2 : window.gpNameS1) || '');
    if (!gpName.trim()) return '';
    return `ROUND ${round} ${gpName.trim().toUpperCase()}`;
};
const buildGpNameSuggestion = (splitNum) => {
    const nextCal = getNextCalendarEntry(splitNum);
    return nextCal ? nextCal.entry.name : '';
};
function csvSplit(line) {
    const out = [];
    let cur = '';
    let inQuotes = false;
    for (let i = 0; i < line.length; i++) {
        const ch = line[i];
        if (ch === '"') {
            if (inQuotes && line[i + 1] === '"') { cur += '"'; i++; }
            else inQuotes = !inQuotes;
        } else if (ch === ',' && !inQuotes) {
            out.push(cur); cur = '';
        } else {
            cur += ch;
        }
    }
    out.push(cur);
    return out.map(s => s.trim());
}
function parseArmLine(line) {
    const trimmed = (line || '').trim();
    if (!trimmed) return null;
    if (trimmed.startsWith('"') && trimmed.includes('","')) {
        const p = csvSplit(trimmed);
        return { format: 'csv', nick: p[1] || '', team: p[2] || '', raw: p };
    }
    if (trimmed.includes('|')) {
        const p = trimmed.split('|').map(s => s.trim());
        return { format: 'pipe', nick: p[0] || '', team: p[1] || '', raw: p };
    }
    return null;
}
const normalizeTeamName = (name) => {    if (!name) return name;
    const n = name.toLowerCase().trim();
    if (n.includes('ferrari') || n.includes('scuderia')) return 'Scuderia Ferrari HP';
    if (n.includes('red bull') && !n.includes('racing bull') && !n.includes('visa')) return 'Red Bull';
    if (n.includes('mercedes')) return 'Mercedes-AMG Petronas';
    
    if (n.includes('williams')) return 'Williams';
    if (n.includes('aston')) return 'Aston Martin';
    if (n.includes('haas') || n.includes('moneygram')) return 'Haas';
    if (n.includes('alpine') || n.includes('bwt')) return 'Alpine';
    if (n.includes('mclaren')) return 'McLaren';
    if (n.includes('racing bull') || n.includes('visa cash') || n.includes('vcarb') || n === 'rb' || n.startsWith('rb ') || n.match(/^racing bulls?$/)) return 'Visa Cash App RB';
    if (n.includes('sauber') || n.includes('kick')) return 'Sauber';
    if (n.includes('audi')) return 'Audi';
    if (n.includes('cadillac')) return 'Cadillac';
    return name;
};
const getTeamClass = (teamName) => {
    const name = (teamName || "").toLowerCase().trim();
    if (name.includes("ferrari") || name.includes("scuderia")) return "team-ferrari";
    if (name.includes("mercedes")) return "team-mercedes";
    if (name.includes("red bull")) return "team-redbull";
    if (name.includes("mclaren")) return "team-mclaren";
    if (name.includes("aston")) return "team-aston";
    if (name.includes("alpine")) return "team-alpine";
    if (name.includes("williams")) return "team-williams";
    
    if (name.includes("haas") || name.includes("moneygram")) return "team-haas";
        if (name.includes("racing bull") || name.includes("visa cash") || name.includes("vcarb") || name === "rb" || name.startsWith("rb ") || name.endsWith(" rb")) return "team-rb";
    if (name.includes("audi")) return "team-audi";
    if (name.includes("cadillac")) return "team-cadillac";
    if (name.includes("sauber") || name.includes("kick")) return "team-sauber";
    return "team-other";
};
const getConstructorClass = (teamName) => {
    const name = (teamName || "").toLowerCase().trim();
    if (name.includes("ferrari")) return "cteam-ferrari";
    if (name.includes("mercedes")) return "cteam-mercedes";
    if (name.includes("red bull") && !name.includes("racing")) return "cteam-redbull";
    if (name.includes("mclaren")) return "cteam-mclaren";
    if (name.includes("aston")) return "cteam-aston";
    if (name.includes("alpine")) return "cteam-alpine";
    if (name.includes("williams")) return "cteam-williams";
    
    if (name.includes("haas")) return "cteam-haas";
        if (name.includes("racing bull") || name.includes("visa cash") || name.includes("vcarb") || name === "rb" || name.startsWith("rb ") || name.endsWith(" rb")) return "cteam-rb";
    if (name.includes("audi")) return "cteam-audi";
    if (name.includes("cadillac")) return "cteam-cadillac";
    if (name.includes("sauber") || name.includes("kick")) return "cteam-sauber";
    return "";
};
 
 
const getTeamKey = (teamName) => { const tc = getTeamClass(teamName); return tc ? tc.replace('team-', '') : ''; };
const findFastestLap = (results) => findFastestLapIdx(results);

 
const renderRaceTable = (results, raceId = null, isLastRace = false, hidePts = false, skipRows = 0) => {
    if (!results || results.length === 0) return '<p style="padding:40px;">Brak wyników.</p>';
    results = results.map(r => ({ ...r, team: normalizeTeamName(r.team) }));
    const posClass = (posVal) => { const p = parseInt(posVal); if (p === 1) return 'pos-gold'; if (p === 2) return 'pos-silver'; if (p === 3) return 'pos-bronze'; return ''; };
    const clean = (val) => (val || '').toString().replace(/^(Start:|Pit:)\s*/i, '').trim();
    const fastestIdx = findFastestLap(results);
    const cellEdit = (val, rowIdx, field, extraClass='') => {
        if (!isLoggedIn) return `<span class="${extraClass}">${val||'-'}</span>`;
        if (raceId) return `<span class="arc-cell-editable ${extraClass}" onclick="ui.editArcCell(this,'${raceId}',${rowIdx},'${field}')">${val||'-'}</span>`;
        if (isLastRace) return `<span class="arc-cell-editable ${extraClass}" onclick="ui.editLastRaceCell(this,${rowIdx},'${field}')">${val||'-'}</span>`;
        return `<span class="${extraClass}">${val||'-'}</span>`;
    };
    const tableId = raceId ? `race-tbl-${raceId}` : (isLastRace ? 'race-tbl-last' : 'race-tbl-tmp');
    const dragAttrs = isLoggedIn ? `draggable="true"` : '';
    return `<table class="f1-table" id="${tableId}"><thead><tr>
        <th class="col-pos" style="width:50px;">P</th>
        <th class="col-driver" style="width:22%;">Kierowca</th>
        <th style="width:18%;">Zespół</th>
        <th style="text-align:center;width:50px;">Grid</th>
        <th style="text-align:center;width:44px;">Pit</th>
        <th style="width:150px;">Najl. okr.</th>
        <th style="width:auto;">Czas</th>
        ${hidePts ? '' : '<th class="col-pts" style="width:70px;">PKT</th>'}
    </tr></thead><tbody>${results.map((r, i) => {
        const rowStyle = `${i < skipRows ? 'display:none;' : ''}${isLoggedIn ? 'cursor:grab;' : ''}`;
        return `
        <tr ${dragAttrs} style="${rowStyle}" class="${getTeamClass(r.team)}" data-row-idx="${i}" data-table-id="${tableId}">
            <td class="col-pos ${posClass(r.pos)}">${cellEdit(r.pos, i, 'pos')}</td>
<td class="col-driver">${nickSpan(r.nick, i, raceId, isLastRace, r.isReserve)}</td>
            <td class="${getTeamClass(r.team).replace('team-', 'txt-')}">${cellEdit(r.team, i, 'team')}</td>
            <td style="text-align:center;">${cellEdit(clean(r.start), i, 'start')}</td>
            <td style="text-align:center;">${cellEdit(clean(r.pit), i, 'pit')}</td>
            <td class="${i === fastestIdx ? 'fastest-lap' : 'col-best-lap'}">${cellEdit(r.best, i, 'best', i === fastestIdx ? 'fastest-lap' : '')}</td>
            <td>${cellEdit(r.time, i, 'time')}</td>
            ${hidePts ? '' : `<td class="col-pts">${cellEdit(r.pts, i, 'pts')}</td>`}
        </tr>`;
    }).join('')}</tbody></table>`;
};

const nickSpan = (nick, rowIdx, raceId, isLastRace, isReserve) => {
    const safeNick = (nick || '').replace(/'/g, "\\'");
    const badge = isReserve ? ' <span class="reserve-badge">REZERWA</span>' : '';
    const profileBtn = `<span class="nick-clickable" onclick="ui.openDriverProfile('${safeNick}')" title="Profil kierowcy">${nick || '—'}${badge}</span>`;
    if (!isLoggedIn) return profileBtn;
    const reserveToggle = `<span style="opacity:0.6;font-size:0.7em;cursor:pointer;margin-left:4px;" onclick="event.stopPropagation();ui.toggleReserveResult('${raceId || ''}',${rowIdx},${!!isLastRace})" title="Przełącz REZERWA">🔄</span>`;
    if (raceId) return `<span class="arc-cell-editable" onclick="ui.editArcCell(this,'${raceId}',${rowIdx},'nick')">${nick || '—'}</span>${badge} <span style="opacity:0.4;font-size:0.7em;cursor:pointer;" onclick="event.stopPropagation();ui.openDriverProfile('${safeNick}')" title="Profil">👤</span>${reserveToggle}`;
    if (isLastRace) return `<span class="arc-cell-editable" onclick="ui.editLastRaceCell(this,${rowIdx},'nick')">${nick || '—'}</span>${badge} <span style="opacity:0.4;font-size:0.7em;cursor:pointer;" onclick="event.stopPropagation();ui.openDriverProfile('${safeNick}')" title="Profil">👤</span>${reserveToggle}`;
    return profileBtn;
};
 
function hexToRgba(hex, alpha) {
    const h = (hex || '#666666').replace('#', '');
    const full = h.length === 3 ? h.split('').map(c => c + c).join('') : h;
    const bigint = parseInt(full, 16);
    const r = (bigint >> 16) & 255, g = (bigint >> 8) & 255, b = bigint & 255;
    return `rgba(${r},${g},${b},${alpha})`;
}

function renderLastRacePodium(results) {
    const top3 = (results || []).slice(0, 3);
    if (top3.length < 3) return '';
    const slot = (r, idx) => {
        const team = normalizeTeamName(r.team);
        const key = getTeamKey(team) || 'default';
        const color = getTeamColorByName(team);
        const teamDef = TEAM_DEFS.find(t => t.key === key);
        const teamLabel = teamDef ? teamDef.label : team;
        return `<div class="podium-slot p${idx + 1}" style="background:linear-gradient(160deg, ${hexToRgba(color, 0.95)}, ${hexToRgba(color, 0.55)});">
            <span class="ps-num">${idx + 1}</span>
            <img class="ps-car" src="cars/${key}.png" alt="${teamLabel}" onerror="this.style.display='none'">
            <span class="ps-nick">${r.nick || '—'}</span>
            <span class="ps-team">${teamLabel}</span>
            <span class="ps-pts">${r.pts || 0} PKT</span>
        </div>`;
    };
    return `<div class="story-podium-title">🏆 Podium</div>
        <div class="podium-row">${slot(top3[0], 0)}${slot(top3[1], 1)}${slot(top3[2], 2)}</div>`;
}

function renderLastRaceStats(results) {
    if (!results || results.length === 0) return '';
    const clean = (v) => (v || '').toString().replace(/^(Start:|Pit:)\s*/i, '').trim();
    const fastestIdx = findFastestLap(results);
    const poleRow = results.find(r => parseInt(clean(r.start)) === 1) || null;
    const winner = results[0] || null;
    const runnerUp = results[1] || null;
    const lastPlace = results[results.length - 1] || null;

    let gainedBest = null, lostWorst = null;
    results.forEach((r, i) => {
        const grid = parseInt(clean(r.start));
        const finish = parseInt(r.pos) || (i + 1);
        if (!grid || isNaN(grid)) return;
        const diff = grid - finish;  
        if (gainedBest === null || diff > gainedBest.diff) gainedBest = { r, diff };
        if (lostWorst === null || diff < lostWorst.diff) lostWorst = { r, diff };
    });

    let mostPits = null;
    results.forEach(r => {
        const n = parseInt(clean(r.pit));
        if (!isNaN(n) && (mostPits === null || n > mostPits.n)) mostPits = { r, n };
    });

    let rows = `<div class="stat-row">
            <div class="stat-icon">⏱️</div>
            <div class="stat-body">
                <span class="stat-label">Najszybsze okrążenie</span>
                <span class="stat-value stat-purple">${fastestIdx >= 0 ? (results[fastestIdx].nick || '—') : '—'}<span class="stat-extra">${fastestIdx >= 0 ? (results[fastestIdx].best || '') : ''}</span></span>
            </div>
        </div>
        <div class="stat-row">
            <div class="stat-icon">🏁</div>
            <div class="stat-body">
                <span class="stat-label">Pole Position</span>
                <span class="stat-value">${poleRow ? (poleRow.nick || '—') : '—'}</span>
            </div>
        </div>`;
    if (gainedBest && gainedBest.diff > 0) {
        rows += `<div class="stat-row">
            <div class="stat-icon">📈</div>
            <div class="stat-body">
                <span class="stat-label">Najwięcej zyskanych pozycji</span>
                <span class="stat-value">${gainedBest.r.nick || '—'}<span class="stat-extra">+${gainedBest.diff}</span></span>
            </div>
        </div>`;
    }
    if (lostWorst && lostWorst.diff < 0) {
        rows += `<div class="stat-row">
            <div class="stat-icon">📉</div>
            <div class="stat-body">
                <span class="stat-label">Najwięcej straconych pozycji</span>
                <span class="stat-value">${lostWorst.r.nick || '—'}<span class="stat-extra">${lostWorst.diff}</span></span>
            </div>
        </div>`;
    }
    if (runnerUp && clean(runnerUp.time)) {
        rows += `<div class="stat-row">
            <div class="stat-icon">🥇</div>
            <div class="stat-body">
                <span class="stat-label">Przewaga zwycięzcy nad P2</span>
                <span class="stat-value">${winner.nick || '—'}<span class="stat-extra">${clean(runnerUp.time)}</span></span>
            </div>
        </div>`;
    }
    if (lastPlace && lastPlace !== winner && clean(lastPlace.time)) {
        rows += `<div class="stat-row">
            <div class="stat-icon">🔻</div>
            <div class="stat-body">
                <span class="stat-label">Strata ostatniego miejsca</span>
                <span class="stat-value">${lastPlace.nick || '—'}<span class="stat-extra">${clean(lastPlace.time)}</span></span>
            </div>
        </div>`;
    }
    if (winner && clean(winner.pit) && !isNaN(parseInt(clean(winner.pit)))) {
        rows += `<div class="stat-row">
            <div class="stat-icon">🔧</div>
            <div class="stat-body">
                <span class="stat-label">Pit-stopy zwycięzcy</span>
                <span class="stat-value">${clean(winner.pit)}</span>
            </div>
        </div>`;
    }
    if (mostPits && mostPits.n > 0) {
        rows += `<div class="stat-row">
            <div class="stat-icon">🛞</div>
            <div class="stat-body">
                <span class="stat-label">Najwięcej pit-stopów</span>
                <span class="stat-value">${mostPits.r.nick || '—'}<span class="stat-extra">${mostPits.n}</span></span>
            </div>
        </div>`;
    }
    return `<div class="story-stats-title">Statystyki wyścigu</div>${rows}`;
}

function updateLastRaceSidebar(results) {
    const podiumEl = document.getElementById('last-race-podium');
    const statsEl = document.getElementById('last-race-stats');
    if (!podiumEl || !statsEl) return;
    if (!results || results.length === 0) {
        podiumEl.innerHTML = '';
        statsEl.innerHTML = '';
        return;
    }
    podiumEl.innerHTML = renderLastRacePodium(results);
    statsEl.innerHTML = renderLastRaceStats(results);
}

 
const renderQualifyingTable = (results, raceId = null) => {
    if (!results || results.length === 0) return '<p style="padding:20px;">Brak wyników.</p>';
    results = results.map(r => ({ ...r, team: normalizeTeamName(r.team) }));
    const toSec = (t) => {
        if (!t || t === '-' || t === '—') return Infinity;
        const clean = t.toString().trim();
        const m = clean.match(/^(\d+):(\d+)[\.,](\d+)$/);
        if (m) return parseInt(m[1]) * 60 + parseInt(m[2]) + parseInt(m[3]) / 1000;
        const s = parseFloat(clean.replace(',', '.'));
        return isNaN(s) ? Infinity : s;
    };
    const sorted = [...results].sort((a, b) => toSec(a.best) - toSec(b.best));
    const posClass = (i) => i===0?'pos-gold':i===1?'pos-silver':i===2?'pos-bronze':'';
    return `<table class="f1-table"><thead><tr>
        <th class="col-pos">P</th>
        <th class="col-driver">Kierowca</th>
        <th>Zespół</th>
        <th style="width:180px;">Najlepszy czas</th>
        <th style="width:160px;text-align:right;padding-right:40px;">STRATA</th>
    </tr></thead><tbody>${sorted.map((r, i) => {
        const bestSec = toSec(r.best);
        const leaderSec = toSec(sorted[0].best);
        const gap = (i === 0 || bestSec === Infinity) ? '0:00,000' : '+' + (bestSec - leaderSec).toFixed(3).replace('.', ',') + 's';
        const safeNick = (r.nick || '').replace(/'/g, "\\'");
        const nickHtml = `<span class="nick-clickable" onclick="ui.openDriverProfile('${safeNick}')">${r.nick||'—'}</span>`;
        const bestHtml = `<span class="fastest-lap">${r.best||'—'}</span>`;
        return `<tr class="${getTeamClass(r.team)}">
            <td class="col-pos ${posClass(i)}">${i+1}</td>
            <td class="col-driver">${nickHtml}</td>
            <td class="${getTeamClass(r.team).replace('team-','txt-')}">${r.team||'—'}</td>
            <td>${bestHtml}</td>
            <td style="text-align:right;padding-right:40px;font-family:var(--font-display);font-size:28px;color:${i===0?'var(--f1-red)':'#888'};font-weight:${i===0?'900':'400'};">${gap}</td>
        </tr>`;
    }).join('')}</tbody></table>`;
};

function renderConstructorRow(r, i) {
    const cClass = getConstructorClass(r.team);
    const posClass = i===0?'pos-gold':i===1?'pos-silver':i===2?'pos-bronze':'';
    const key = getTeamKey(r.team);
    const logoUrl = key ? (teamLogos[key] || '') : '';
    const leftDecor = logoUrl
        ? `<img src="${logoUrl}" class="constructor-logo-main" alt="${r.team}" onerror="this.style.display='none'">`
        : `<div style="width:6px;height:50px;background:rgba(255,255,255,0.4);border-radius:3px;flex-shrink:0;"></div>`;
    return `<tr class="constructor-row ${cClass}">
        <td class="col-pos" style="font-weight:900;"><span class="${posClass}">${r.pos||i+1}</span></td>
        <td style="font-weight:700;font-size:18px;letter-spacing:1px;white-space:normal;">
            <div class="constructor-name-cell">${leftDecor}<span class="${getTeamClass(r.team).replace('team-', 'txt-')}" style="filter:brightness(0) invert(1);">${r.team}</span></div>
        </td>
        <td class="col-pts" style="padding-right:10px;">
            <span class="cteam-pts-cell">${isLoggedIn ? `<span class="editable-cell" data-countup="${r.pts||0}" onclick="ui.editCell(this,'standings','teams',${i},'pts')">0</span>` : `<span data-countup="${r.pts||0}">0</span>`}</span>
        </td>
    </tr>`;
}

const REAL_F1_DRIVERS = new Set([
    'max verstappen','liam lawson','charles leclerc','lewis hamilton','george russell','andrea kimi antonelli','kimi antonelli',
    'lando norris','oscar piastri','fernando alonso','lance stroll','pierre gasly','jack doohan','alex albon','carlos sainz',
    'yuki tsunoda','isack hadjar','nico hulkenberg','nico hülkenberg','esteban ocon','oliver bearman','gabriel bortoleto',
    'kevin magnussen','valtteri bottas','zhou guanyu','guanyu zhou','sergio perez','sergio pérez','daniel ricciardo','franco colapinto',
    'nyck de vries','mick schumacher','robert kubica',
    'verstappen','lawson','leclerc','hamilton','russell','antonelli','norris','piastri','alonso','stroll','gasly','doohan',
    'albon','sainz','tsunoda','hadjar','hulkenberg','hülkenberg','ocon','bearman','bortoleto','colapinto','bottas','zhou',
    'perez','pérez','ricciardo','sargeant',
]);
const isRealF1Driver = (name) => {
    if (!name) return false;
    const n = name.toLowerCase().trim();
    if (REAL_F1_DRIVERS.has(n)) return true;
    const words = n.split(/\s+/);
    return words.some(w => w.length > 3 && REAL_F1_DRIVERS.has(w));
};

 
function renderStandings() {
    const sd = splitDataCache[currentSplit].standings;
    if (!sd) return;
    const driversList = document.getElementById('api-drivers-list');
    const teamsList = document.getElementById('api-teams-list');
    if (driversList && sd.drivers) {
        const humanDrivers = sd.drivers.filter(d => !d.isBot);
        const botDrivers = sd.drivers.filter(d => d.isBot);
        const hasBots = botDrivers.length > 0;
        const colSpan = 5;
        const separatorRow = hasBots
            ? `<tr class="separator-row"><td colspan="${colSpan}"><div></div></td></tr>`
            : '';
        const renderDriverRow = (d, i, isBot) => {
            const posC = i===0?'pos-gold':i===1?'pos-silver':i===2?'pos-bronze':'';
            const tc = getTeamClass(d.team);
            const safeNick = (d.nick||'').replace(/'/g,"\\'");
            const nickHtml = `<span class="driver-name-clickable${isBot ? ' bot-driver-name' : ''}" onclick="ui.openDriverProfile('${safeNick}')" title="${isBot ? 'Profil bota AI' : 'Profil kierowcy'}">${d.nick}${isBot ? ' <span class="bot-badge">BOT</span>' : ''}${d.isReserve ? ' <span class="reserve-badge">REZERWA</span>' : ''}</span>`;
            const origIdx = sd.drivers.indexOf(d);
            const posHtml = isLoggedIn
                ? `<span class="arc-cell-editable ${posC}" onclick="ui.editCell(this,'${getSplitPath()}/standings','drivers',${origIdx},'pos')">${d.pos||i+1}</span>`
                : `<span class="${posC}">${d.pos||i+1}</span>`;
            const ptsHtml = isLoggedIn
                ? `<span class="editable-cell" data-countup="${d.pts||0}" onclick="ui.editCell(this,'${getSplitPath()}/standings','drivers',${origIdx},'pts')">0</span>`
                : `<span data-countup="${d.pts||0}">0</span>`;
            const winsHtml = isLoggedIn
                ? `<span class="editable-cell" data-countup="${d.wins||0}" onclick="ui.editCell(this,'${getSplitPath()}/standings','drivers',${origIdx},'wins')">0</span>`
                : `<span data-countup="${d.wins||0}">0</span>`;
const deleteBtn = isLoggedIn
    ? `<span style="cursor:pointer;color:#c00;font-weight:900;margin-left:10px;font-size:0.6em;" onclick="event.stopPropagation();ui.deleteDriverFromStandings(${origIdx})" title="Usuń kierowcę">🗑</span>`
    : '';
const reserveBtn = isLoggedIn
    ? `<span style="cursor:pointer;color:#ffc107;font-weight:900;margin-left:6px;font-size:0.6em;" onclick="event.stopPropagation();ui.toggleReserveDriver(${origIdx})" title="Przełącz REZERWA">🔄</span>`
    : '';
            return `<tr class="${tc}${isBot ? ' bot-row' : ''}">
                <td class="col-pos">${posHtml}</td>
<td class="col-driver"><div class="driver-cell">${nickHtml}${reserveBtn}${deleteBtn}</div></td>
                <td class="${tc.replace('team-','txt-')}" style="font-size:28px;">${d.team||''}</td>
                <td style="text-align:center;">${winsHtml}</td>
                <td class="col-pts">${ptsHtml}</td>
            </tr>`;
        };
        driversList.innerHTML =
            humanDrivers.map((d, i) => renderDriverRow(d, i, false)).join('') +
            separatorRow +
            botDrivers.map((d, i) => renderDriverRow(d, i, true)).join('');
    }
    if (teamsList && sd.teams) {
        teamsList.innerHTML = sd.teams.map((r, i) => renderConstructorRow(r, i)).join('');
    }
    runCountUps(driversList);
    runCountUps(teamsList);
}
function seasonArchivePath(splitNum) {
    const sp = splitNum === 1 ? 'split1' : 'split2';
    return currentSeason === 1 ? sp + '/archive' : 'season2/' + sp + '/archive';
}
function seasonStandingsPath(splitNum) {
    const sp = splitNum === 1 ? 'split1' : 'split2';
    return currentSeason === 1 ? sp + '/standings' : 'season2/' + sp + '/standings';
}
function seasonGalleryPath() {
    return currentSeason === 1 ? 'gallery' : 'season2/gallery';
}
function getSplitPath(split) {
    const s = split !== undefined ? split : (document.getElementById('adm-split1-btn')?.classList.contains('active') ? 1 : 2);
    return s === 1 ? 'split1' : 'split2';
}
function getSplitPathView() {
    return currentSplit === 1 ? 'split1' : 'split2';
}

function refreshGpNamesDatalist() {
    const names = new Set();
    [1, 2].forEach(s => {
        const arc = splitDataCache[s].archive || {};
        Object.values(arc).forEach(r => { if (r.name) names.add(r.name); });
    });
    Object.values(calendarData || {}).forEach(entry => { if (entry && entry.name) names.add(entry.name); });
    const dl = document.getElementById('gp-names-list');
    if (dl) dl.innerHTML = [...names].map(n => `<option value="${n}">`).join('');
}

function buildAdmArchiveManager() {
    ui.refreshRaceTitleSuggestion();
    const manager = document.getElementById('adm-archive-manager');
    if (!manager) return;
    refreshGpNamesDatalist();
    const data = splitDataCache[adminSplit].archive;
    if (!data || Object.keys(data).length === 0) {
        manager.innerHTML = '<p style="color:#999;font-size:13px;">Brak wpisów w archiwum.</p>';
        const saveBtn = document.getElementById('btn-save-archive-order');
        if (saveBtn) saveBtn.style.display = 'none';
        return;
    }
    const entries = Object.entries(data).sort((a, b) => {
        const ao = a[1].order, bo = b[1].order;
        if (ao !== undefined && bo !== undefined) return ao - bo;
        if (ao !== undefined) return -1; if (bo !== undefined) return 1;
        return (b[1].timestamp || 0) - (a[1].timestamp || 0);
    });
    const arcPath = seasonArchivePath(adminSplit);
    manager.innerHTML = `<div class="reorder-list" id="archive-reorder-list">` +
        entries.map(([id, race]) => `
        <div class="reorder-item" data-id="${id}">
            <span class="reorder-handle">⠿</span>
            <span class="reorder-label">${race.name || id}${race.isNoStats ? ' <span style="font-size:11px;color:#888;">[BEZ PKT]</span>' : ''}${race.isQualifying ? ' <span style="font-size:11px;color:#6088d6;">[KWAL.]</span>' : ''}</span>
            <div class="reorder-actions">
                <button class="btn-action btn-danger btn-sm" onclick="dbCore.deleteNode('${arcPath}/${id}')">🗑</button>
            </div>
        </div>`).join('') + `</div>`;
    const saveBtn = document.getElementById('btn-save-archive-order');
    if (saveBtn) saveBtn.style.display = entries.length > 1 ? 'inline-flex' : 'none';
    const reorderList = document.getElementById('archive-reorder-list');
    if (reorderList) initReorderList(reorderList, () => { if (saveBtn) saveBtn.style.display = 'inline-flex'; });
}

 
function subscribeStandings(splitNum) {
    if (splitSubscribed[splitNum].standings) return;
    splitSubscribed[splitNum].standings = true;
    const sp = seasonStandingsPath(splitNum);
    const cacheKey = 'f1_standings_' + sp.replace(/\//g, '_');

     
    try {
        const cached = localStorage.getItem(cacheKey);
        if (cached) {
            const d = JSON.parse(cached);
            splitDataCache[splitNum].standings = d;
            if (currentSplit === splitNum) renderStandings();
        } else {
            splitDataCache[splitNum].standings = { drivers: [], teams: [] };
            if (currentSplit === splitNum) renderStandings();
        }
    } catch (e) {}

     
    onValue(ref(db, sp), snap => {
        const d = snap.val() || { drivers: [], teams: [] };
        splitDataCache[splitNum].standings = d;
        try { localStorage.setItem(cacheKey, JSON.stringify(d)); } catch (e) {}
        if (adminSplit === splitNum) {
            const driversRaw = document.getElementById('adm-drivers-raw');
            const teamsRaw = document.getElementById('adm-teams-raw');
            if (driversRaw) driversRaw.value = (d.drivers || []).map(dr => `${dr.isBot ? 'BOT:' : (dr.isReserve ? 'REZ:' : '')}${dr.nick} | ${dr.team} | ${dr.photo || ''} | ${dr.wins || 0} | ${dr.pts || 0}`).join('\n');
            if (teamsRaw) teamsRaw.value = (d.teams || []).map(t => `${t.team} | ${t.pts}`).join('\n');
            buildRaceNickChips();
        }
        if (currentSplit === splitNum) renderStandings();
    });
}

function subscribeLastRace(splitNum) {
    if (splitSubscribed[splitNum].lastRace) return;
    splitSubscribed[splitNum].lastRace = true;
    const sp = splitNum === 1 ? 'split1' : 'split2';
    onValue(ref(db, sp + '/lastRace'), snap => {
        const d = snap.val();
        splitDataCache[splitNum].lastRace = d || null;
        if (currentSplit === splitNum) {
            lastRaceDataCache = d || null;
            rerenderLastRace();
        }
    });
}

function subscribeArchive(splitNum, season) {
    const s = season || currentSeason;
    splitSubscribed[splitNum].archive = true;
    onValue(ref(db, seasonArchivePath(splitNum)), snap => {
        const d = snap.val();
        splitDataCache[splitNum].archive = d || {};
        if (currentSplit === splitNum) {
            archiveDataCache = d || {};
            rerenderArchive();
        }
        if (adminSplit === splitNum) buildAdmArchiveManager();
        if (window.ui) ui.refreshGpNameSuggestion(splitNum);
        renderCalendar();
    });
}

function subscribeTeamsInfo(splitNum) {
    if (splitSubscribed[splitNum].teamsInfo) return;
    splitSubscribed[splitNum].teamsInfo = true;
    const sp = splitNum === 1 ? 'split1' : 'split2';
    onValue(ref(db, sp + '/teamsInfo'), snap => {
        const d = snap.val();
        if (d) {
            splitDataCache[splitNum].teamsInfo = d;
            if (currentSplit === splitNum) {
                teamsInfoData = d;
                if (document.getElementById('view-teams').classList.contains('active')) renderTeamsPage();
            }
            if (adminSplit === splitNum) { buildTeamsAdminList(); buildRaceNickChips(); }
        }
    });
}

function subscribeCalendar() {
    if (calendarSubscribed) return;
    calendarSubscribed = true;
    onValue(ref(db, 'calendar'), snap => {
        calendarData = snap.val() || {};
        window.calendarData = calendarData;
        renderCalendar();
        refreshGpNamesDatalist();
        if (window.ui) { ui.refreshGpNameSuggestion(1); ui.refreshGpNameSuggestion(2); }
    });
}

function renderCalendar() {
    const grid = document.getElementById('calendar-grid');
    if (!grid) return;
    let html = '';
    const nextInfo = getNextCalendarEntry(currentSplit);
    const nextRound = nextInfo ? nextInfo.round : null;
    for (let round = 1; round <= 12; round++) {
        const entry = calendarData[round];
        if (entry) {
            const isNext = round === nextRound;
            html += `<div class="calendar-card${isNext ? ' next' : ''}">
                <div class="calendar-card-bg" style="background-image:url('${entry.img || ''}')"></div>
                <div class="calendar-card-overlay"></div>
                <div class="calendar-round-badge">ROUND ${round}</div>
                ${isNext ? '<div class="calendar-next-badge">NEXT</div>' : ''}
                <div class="calendar-flag">${entry.flagCode ? flagImgHtml(entry.flagCode, 40, 27) : ''}</div>
                <div class="calendar-card-info">
                    <div class="calendar-gp-name">${entry.name || ''}</div>
                    <div class="calendar-circuit-name">${entry.country || ''}</div>
                </div>
                ${isLoggedIn ? `<button class="album-edit-btn visible" style="top:auto;bottom:14px;right:14px;" onclick="event.stopPropagation();ui.clearCalendarSlot(${round})">🗑 WYCZYŚĆ</button>` : ''}
            </div>`;
        } else {
            html += `<div class="calendar-card empty">
                <div class="calendar-empty-round">${round}</div>
                <div class="calendar-empty-text">Brak toru</div>
            </div>`;
        }
    }
    grid.innerHTML = html;
    preloadImages(Object.values(calendarData || {}).flatMap(e => e ? [e.img, e.flagCode ? `https://flagcdn.com/w80/${e.flagCode}.png` : ''] : []));
}

preloadImages(TEAM_DEFS.map(t => 'cars/' + t.key + '.png'));

subscribeStandings(1);
subscribeLastRace(1);
subscribeTeamsInfo(1);
subscribeArchive(1);
subscribeCalendar();


 
onValue(ref(db, 'config'), snap => {
    const c = snap.val(); if (!c) return;

    const soonVal = c.split2SoonMode;
    split2SoonMode = (soonVal === null || soonVal === true || soonVal === undefined);
    const tog = document.getElementById('adm-split2-soon-toggle');
    if (tog) tog.checked = !!split2SoonMode;
    if (currentSplit === 2) ui._applySplitView();
    if (c.hideSplitSwitcher !== undefined) {
        applySplitSwitcherVisibility(c.hideSplitSwitcher);
        const togHide = document.getElementById('adm-hide-split-switcher');
        if (togHide) togHide.checked = c.hideSplitSwitcher;
    }
    if (c.teamLogos) { teamLogos = c.teamLogos; preloadImages(Object.values(teamLogos)); buildLogosGrid(); renderStandings(); if (document.getElementById('view-teams').classList.contains('active')) renderTeamsPage(); }
    if (c.socialIcons) {
        socialConfig = c.socialIcons;
        ['discord', 'youtube', 'tiktok'].forEach(p => {
            const cfg = c.socialIcons[p] || {};
            const urlInput = document.getElementById('social-url-' + p);
            const iconInput = document.getElementById('social-icon-' + p);
            if (urlInput) urlInput.value = cfg.url || '';
            if (iconInput && cfg.icon && !cfg.icon.startsWith('data:')) iconInput.value = cfg.icon || '';
            if (cfg.icon) { const prev = document.getElementById('social-prev-' + p); if (prev) prev.innerHTML = `<img src="${cfg.icon}" alt="${p}" style="width:30px;height:30px;object-fit:contain;">`; }
        });
    }
    renderSocialIcons();
    if (c.splashContent) {
        document.getElementById('splash-custom-content').innerHTML = c.splashContent;
        document.getElementById('adm-splash-content').value = c.splashContent;
        document.getElementById('splash-preview-box').innerHTML = c.splashContent;
    }
    if (c.splashImages && c.splashImages.length > 0) {
        renderSplashImages(c.splashImages);
        const list = document.getElementById('adm-splash-images-list');
        if (list) { list.innerHTML = ''; c.splashImages.forEach(img => ui.addSplashImageRow(img)); }
        document.getElementById('splash-image-area').style.display = 'none';
    } else if (c.splashImage) {
        const imgArea = document.getElementById('splash-image-area');
        imgArea.style.display = 'block';
        imgArea.innerHTML = `<div class="splash-featured-image"><img class="splash-image-main" alt="Splash"></div>`;
        loadSplashImage(imgArea.querySelector('.splash-image-main'), c.splashImage);
    }
    document.getElementById('adm-splash-content').addEventListener('input', function() {
        document.getElementById('splash-preview-box').innerHTML = this.value || '<em style="opacity:0.4;">Podgląd...</em>';
    });
    const newsBar = document.getElementById('news-bar-container');
    newsBar.style.display = c.showNews ? 'flex' : 'none';
    const rawNews = c.newsContent || "";
    const formattedNews = rawNews.split(/\s{2,}/).filter(s => s.trim()).join('  <span style="color:rgba(255,255,255,0.4);margin:0 20px;">•</span>  ');
    document.getElementById('api-news-content').innerHTML = formattedNews + '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;' + formattedNews;
    const track = document.getElementById('api-news-content'); const clone = document.getElementById('api-news-clone');
    track.style.animation = 'none'; clone.style.animation = 'none'; void track.offsetWidth;
    track.style.animation = 'f1-marquee 40.55s linear infinite';
    clone.style.animation = 'f1-marquee 40.55s linear infinite'; clone.style.animationDelay = '-20.55s';

    window.heroConfigS1 = { mode: c.heroModeS1 || 'countdown', date: c.heroDateS1 || '', title: c.heroTitleS1 || '' };
    window.heroConfigS2 = { mode: c.heroModeS2 || 'countdown', date: c.heroDateS2 || '', title: c.heroTitleS2 || '' };

    if (c.heroTitleS1 !== undefined) { const el = document.getElementById('adm-hero-title-s1'); if(el) el.value = c.heroTitleS1; }
    if (c.heroDateS1  !== undefined) { const el = document.getElementById('adm-hero-date-s1');  if(el) el.value = c.heroDateS1;  }
    if (c.heroModeS1) { const r = document.querySelector(`input[name="hero-mode-s1"][value="${c.heroModeS1}"]`); if(r) r.checked = true; document.getElementById('hero-date-group-s1').style.display = c.heroModeS1 === 'soon' ? 'none' : 'block'; }
    if (c.heroTitleS2 !== undefined) { const el = document.getElementById('adm-hero-title-s2'); if(el) el.value = c.heroTitleS2; }
    if (c.heroDateS2  !== undefined) { const el = document.getElementById('adm-hero-date-s2');  if(el) el.value = c.heroDateS2;  }
if (c.heroModeS2) { const r = document.querySelector(`input[name="hero-mode-s2"][value="${c.heroModeS2}"]`); if(r) r.checked = true; document.getElementById('hero-date-group-s2').style.display = c.heroModeS2 === 'soon' ? 'none' : 'block'; }

    window.gpNameS1 = c.gpNameS1 || '';
    window.gpNameS2 = c.gpNameS2 || '';
    if (c.gpNameS1 !== undefined) { const el = document.getElementById('adm-gp-name-s1'); if(el) el.value = c.gpNameS1; }
    if (c.gpNameS2 !== undefined) { const el = document.getElementById('adm-gp-name-s2'); if(el) el.value = c.gpNameS2; }
    ui.updateGpPreview(1);
    ui.updateGpPreview(2);

    applyHeroConfig(currentSplit);
    if (c.showNews !== undefined) document.getElementById('adm-show-news').checked = c.showNews;
    if (c.newsContent) document.getElementById('adm-news-content').value = c.newsContent;
    if (c.regulaminContent !== undefined) {
        const display = document.getElementById('regulamin-content-display');
        const textarea = document.getElementById('regulamin-textarea');
        if (display) display.innerHTML = c.regulaminContent || '<div class="regulamin-empty"><span>📋</span>Regulamin zostanie dodany wkrótce.</div>';
        const editorOverlay = document.getElementById('regulamin-editor-overlay');
        if (textarea && !(editorOverlay && editorOverlay.classList.contains('open'))) textarea.value = c.regulaminContent || '';
    }
    const preLoader = document.getElementById('pre-loader');
    const splash = document.getElementById('splash-screen');
    if (preLoader && preLoader.style.display !== 'none') {
        preLoader.style.opacity = '0';
        splash.style.transition = 'opacity 0.6s ease';
        splash.style.opacity = '1';
        setTimeout(() => { preLoader.style.display = 'none'; }, 600);
    }
});

 
let gallerySubscribed = false;
function subscribeGallery() {
    if (gallerySubscribed) return;
    gallerySubscribed = true;
onValue(ref(db, seasonGalleryPath()), snap => {
        const data = snap.val();
        const albumsGrid = document.getElementById('gallery-albums');
        const manager = document.getElementById('adm-gallery-manager');
if (!data) { albumsGrid.innerHTML = "<p>Brak albumów w galerii.</p>"; manager.innerHTML = "Brak albumów."; return; }       window.galleryData = data;
        const entries = Object.entries(data).sort((a, b) => {
            const ao = a[1].order, bo = b[1].order;
            if (ao !== undefined && bo !== undefined) return ao - bo;
            if (ao !== undefined) return -1; if (bo !== undefined) return 1;
            return a[0] < b[0] ? -1 : 1;
        });
        const addAlbumTile = isLoggedIn ? `
            <div class="album-card" style="display:flex;align-items:center;justify-content:center;cursor:pointer;border-bottom:15px solid #444;background:#1a1a22;" onclick="ui.quickCreateAlbum()">
                <div style="font-family:var(--font-display);font-size:90px;color:rgba(255,255,255,0.4);">＋</div>
            </div>` : '';
        albumsGrid.innerHTML = addAlbumTile + entries.map(([id, gal]) => {
            const entryCount = gal.entries ? Object.keys(gal.entries).length : 0;
            const isPinned = !!gal.pinned;
            const pinnedBadge = isPinned ? `<div style="position:absolute;top:14px;left:14px;z-index:20;background:var(--f1-red);color:#fff;border-radius:8px;padding:6px 14px;font-family:var(--font-display);font-size:18px;font-weight:900;letter-spacing:2px;display:flex;align-items:center;gap:6px;box-shadow:0 4px 14px rgba(225,6,0,0.4);">📌 PRZYPIĘTY</div>` : '';
            const pinnedBorder = isPinned ? 'outline:3px solid var(--f1-red);outline-offset:-3px;' : '';
            const pinBtn = isLoggedIn ? `<button class="album-edit-btn visible" style="top:16px;right:90px;" onclick="event.stopPropagation();ui.togglePinAlbum('${id}',${isPinned})">${isPinned ? '📌 ODEPNIJ' : '📌 PRZYPNIJ'}</button>` : '';
            return `<div class="album-card" style="${pinnedBorder}">
                <div class="album-click-zone" onclick="ui.openAlbum('${id}')"></div>
                ${gal.cover ? `<img class="album-card-img" src="${gal.cover}" alt="${gal.name}">` : ''}
                <div style="position:absolute;inset:0;background:linear-gradient(to top,rgba(0,0,0,0.85) 0%,transparent 60%);pointer-events:none;"></div>
                ${pinnedBadge}
                ${pinBtn}
                <button class="album-edit-btn ${isLoggedIn ? 'visible' : ''}" onclick="event.stopPropagation();ui.editAlbumNameFromGrid('${id}','${gal.name.replace(/'/g,"\\'")}',this)">✎ NAZWA</button>
                <div class="album-info" style="pointer-events:none;">
                    <div class="album-name">${gal.name}</div>
                    <div style="font-family:var(--font-body);font-size:16px;color:rgba(255,255,255,0.6);margin-top:6px;letter-spacing:1px;">${entryCount} ${entryCount===1?'wpis':'wpisów'}</div>
                </div>
            </div>`;
        }).join('');
        const saveBtn = document.getElementById('btn-save-gallery-order');
        manager.innerHTML = `<div class="reorder-list" id="gallery-reorder-list">` +
            entries.map(([id, gal]) => `
            <div class="reorder-item" data-id="${id}">
                <span class="reorder-handle">⠿</span>
                <span class="reorder-label">${gal.name}</span>
                <div class="reorder-actions">
                    <button class="btn-action btn-secondary btn-sm" onclick="ui.editAlbumCover('${id}','${(gal.cover||'').replace(/'/g,"\\'")}')">🖼</button>
<button class="btn-action btn-danger btn-sm" onclick="dbCore.deleteNode('${seasonGalleryPath()}/${id}')">🗑</button>
                </div>
            </div>`).join('') + `</div>`;
        if (saveBtn) saveBtn.style.display = entries.length > 1 ? 'inline-flex' : 'none';
        const reorderList = document.getElementById('gallery-reorder-list');
        if (reorderList) initReorderList(reorderList, () => { if (saveBtn) saveBtn.style.display = 'inline-flex'; });
        if (window._currentAlbumId && data[window._currentAlbumId]) ui.openAlbum(window._currentAlbumId);
    });
}
ui.quickCreateAlbum = function() {
    if (!isLoggedIn) return;
    const nextCal = getNextCalendarEntry(currentSplit);
    const gpName = nextCal ? nextCal.entry.name : (currentSplit === 2 ? window.gpNameS2 : window.gpNameS1);
    const suggested = gpName ? gpNameToShort(gpName) : '';
    ui.openGalleryModal('album', null, suggested);
};
ui.togglePinAlbum = async function(id, isPinned) {
await update(ref(db, seasonGalleryPath() + '/' + id), { pinned: !isPinned });
};

ui.editAlbumNameFromGrid = async function(id, currentName, btn) {
    if (!isLoggedIn) return;
    const newName = prompt('Nowa nazwa albumu:', currentName);
    if (newName && newName.trim() && newName.trim() !== currentName) {
await update(ref(db, seasonGalleryPath() + '/' + id), { name: newName.trim() });
        if (window.galleryData && window.galleryData[id]) window.galleryData[id].name = newName.trim();
    }
};
ui.editAlbumCover = async function(id, currentCover) {
    if (!isLoggedIn) return;
    const newCover = prompt('Nowy URL okładki:', currentCover);
    if (newCover !== null && newCover.trim() !== currentCover) await update(ref(db, seasonGalleryPath() + '/' + id), { cover: newCover.trim() });
};

document.querySelectorAll('input[name="hero-mode-s1"]').forEach(r => {
    r.addEventListener('change', function() {
        document.getElementById('hero-date-group-s1').style.display = this.value === 'soon' ? 'none' : 'block';
    });
});
document.querySelectorAll('input[name="hero-mode-s2"]').forEach(r => {
    r.addEventListener('change', function() {
        document.getElementById('hero-date-group-s2').style.display = this.value === 'soon' ? 'none' : 'block';
    });
});

buildLogosGrid();
renderSocialIcons();

 
function initRaceRowDragDrop(tableId, raceId, isLastRace) {
    const table = document.getElementById(tableId);
    if (!table) return;
    const tbody = table.querySelector('tbody');
    if (!tbody) return;
    let dragSrcRow = null;

    tbody.querySelectorAll('tr[draggable]').forEach(row => {
        row.addEventListener('dragstart', e => {
            dragSrcRow = row;
            row.classList.add('race-row-dragging');
            e.dataTransfer.effectAllowed = 'move';
        });
        row.addEventListener('dragend', async () => {
            row.classList.remove('race-row-dragging');
            tbody.querySelectorAll('tr').forEach(r => r.classList.remove('race-row-dragover'));
            const rows = [...tbody.querySelectorAll('tr[data-row-idx]')];
            const splitPath = getSplitPathView();
            try {
if (raceId) {
    const cached = (splitDataCache[currentSplit].archive || {})[raceId];
    if (cached && Array.isArray(cached.results)) {
        const newResults = rows.map(r => cached.results[parseInt(r.dataset.rowIdx)]).filter(Boolean);
        rows.forEach((r, i) => r.dataset.rowIdx = i);
        await set(ref(db, seasonArchivePath(currentSplit) + '/' + raceId + '/results'), newResults);
    }
} else if (isLastRace) {
                    const data = splitDataCache[currentSplit].lastRace;
                    if (data && Array.isArray(data.results)) {
                        const newResults = rows.map(r => data.results[parseInt(r.dataset.rowIdx)]).filter(Boolean);
                        rows.forEach((r, i) => r.dataset.rowIdx = i);
                        await set(ref(db, splitPath + '/lastRace/results'), newResults);
                    }
                }
            } catch(e) { console.error('Błąd zapisu kolejności:', e); }
        });
        row.addEventListener('dragover', e => {
            e.preventDefault();
            e.dataTransfer.dropEffect = 'move';
            tbody.querySelectorAll('tr').forEach(r => r.classList.remove('race-row-dragover'));
            if (row !== dragSrcRow) row.classList.add('race-row-dragover');
        });
        row.addEventListener('drop', e => {
            e.stopPropagation();
            if (dragSrcRow && dragSrcRow !== row) {
                const allRows = [...tbody.querySelectorAll('tr')];
                const si = allRows.indexOf(dragSrcRow), di = allRows.indexOf(row);
                if (si < di) tbody.insertBefore(dragSrcRow, row.nextSibling);
                else tbody.insertBefore(dragSrcRow, row);
            }
        });
    });
}

} catch(err) {
    console.error('Firebase/App error:', err);
}

 
 
function initializeDialogPlacement() {
    const overlays = ['add-race-modal-overlay', 'gallery-modal-overlay', 'circuit-draw-overlay', 'regulamin-editor-overlay', 'auth-modal'];
    overlays.forEach(id => {
        const el = document.getElementById(id);
        if (el && el.parentNode !== document.body) document.body.appendChild(el);
    });
}
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initializeDialogPlacement, { once: true });
} else {
    initializeDialogPlacement();
}

 
const flagImgHtml = (code, w, h) => `<img src="https://flagcdn.com/w80/${code}.png" srcset="https://flagcdn.com/w160/${code}.png 2x" width="${w}" height="${h}" alt="" loading="lazy" style="width:${w}px;height:${h}px;object-fit:cover;display:block;">`;

const F1_CIRCUITS_2025 = [
    { name: 'Australian Grand Prix',    short: 'Australian GP',    country: 'Australia',    flagCode: 'au', img: 'https://www.formula1.com/content/dam/fom-website/2018-redesign-assets/Circuit%20maps%2016x9/Australia_Circuit.png' },
    { name: 'Chinese Grand Prix',       short: 'Chinese GP',       country: 'China',        flagCode: 'cn', img: 'https://www.formula1.com/content/dam/fom-website/2018-redesign-assets/Circuit%20maps%2016x9/China_Circuit.png' },
    { name: 'Japanese Grand Prix',      short: 'Japanese GP',      country: 'Japan',        flagCode: 'jp', img: 'https://www.formula1.com/content/dam/fom-website/2018-redesign-assets/Circuit%20maps%2016x9/Japan_Circuit.png' },
    { name: 'Bahrain Grand Prix',       short: 'Bahrain GP',       country: 'Bahrain',      flagCode: 'bh', img: 'https://www.formula1.com/content/dam/fom-website/2018-redesign-assets/Circuit%20maps%2016x9/Bahrain_Circuit.png' },
    { name: 'Saudi Arabian Grand Prix', short: 'Saudi Arabian GP', country: 'Arabia Saud.',  flagCode: 'sa', img: 'https://www.formula1.com/content/dam/fom-website/2018-redesign-assets/Circuit%20maps%2016x9/Saudi_Arabia_Circuit.png' },
    { name: 'Miami Grand Prix',         short: 'Miami GP',         country: 'USA',          flagCode: 'us', img: 'https://www.formula1.com/content/dam/fom-website/2018-redesign-assets/Circuit%20maps%2016x9/Miami_Circuit.png' },
    { name: 'Madrid Grand Prix',        short: 'Madrid GP',        country: 'Hiszpania',    flagCode: 'es', img: 'https://media.formula1.com/image/upload/c_fit,h_704/q_auto/v1740000001/common/f1/2026/track/2026trackmadringdetailed.webp' },
    { name: 'Monaco Grand Prix',        short: 'Monaco GP',        country: 'Monako',       flagCode: 'mc', img: 'https://www.formula1.com/content/dam/fom-website/2018-redesign-assets/Circuit%20maps%2016x9/Monaco_Circuit.png' },
    { name: 'Spanish Grand Prix',       short: 'Spanish GP',       country: 'Hiszpania',    flagCode: 'es', img: 'https://www.formula1.com/content/dam/fom-website/2018-redesign-assets/Circuit%20maps%2016x9/Spain_Circuit.png' },
    { name: 'Canadian Grand Prix',      short: 'Canadian GP',      country: 'Kanada',       flagCode: 'ca', img: 'https://www.formula1.com/content/dam/fom-website/2018-redesign-assets/Circuit%20maps%2016x9/Canada_Circuit.png' },
    { name: 'Austrian Grand Prix',      short: 'Austrian GP',      country: 'Austria',      flagCode: 'at', img: 'https://www.formula1.com/content/dam/fom-website/2018-redesign-assets/Circuit%20maps%2016x9/Austria_Circuit.png' },
    { name: 'British Grand Prix',       short: 'British GP',       country: 'W. Brytania',  flagCode: 'gb', img: 'https://www.formula1.com/content/dam/fom-website/2018-redesign-assets/Circuit%20maps%2016x9/Great_Britain_Circuit.png' },
    { name: 'Belgian Grand Prix',       short: 'Belgian GP',       country: 'Belgia',       flagCode: 'be', img: 'https://www.formula1.com/content/dam/fom-website/2018-redesign-assets/Circuit%20maps%2016x9/Belgium_Circuit.png' },
    { name: 'Hungarian Grand Prix',     short: 'Hungarian GP',     country: 'Węgry',        flagCode: 'hu', img: 'https://www.formula1.com/content/dam/fom-website/2018-redesign-assets/Circuit%20maps%2016x9/Hungary_Circuit.png' },
    { name: 'Dutch Grand Prix',         short: 'Dutch GP',         country: 'Holandia',     flagCode: 'nl', img: 'https://www.formula1.com/content/dam/fom-website/2018-redesign-assets/Circuit%20maps%2016x9/Netherlands_Circuit.png' },
    { name: 'Italian Grand Prix',       short: 'Italian GP',       country: 'Włochy',       flagCode: 'it', img: 'https://www.formula1.com/content/dam/fom-website/2018-redesign-assets/Circuit%20maps%2016x9/Italy_Circuit.png' },
    { name: 'Azerbaijan Grand Prix', short: 'Azerbaijan GP', country: 'Azerbejdżan', flagCode: 'az', img: 'https://www.formula1.com/content/dam/fom-website/2018-redesign-assets/Circuit%20maps%2016x9/Baku_Circuit.png' },
    { name: 'Singapore Grand Prix',     short: 'Singapore GP',     country: 'Singapur',     flagCode: 'sg', img: 'https://www.formula1.com/content/dam/fom-website/2018-redesign-assets/Circuit%20maps%2016x9/Singapore_Circuit.png' },
    { name: 'United States Grand Prix', short: 'United States GP', country: 'USA',          flagCode: 'us', img: 'https://www.formula1.com/content/dam/fom-website/2018-redesign-assets/Circuit%20maps%2016x9/USA_Circuit.png' },
    { name: 'Mexico City Grand Prix',   short: 'Mexico City GP',   country: 'Meksyk',       flagCode: 'mx', img: 'https://www.formula1.com/content/dam/fom-website/2018-redesign-assets/Circuit%20maps%2016x9/Mexico_Circuit.png' },
    { name: 'São Paulo Grand Prix',     short: 'São Paulo GP',     country: 'Brazylia',     flagCode: 'br', img: 'https://www.formula1.com/content/dam/fom-website/2018-redesign-assets/Circuit%20maps%2016x9/Brazil_Circuit.png' },
    { name: 'Las Vegas Grand Prix',     short: 'Las Vegas GP',     country: 'USA',          flagCode: 'us', img: 'https://www.formula1.com/content/dam/fom-website/2018-redesign-assets/Circuit%20maps%2016x9/Las_Vegas_Circuit.png' },
    { name: 'Qatar Grand Prix',         short: 'Qatar GP',         country: 'Katar',        flagCode: 'qa', img: 'https://www.formula1.com/content/dam/fom-website/2018-redesign-assets/Circuit%20maps%2016x9/Qatar_Circuit.png' },
    { name: 'Abu Dhabi Grand Prix',     short: 'Abu Dhabi GP',     country: 'Abu Dhabi',    flagCode: 'ae', img: 'https://www.formula1.com/content/dam/fom-website/2018-redesign-assets/Circuit%20maps%2016x9/Abu_Dhabi_Circuit.png' },
];

window.circuitDraw = {
    _spinning: false,
    _result: null,
    _usedNames: new Set(),
    _currentAnimation: null,
    _mode: 'soon',
    _lastWinnerName: (function(){ try { return localStorage.getItem('f1_lastCircuitWinner') || null; } catch(e){ return null; } })(),

    _shuffle(arr) {
        const a = [...arr];
        for (let i = a.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [a[i], a[j]] = [a[j], a[i]];
        }
        return a;
    },

_getUsedCircuits() {
    if (this._mode === 'calendar') {
        const usedCal = new Set();
        const cal = window.calendarData || {};
        Object.values(cal).forEach(entry => { if (entry && entry.name) usedCal.add(entry.name); });
        return usedCal;
    }
    const used = new Set();
    const KEYWORD_MAP = [
        { keys: ['australian','australia','albert park'],                name: 'Australian Grand Prix' },
        { keys: ['chinese','china','shanghai'],                          name: 'Chinese Grand Prix' },
        { keys: ['japanese','japan','suzuka'],                           name: 'Japanese Grand Prix' },
        { keys: ['bahrain','sakhir'],                                    name: 'Bahrain Grand Prix' },
        { keys: ['saudi','arabia','jeddah'],                             name: 'Saudi Arabian Grand Prix' },
        { keys: ['miami'],                                               name: 'Miami Grand Prix' },
        { keys: ['madrid'],                                              name: 'Madrid Grand Prix' },
        { keys: ['monaco','monte carlo'],                                name: 'Monaco Grand Prix' },
        { keys: ['spanish','spain','barcelona','catalunya'],             name: 'Spanish Grand Prix' },
        { keys: ['canadian','canada','montreal','villeneuve'],           name: 'Canadian Grand Prix' },
        { keys: ['austrian','austria','spielberg','red bull ring'],      name: 'Austrian Grand Prix' },
        { keys: ['british','britain','silverstone'],                     name: 'British Grand Prix' },
        { keys: ['belgian','belgium','spa','francorchamps'],             name: 'Belgian Grand Prix' },
        { keys: ['hungarian','hungary','hungaroring','budapest'],        name: 'Hungarian Grand Prix' },
        { keys: ['dutch','netherlands','zandvoort'],                     name: 'Dutch Grand Prix' },
        { keys: ['italian','italy','monza'],                             name: 'Italian Grand Prix' },
        { keys: ['azerbaijan','baku'],                                   name: 'Azerbaijan Grand Prix' },
        { keys: ['singapore','marina bay'],                              name: 'Singapore Grand Prix' },
        { keys: ['united states','usa','austin','cota'],                 name: 'United States Grand Prix' },
        { keys: ['mexico','mexico city','hermanos'],                     name: 'Mexico City Grand Prix' },
        { keys: ['paulo','sao paulo','brasil','brazil','interlagos'],    name: 'São Paulo Grand Prix' },
        { keys: ['las vegas','vegas'],                                   name: 'Las Vegas Grand Prix' },
        { keys: ['qatar','losail'],                                      name: 'Qatar Grand Prix' },
        { keys: ['abu dhabi','yas marina','yas'],                        name: 'Abu Dhabi Grand Prix' },
    ];

    const matchAndAdd = (rawText) => {
        if (!rawText) return;
        const clean = rawText.toLowerCase()
            .replace(/next race:?/gi, '')
            .replace(/round\s*\d+\s*[-–—]?\s*/i, '')
            .replace(/gp\b/gi, '')
            .trim();
        KEYWORD_MAP.forEach(entry => {
            if (entry.keys.some(k => clean.includes(k))) used.add(entry.name);
        });
    };

    const cache = window.splitDataCache || {};
    [1, 2].forEach(s => {
        const arc = (cache[s] && cache[s].archive) ? cache[s].archive : {};
        Object.values(arc).forEach(r => {
            if (!r.isQualifying && r.name) matchAndAdd(r.name);
        });
    });

   
    matchAndAdd(window.gpNameS1);
    matchAndAdd(window.gpNameS2);
    matchAndAdd(window.heroConfigS1 && window.heroConfigS1.title);
    matchAndAdd(window.heroConfigS2 && window.heroConfigS2.title);

    return used;
},

    _getAvailable() {
    const used = this._getUsedCircuits();
    console.log('Używane tory:', [...used]);
    return F1_CIRCUITS_2025.filter(c => !used.has(c.name));
},

    _buildReel(available) {
    const reel = document.getElementById('cdm-reel');
    if (!reel) return;
    
   let pool = [];
        if (available.length > 0) {
            const repeats = Math.max(4, Math.ceil(20 / available.length));
            for (let i = 0; i < repeats; i++) {
                let shuffled = this._shuffle(available);
                if (pool.length > 0 && shuffled[0].name === pool[pool.length - 1].name && shuffled.length > 1) {
                    [shuffled[0], shuffled[1]] = [shuffled[1], shuffled[0]];
                }
                pool.push(...shuffled);
            }
        }
        reel.innerHTML = pool.map((c, i) => {
            return `<div class="cdm-card" data-name="${c.name}" data-idx="${i}">
                <img class="cdm-card-img" src="${c.img}" alt="${c.short}" onerror="this.style.opacity=0.2">
                <span class="cdm-card-flag">${flagImgHtml(c.flagCode, 32, 22)}</span>
                <div class="cdm-card-label">
                    <div class="cdm-card-country">${c.country}</div>
                    <div class="cdm-card-name">${c.short}</div>
                </div>
            </div>`;
        }).join('');
        reel.style.transform = 'translateX(0)';
        reel.style.transition = 'none';
    },

  open(mode) {
    this._mode = mode === 'calendar' ? 'calendar' : 'soon';
    const overlay = document.getElementById('circuit-draw-overlay');
    if (!overlay) return;
    overlay.classList.add('open');
    document.body.style.overflow = 'hidden';
    const titleEl = document.querySelector('.cdm-header-title');
    if (titleEl) titleEl.textContent = this._mode === 'calendar' ? 'Losowanie do Kalendarza' : 'Losowanie toru GP';
    this._result = null;
    this._spinning = false;
    document.getElementById('cdm-result-box').classList.remove('show');
    document.getElementById('cdm-btn-spin').style.display = '';
    document.getElementById('cdm-btn-spin').disabled = true;
    document.getElementById('cdm-btn-accept').style.display = 'none';
    document.getElementById('cdm-btn-reject').style.display = 'none';
    document.getElementById('cdm-status').textContent = 'Ładowanie danych archiwum...';
    document.getElementById('cdm-reel').innerHTML = '';

    const { ref: fbRef, onValue: fbOnValue } = window._fbFirebase;
    const db = window._fbDb;

    const finishLoading = () => {
        try {
            const available = this._getAvailable();
            this._buildReel(available);
            this._updateStatus(available);
            document.getElementById('cdm-btn-spin').disabled = available.length === 0;
        } catch (e) {
            console.error('Błąd podczas losowania toru:', e);
            document.getElementById('cdm-status').textContent = '❌ Błąd: ' + e.message + ' (sprawdź konsolę F12)';
        }
    };

    if (this._mode === 'calendar') {
        fbOnValue(fbRef(db, 'calendar'), snap => {
            window.calendarData = snap.val() || {};
            calendarData = window.calendarData;
            finishLoading();
        }, (err) => { console.error('Błąd calendar:', err); finishLoading(); }, { onlyOnce: true });
        return;
    }

    let s1Ready = false, s2Ready = false;
    const maybeFinish = () => { if (s1Ready && s2Ready) finishLoading(); };

    fbOnValue(fbRef(db, 'split1/archive'), snap => {
        if (window.splitDataCache) window.splitDataCache[1].archive = snap.val() || {};
        s1Ready = true; maybeFinish();
    }, (err) => { console.error('Błąd split1/archive:', err); s1Ready = true; maybeFinish(); }, { onlyOnce: true });

    fbOnValue(fbRef(db, 'split2/archive'), snap => {
        if (window.splitDataCache) window.splitDataCache[2].archive = snap.val() || {};
        s2Ready = true; maybeFinish();
    }, (err) => { console.error('Błąd split2/archive:', err); s2Ready = true; maybeFinish(); }, { onlyOnce: true });

     
    setTimeout(() => { if (!(s1Ready && s2Ready)) { s1Ready = true; s2Ready = true; finishLoading(); } }, 6000);
},

    close() {
        const overlay = document.getElementById('circuit-draw-overlay');
        if (overlay) overlay.classList.remove('open');
        document.body.style.overflow = '';
    },

    _updateStatus(available) {
        const used = F1_CIRCUITS_2025.length - (available || this._getAvailable()).length;
        document.getElementById('cdm-used-count').textContent =
            `Użyte: ${used}/${F1_CIRCUITS_2025.length} torów • Dostępne: ${(available || this._getAvailable()).length}`;
        document.getElementById('cdm-status').textContent =
            (available || this._getAvailable()).length === 0
                ? '⚠️ Wszystkie tory zostały już wylosowane!'
                : 'Gotowy do losowania';
    },

    spin() {
        if (this._spinning) return;
        const available = this._getAvailable();
        if (available.length === 0) { ui.showToast('Wszystkie tory zostały już użyte w archiwum!', 'warn'); return; }

if (this._currentAnimation) {
    this._currentAnimation.cancel();
    this._currentAnimation = null;
}
document.getElementById('cdm-reel')?.getAnimations().forEach(a => a.cancel());

        this._spinning = true;
        this._result = null;

         
        document.getElementById('cdm-result-box').classList.remove('show');
        document.getElementById('cdm-btn-accept').style.display = 'none';
        document.getElementById('cdm-btn-reject').style.display = 'none';
        document.getElementById('cdm-btn-spin').disabled = true;
        document.getElementById('cdm-status').textContent = '🎰 Losowanie w toku...';
        document.querySelectorAll('.cdm-card').forEach(c => c.classList.remove('highlight','winner'));

        let candidates = available;
        if (this._lastWinnerName && available.length > 1) {
            const filtered = available.filter(c => c.name !== this._lastWinnerName);
            if (filtered.length > 0) candidates = filtered;
        }
        const winner = candidates[Math.floor(Math.random() * candidates.length)];

        const reel = document.getElementById('cdm-reel');
        const reelWrap = document.querySelector('.cdm-reel-wrap');

       
        const VMAX_PX_S = 3000;                                     
const rampMs     = Math.round(450 + Math.random() * 200);    
const plateauMs  = Math.round(1400 + Math.random() * 900);   
const tailMs     = 1000;                                     
const mainDecayMs = Math.round(4200 + Math.random() * 1600); 
        const decayMs    = mainDecayMs + tailMs;
        const totalMs    = rampMs + plateauMs + decayMs;
        const V_CREEP    = 90;  

        
        const velocityAt = (tMs) => {
            if (tMs < rampMs) {
                return VMAX_PX_S * 0.5 * (1 - Math.cos(Math.PI * tMs / rampMs));
            } else if (tMs < rampMs + plateauMs) {
                return VMAX_PX_S;
            } else {
                const td = tMs - rampMs - plateauMs;
                if (td < mainDecayMs) {
                    const t = td / mainDecayMs;
                    const eased = 0.5 * (1 - Math.cos(Math.PI * t));
                    return VMAX_PX_S + (V_CREEP - VMAX_PX_S) * eased;
                } else {
                    const tt = Math.min(1, (td - mainDecayMs) / tailMs);
                    const eased = 0.5 * (1 - Math.cos(Math.PI * tt));
                    return V_CREEP * (1 - eased);
                }
            }
        };

        const SAMPLES = 140;
        const stepMs = totalMs / SAMPLES;
        const positions = [0];
        for (let i = 1; i <= SAMPLES; i++) {
            positions.push(positions[i - 1] + velocityAt(i * stepMs) * (stepMs / 1000));
        }
        const totalDistEstimate = positions[positions.length - 1];

        const CARD_STEP_ESTIMATE = 192;
        const travelCards = Math.ceil(totalDistEstimate / CARD_STEP_ESTIMATE) + 4;
        const AFTER_CARDS = 14;

        const cycle = [];
        while (cycle.length < travelCards + AFTER_CARDS + available.length) {
            let shuffled = this._shuffle(available);
            if (cycle.length > 0 && shuffled[0].name === cycle[cycle.length - 1].name && shuffled.length > 1) {
                [shuffled[0], shuffled[1]] = [shuffled[1], shuffled[0]];
            }
            cycle.push(...shuffled);
        }
        const winnerIdx = travelCards;
        const filler = cycle.slice(0, winnerIdx);
        if (filler.length > 0 && filler[filler.length - 1].name === winner.name) {
            filler.pop();
            filler.push(cycle[winnerIdx] || available.find(c => c.name !== winner.name));
        }
        filler.push(winner);
        let afterCards = cycle.slice(winnerIdx, winnerIdx + AFTER_CARDS);
        if (afterCards.length > 0 && afterCards[0].name === winner.name && afterCards.length > 1) {
            [afterCards[0], afterCards[1]] = [afterCards[1], afterCards[0]];
        }
        filler.push(...afterCards);

        reel.innerHTML = filler.map((c, i) => {
            return `<div class="cdm-card" data-name="${c.name}" data-idx="${i}">
                <img class="cdm-card-img" src="${c.img}" alt="${c.short}" onerror="this.style.opacity=0.2">
                <span class="cdm-card-flag">${flagImgHtml(c.flagCode, 32, 22)}</span>
                <div class="cdm-card-label">
                    <div class="cdm-card-country">${c.country}</div>
                    <div class="cdm-card-name">${c.short}</div>
                </div>
            </div>`;
        }).join('');

        reel.style.transition = 'none';
        reel.style.transform = 'translateX(0)';
        void reel.offsetWidth;

        
        const winnerCardEl = reel.children[winnerIdx];
        const wrapRect = reelWrap.getBoundingClientRect();
        const cardRect = winnerCardEl.getBoundingClientRect();
        const cardCenterX = cardRect.left + cardRect.width / 2;
        const wrapCenterX = wrapRect.left + wrapRect.width / 2;
        const snapX = Math.round(wrapCenterX - cardCenterX);
        const jitterSign = Math.random() < 0.5 ? -1 : 1;
        const jitterMagnitude = 25 + Math.random() * 45;
        const finalX = snapX + jitterSign * jitterMagnitude;

        const scale = finalX / totalDistEstimate;
        const keyframes = positions.map((p, i) => ({
            transform: `translateX(${p * scale}px)`,
            offset: i / SAMPLES
        }));

        const animation = reel.animate(keyframes, { duration: totalMs, fill: 'forwards' });
        this._currentAnimation = animation;

        animation.onfinish = () => {
    
    animation.cancel();
    reel.style.transition = 'none';
    reel.style.transform = `translateX(${finalX}px)`;
    void reel.offsetWidth;

    const wrapRectFinal = reelWrap.getBoundingClientRect();
    const cardRectFinal = winnerCardEl.getBoundingClientRect();
    const correction = (wrapRectFinal.left + wrapRectFinal.width / 2) - (cardRectFinal.left + cardRectFinal.width / 2);

    
    reel.style.transition = 'transform 0.35s cubic-bezier(0.19,1,0.22,1)';
    requestAnimationFrame(() => {
        reel.style.transform = `translateX(${finalX + correction}px)`;
    });
    const clearTransition = () => { reel.style.transition = 'none'; reel.removeEventListener('transitionend', clearTransition); };
    reel.addEventListener('transitionend', clearTransition, { once: true });

            winnerCardEl.classList.add('highlight', 'winner');

             
            this._result = winner;
            this._lastWinnerName = winner.name;
            try { localStorage.setItem('f1_lastCircuitWinner', winner.name); } catch(e) {}
            document.getElementById('cdm-result-flag').innerHTML = flagImgHtml(winner.flagCode, 78, 53);
            document.getElementById('cdm-result-name').textContent = winner.name;
            document.getElementById('cdm-result-country').textContent = winner.country;
            document.getElementById('cdm-result-box').classList.add('show');
            document.getElementById('cdm-status').textContent = `🏁 Wylosowano: ${winner.name}`;
            document.getElementById('cdm-btn-spin').style.display = 'none';
            document.getElementById('cdm-btn-accept').style.display = '';
            document.getElementById('cdm-btn-reject').style.display = '';
            this._currentAnimation = null;
            this._spinning = false;
        };
    },

    async accept() {
        if (!this._result) return;
        const c = this._result;

        if (this._mode === 'calendar') {
            try {
                const { ref: fbRef, onValue: fbOnValue, set: fbSet } = window._fbFirebase;
                const db = window._fbDb;
                const snap = await new Promise(res => fbOnValue(fbRef(db, 'calendar'), res, { onlyOnce: true }));
                const cal = snap.val() || {};
                let nextRound = null;
                for (let r = 1; r <= 12; r++) { if (!cal[r]) { nextRound = r; break; } }
                if (!nextRound) {
                    ui.showToast('Kalendarz jest już pełny (12/12 rund).', 'warn');
                    this.close();
                    return;
                }
                await fbSet(fbRef(db, 'calendar/' + nextRound), {
                    name: c.name, short: c.short, country: c.country,
                    flagCode: c.flagCode, img: c.img,
                });
                cal[nextRound] = { name: c.name, short: c.short, country: c.country, flagCode: c.flagCode, img: c.img };
                window.calendarData = cal;
                calendarData = cal;
                if (typeof renderCalendar === 'function') renderCalendar();

                ui.showToast(`Runda ${nextRound}: ${c.name} dodana do kalendarza!`, 'success');

                if (nextRound >= 12) {
                    ui.showToast('Kalendarz jest kompletny — wylosowano wszystkie 12 rund!', 'success');
                    this.close();
                    return;
                }
                this._result = null;
                document.getElementById('cdm-result-box').classList.remove('show');
                document.getElementById('cdm-btn-accept').style.display = 'none';
                document.getElementById('cdm-btn-reject').style.display = 'none';
                document.getElementById('cdm-btn-spin').style.display = '';
                const available = this._getAvailable();
                this._buildReel(available);
                this._updateStatus(available);
                document.getElementById('cdm-btn-spin').disabled = available.length === 0;
            } catch(e) {
                console.error(e);
                ui.showToast('Błąd zapisu kalendarza: ' + e.message, 'error');
            }
            return;
        }

        try {
            if (!window._fbDb) { ui.showToast('Błąd: brak połączenia z Firebase.', 'error'); return; }
            const { ref: fbRef, onValue: fbOnValue, set: fbSet } = window._fbFirebase;
            const db = window._fbDb;
            const snap = await new Promise(res => fbOnValue(fbRef(db, 'config'), res, { onlyOnce: true }));
            const cfg = snap.val() || {};
            const title = ` ${c.name.toUpperCase()}`;
            await fbSet(fbRef(db, 'config'), {
                ...cfg,
                heroTitleS1: title,
                heroModeS1: 'soon',
                heroTitleS2: title,
                heroModeS2: 'soon',
                gpNameS1: c.name,
                gpNameS2: c.name,
            });
            this.close();
            ui.showToast(`Zaakceptowano: ${c.name} — odliczanie ustawione na SOON`, 'success');
        } catch(e) {
            console.error(e);
            ui.showToast('Błąd zapisu do Firebase: ' + e.message, 'error');
        }
    },

    reject() {
        this._result = null;
        document.getElementById('cdm-result-box').classList.remove('show');
        document.getElementById('cdm-btn-accept').style.display = 'none';
        document.getElementById('cdm-btn-reject').style.display = 'none';
        document.getElementById('cdm-btn-spin').style.display = '';
        document.getElementById('cdm-btn-spin').disabled = false;
        document.getElementById('cdm-status').textContent = 'Odrzucono — losuj ponownie';
        document.querySelectorAll('.cdm-card').forEach(c => c.classList.remove('highlight','winner'));
        this._buildReel(this._getAvailable());
    }
};
if (!window.splitDataCache) { window.splitDataCache = {}; }
if (!window.currentSplitRef) { window.currentSplitRef = () => null; }

function finishLoadingIndicator() {
    const loader = document.getElementById('loader');
    if (loader) loader.style.display = 'none';
}
if (document.readyState === 'complete') {
    finishLoadingIndicator();
} else {
    window.addEventListener('load', finishLoadingIndicator, { once: true });
}

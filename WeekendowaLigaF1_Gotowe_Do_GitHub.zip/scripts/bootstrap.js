const pages = [
  ['standings', 'klasyfikacje.html'],
  ['last-race', 'ostatni-wyscig.html'],
  ['archive', 'archiwum.html'],
  ['calendar', 'kalendarz.html'],
  ['gallery', 'galeria.html'],
  ['teams', 'zespoly.html'],
  ['regulamin', 'regulamin.html'],
];

const content = document.getElementById('page-content');

async function loadPage(filename) {
  const url = new URL(`../pages/${filename}`, import.meta.url);
  const response = await fetch(url);
  if (!response.ok) throw new Error(`Nie udało się pobrać ${filename}: HTTP ${response.status}`);
  return response.text();
}

try {
  const markup = await Promise.all(pages.map(([, filename]) => loadPage(filename)));
  const fragment = document.createDocumentFragment();
  for (let i = 0; i < pages.length; i++) {
    const template = document.createElement('template');
    template.innerHTML = markup[i];
    const view = template.content.firstElementChild;
    if (!view || view.id !== `view-${pages[i][0]}`) {
      throw new Error(`Nieprawidłowa struktura widoku: ${pages[i][1]}`);
    }
    fragment.appendChild(template.content);
  }
  content.appendChild(fragment);
  const year = document.getElementById('footer-year');
  if (year) year.textContent = String(new Date().getFullYear());
  await import('./app.js');

  setTimeout(() => {
    const cover = document.getElementById('pre-loader');
    if (!cover || cover.style.display === 'none') return;
    cover.style.opacity = '0';
    const splash = document.getElementById('splash-screen');
    if (splash) splash.style.opacity = '1';
    setTimeout(() => { cover.style.display = 'none'; }, 650);
  }, 3500);
} catch (error) {
  console.error('Nie udało się uruchomić strony:', error);
  const loader = document.getElementById('pre-loader');
  if (loader) loader.style.display = 'none';
  const splash = document.getElementById('splash-screen');
  if (splash) splash.style.display = 'none';
  const app = document.getElementById('main-app');
  if (app) app.style.display = 'flex';
  content.innerHTML = '<div class="app-error" role="alert">Nie udało się wczytać zakładek. Sprawdź połączenie i odśwież stronę.</div>';
}

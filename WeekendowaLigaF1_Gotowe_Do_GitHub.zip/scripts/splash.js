function hideSplash() {
    var splash = document.getElementById('splash-screen');
    if (!splash) return;
	document.body.style.background = '';
    splash.classList.add('hiding');
    splash.style.opacity = '0';
    splash.style.transform = 'scale(1.05)';
    setTimeout(function() {
        splash.style.display = 'none';
        var app = document.getElementById('main-app');
        if (app) app.style.display = 'flex';
        if (window._resetInactivityTimer) window._resetInactivityTimer();
        if (window.ui && window.ui.replayStandingsCountUp) window.ui.replayStandingsCountUp();
    }, 500);
}
function showSplash() {
    var app = document.getElementById('main-app');
    if (app) app.style.display = 'none';
    var splash = document.getElementById('splash-screen');
    if (!splash) return;
    splash.style.display = 'flex';
    splash.style.opacity = '1';
    splash.style.transform = '';
    splash.classList.remove('hiding');
}

(function() {
    var INACTIVITY_MS = 10 * 60 * 1000;
    var _inactivityTimer = null;

    function resetInactivityTimer() {
        var splash = document.getElementById('splash-screen');
        if (splash && splash.style.display !== 'none' && !splash.classList.contains('hiding')) return;
        clearTimeout(_inactivityTimer);
        _inactivityTimer = setTimeout(function() {
            showSplash();
        }, INACTIVITY_MS);
    }

    ['mousemove', 'mousedown', 'keydown', 'touchstart', 'scroll', 'click'].forEach(function(evt) {
        document.addEventListener(evt, resetInactivityTimer, { passive: true });
    });

    resetInactivityTimer();
    window._resetInactivityTimer = resetInactivityTimer;
})();
setTimeout(function() {
    var splash = document.getElementById('splash-screen');
    if (splash && splash.style.display !== 'none') {
        hideSplash();
    }
}, 30000);
